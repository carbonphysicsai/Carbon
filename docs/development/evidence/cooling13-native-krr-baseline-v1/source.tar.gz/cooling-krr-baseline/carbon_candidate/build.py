"""Cooling's registered learned baseline (learned-krr-v1) as a Cooling 1.3 recipe.

Cooling 1.3 serves the law-safe output encoding (`cold_plate.output_encoding`):
its TRAIN and every predicted row carry slot 0 as a raw peak excess `e`
(peak = max(profile) + softplus(e)) and slot 31 as a raw pressure `q`
(pressure drop = softplus(q)). This recipe decodes TRAIN to the native 32
values, fits the same model as `carbon.scoring.cooling_dual_pack._baseline_outputs`
on them (inputs scaled to [-1, 1] by `cold_plate.domain.INPUT_BOUNDS`; targets
log(peak - inlet), log(profile_i - inlet) x30 and log(pressure drop); a Gaussian
kernel ridge, length 8.0, ridge 1e-6; back-transformed as inlet + exp(.) and
exp(.), with peak = max(peak, max profile)), and returns those native outputs
encoded again: slot 0 = inverse softplus of the peak excess (at least 32 float32
ulp of the hottest segment mean, the floor `output_encoding.encode_targets`
uses), slot 31 = inverse softplus of the pressure drop. Decoded, its rows are the
registered baseline's. The fit is numpy; the returned forward is plain Torch with
the scaled TRAIN points and coefficients as its parameters.
Output: (cases, 32) float64, encoded as Cooling 1.3 declares.
"""

from __future__ import annotations

import numpy as np
import torch

#: cold_plate.domain.INPUT_BOUNDS in the kit's input order (domain.INPUTS):
#: channel_width_mm, fin_width_mm, channel_depth_mm, flow_lpm_per_kw, inlet_c,
#: heat_load_w, hotspot_ratio, hotspot_center_mm, hotspot_width_mm.
LOW = np.array([0.2, 0.2, 1.0, 1.25, 30.0, 500.0, 1.0, 3.0, 1.5])
HIGH = np.array([0.5, 0.5, 3.0, 2.0, 45.0, 1500.0, 3.0, 27.0, 3.5])
INLET = 4
PROFILE = 30
#: The inverse softplus switches form at 20, as `output_encoding` does.
SWITCH = 20.0
#: `cold_plate.exam.ULP_FACTOR` and `F32_EPS`, the peak floor `encode_targets` uses.
ULP_FACTOR = 32
F32_EPS = float(np.finfo(np.float32).eps)


def _scale(x):
    return 2 * (np.asarray(x, float) - LOW) / (HIGH - LOW) - 1


def _kernel(a, b, length):
    squared = (a**2).sum(1)[:, None] + (b**2).sum(1)[None, :] - 2 * a @ b.T
    return np.exp(-np.maximum(squared, 0.0) / (2 * length**2))


def _softplus(x):
    return np.log1p(np.exp(-np.abs(x))) + np.maximum(x, 0.0)


def _native(encoded):
    """Encoded TRAIN rows (slot 0 raw excess, slot 31 raw pressure) as native."""
    t = np.array(encoded, dtype=float)
    profile = t[:, 1 : 1 + PROFILE]
    t[:, 0] = profile.max(1) + _softplus(t[:, 0])
    t[:, -1] = _softplus(t[:, -1])
    return t


def build(train_inputs, train_targets, *, seed, configuration, train_use):
    del seed  # closed-form and deterministic
    if set(configuration) != {"length", "ridge"} or train_use not in ({}, {"cases": "all"}):
        raise ValueError("kernel ridge takes length and ridge, and all TRAIN")
    length, ridge = float(configuration["length"]), float(configuration["ridge"])
    x_raw = np.asarray(train_inputs, float)
    t = _native(train_targets)
    inlet = x_raw[:, INLET : INLET + 1]
    y = np.column_stack(
        [np.log(t[:, :1] - inlet), np.log(t[:, 1 : 1 + PROFILE] - inlet), np.log(t[:, -1:])]
    )
    x = _scale(x_raw)
    mean, std = y.mean(0), y.std(0)
    std[std == 0] = 1.0
    k = _kernel(x, x, length) + ridge * np.eye(len(x))
    factor = np.linalg.cholesky(k)
    z = np.linalg.solve(factor, (y - mean) / std)
    alpha = np.linalg.solve(factor.T, z)

    low, span = torch.from_numpy(LOW), torch.from_numpy(HIGH - LOW)
    mean_t, std_t = torch.from_numpy(mean), torch.from_numpy(std)
    scale = -1.0 / (2 * length**2)  # applied as a multiply: no neg op

    def inverse_softplus(v):
        # log(exp(v) - 1) up to SWITCH, v + log1p(-exp(-v)) above; each branch
        # sees only arguments it handles.
        small = torch.log(torch.exp(torch.clamp(v, max=SWITCH)) - 1.0)
        big_v = torch.clamp(v, min=SWITCH)
        big = big_v + torch.log1p(torch.exp(big_v * -1.0) * -1.0)
        return torch.where(v > SWITCH, big, small)

    def apply(params, inputs):
        points, coefficients = params
        raw = torch.as_tensor(inputs)
        q = 2 * (raw - low) / span - 1
        squared = (
            (q * q).sum(1).unsqueeze(1)
            + (points * points).sum(1).unsqueeze(0)
            - 2 * (q @ points.t())
        )
        squared = torch.where(squared > 0, squared, squared * 0)
        logs = torch.exp(squared * scale) @ coefficients * std_t + mean_t
        inlet_t = raw[:, INLET : INLET + 1]
        profile = inlet_t + torch.exp(logs[:, 1 : 1 + PROFILE])
        peak = inlet_t + torch.exp(logs[:, :1])
        hottest = profile[:, :1]
        for i in range(PROFILE):  # peak = max(peak, max profile), as where
            column = profile[:, i : i + 1]
            peak = torch.where(column > peak, column, peak)
            hottest = torch.where(column > hottest, column, hottest)
        # The law's own tolerance unit at the hottest segment mean
        # (`cold_plate.exam._ulp`: ULP_FACTOR * F32_EPS * max(1, |v|)).
        size = torch.abs(hottest)
        ulp = torch.where(size > 1.0, size, size * 0 + 1.0) * (ULP_FACTOR * F32_EPS)
        excess = peak - hottest
        excess = torch.where(excess > ulp, excess, ulp)
        pressure = torch.exp(logs[:, -1:])
        return torch.cat(
            [inverse_softplus(excess), profile, inverse_softplus(pressure)], dim=1
        )

    parameters = [torch.from_numpy(x), torch.from_numpy(alpha)]
    return {"framework": "torch", "apply": apply, "parameters": parameters}
