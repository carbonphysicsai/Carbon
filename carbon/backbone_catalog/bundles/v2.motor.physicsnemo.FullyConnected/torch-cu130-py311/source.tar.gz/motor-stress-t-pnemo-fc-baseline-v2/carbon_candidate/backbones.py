"""Open-source operator backbones adapted to Motor's job (8 inputs -> a 60-point
torque curve), for the backbone coverage matrix (DEVELOPMENT examples).

Each entry builds a fresh, untrained `torch.nn.Module` mapping a (cases, 8)
float tensor to (cases, 60). Grid operators see the case's inputs broadcast over
the curve's grid plus the grid coordinate (a 1-D function with 9 channels);
2-D-only backbones see the 60 points as a 6 x 10 grid. Nothing is downloaded or
pretrained. The adapter is stated per entry so a result can be read honestly.
"""

from __future__ import annotations

import torch

POINTS = 60
GRID_2D = (6, 10)


class OnGrid(torch.nn.Module):
    """(n, k) inputs -> (n, k + 1, 60) [or (n, k + dims, 6, 10)] -> backbone -> (n, 60)."""

    def __init__(self, backbone, n_in, two_d=False, channels_last=False):
        super().__init__()
        self.backbone, self.two_d, self.channels_last = backbone, two_d, channels_last
        if two_d:
            a = torch.linspace(0.0, 1.0, GRID_2D[0])
            b = torch.linspace(0.0, 1.0, GRID_2D[1])
            yy, xx = torch.meshgrid(a, b, indexing="ij")
            self.register_buffer("coords", torch.stack([yy, xx]).unsqueeze(0))
        else:
            self.register_buffer("coords", torch.linspace(0.0, 1.0, POINTS).view(1, 1, POINTS))

    def forward(self, x):
        n, k = x.shape
        x = x.to(self.coords.dtype)
        if self.two_d:
            feats = x.view(n, k, 1, 1).expand(n, k, *GRID_2D)
            grid = torch.cat([feats, self.coords.expand(n, -1, -1, -1)], dim=1)
        else:
            feats = x.view(n, k, 1).expand(n, k, POINTS)
            grid = torch.cat([feats, self.coords.expand(n, -1, -1)], dim=1)
        if self.channels_last:
            grid = grid.movedim(1, -1)
        out = self.backbone(grid)
        if isinstance(out, (tuple, list)):
            out = out[0]
        if self.channels_last:
            out = out.movedim(-1, 1)
        return out.reshape(n, -1)[:, :POINTS]


def _neuralop(name, n_in, **kw):
    import neuralop.models as m

    if not hasattr(m, name):
        # neuralop 2.0 exports LocalNO and SFNO only when torch-harmonics is installed,
        # which the Torch build base does not ship: a dependency limit.
        raise ImportError(f"neuralop.models.{name} needs torch-harmonics, not in the Torch build base")
    return getattr(m, name)(**kw)


def _registry(n_in):
    c = n_in + 1  # channels on the 1-D grid
    c2 = n_in + 2  # channels on the 2-D grid
    return {
        # --- neuraloperator 2.0 -------------------------------------------
        "neuralop.FNO": lambda: OnGrid(
            _neuralop("FNO", n_in, n_modes=(16,), hidden_channels=32, in_channels=c, out_channels=1, n_layers=4), n_in),
        "neuralop.TFNO": lambda: OnGrid(
            _neuralop("TFNO", n_in, n_modes=(16,), hidden_channels=32, in_channels=c, out_channels=1, n_layers=4,
                      factorization="tucker", rank=0.42), n_in),
        "neuralop.UNO": lambda: OnGrid(
            _neuralop("UNO", n_in, in_channels=c, out_channels=1, hidden_channels=32, n_layers=3,
                      uno_out_channels=[32, 32, 32], uno_n_modes=[[8], [8], [8]],
                      uno_scalings=[[1.0], [1.0], [1.0]], channel_mlp_skip="linear",
                      positional_embedding=None), n_in),
        "neuralop.LocalNO": lambda: OnGrid(
            _neuralop("LocalNO", n_in, n_modes=(16,), in_channels=c, out_channels=1, hidden_channels=32,
                      n_layers=4, default_in_shape=(POINTS,)), n_in),
        "neuralop.SFNO": lambda: OnGrid(
            _neuralop("SFNO", n_in, n_modes=GRID_2D, hidden_channels=32, in_channels=c2, out_channels=1,
                      n_layers=4), n_in, two_d=True),
        # CODANO's attention normalises 2-D+ fields (instance norm), so it sees the 6 x 10
        # grid; each input channel is one of its variables.
        "neuralop.CODANO": lambda: OnGrid(
            _neuralop("CODANO", n_in, output_variable_codimension=1, hidden_variable_codimension=8,
                      lifting_channels=16, use_positional_encoding=False, n_layers=2,
                      n_heads=[2, 2], n_modes=[[3, 4], [3, 4]], per_layer_scaling_factors=[[1.0, 1.0], [1.0, 1.0]],
                      attention_scaling_factors=[1.0, 1.0]), n_in, two_d=True),
        # UQNO trains in two stages (a frozen base FNO, then a residual FNO for the
        # uncertainty ball); its forward runs the base under no_grad. The adapter
        # trains and deploys stage 1, the solution head, so UQNO's operators are FNO's.
        "neuralop.UQNO": lambda: OnGrid(
            _UQNOSolution(_neuralop("UQNO", n_in,
                      base_model=_neuralop("FNO", n_in, n_modes=(16,), hidden_channels=16, in_channels=c,
                                           out_channels=1, n_layers=2),
                      residual_model=_neuralop("FNO", n_in, n_modes=(16,), hidden_channels=16, in_channels=c,
                                               out_channels=1, n_layers=2))), n_in),
        # GINO on Motor's curve as a 1-D point cloud: the 60 grid points are both the
        # input geometry and the output queries, a 16-point latent grid in between,
        # neighbour search in plain torch (no open3d / torch_scatter).
        "neuralop.GINO": lambda: _GINOOnCurve(c),
        # --- PhysicsNeMo 2.2 -----------------------------------------------
        "physicsnemo.FNO": lambda: OnGrid(_physicsnemo_fno(c), n_in),
        "physicsnemo.AFNO": lambda: OnGrid(_physicsnemo_afno(c2), n_in, two_d=True),
        "physicsnemo.FullyConnected": lambda: _physicsnemo_mlp(n_in),
        "physicsnemo.MeshGraphNet": lambda: _physicsnemo_meshgraphnet(c),
        # --- KAN ------------------------------------------------------------
        # No KAN library is in the Torch build base: the B-spline KAN layer is
        # written here from the efficient-KAN algorithm (SiLU base branch plus a
        # learned spline over a fixed uniform grid), a direct 8 -> 60 map.
        "kan.EfficientKAN": lambda: _Flat(torch.nn.Sequential(KANLayer(n_in, 16), KANLayer(16, POINTS))),
    }


class _UQNOSolution(torch.nn.Module):
    def __init__(self, uqno):
        super().__init__()
        self.uqno = uqno

    def forward(self, x):
        return self.uqno.base_model(x)


class _GINOOnCurve(torch.nn.Module):
    def __init__(self, c):
        super().__init__()
        import neuralop.models as m

        self.gino = m.GINO(in_channels=c, out_channels=1, gno_coord_dim=1, in_gno_radius=0.1,
                           out_gno_radius=0.1, fno_n_modes=(8,), fno_hidden_channels=32, fno_n_layers=2,
                           fno_in_channels=c, gno_embed_channels=16,
                           in_gno_channel_mlp_hidden_layers=[32, 32], out_gno_channel_mlp_hidden_layers=[32, 32],
                           gno_use_open3d=False, gno_use_torch_scatter=False)
        self.register_buffer("points", torch.linspace(0.0, 1.0, POINTS).view(1, POINTS, 1))
        self.register_buffer("latent", torch.linspace(0.0, 1.0, 16).view(1, 16, 1))

    def forward(self, x):
        n, k = x.shape
        x = x.to(self.points.dtype)
        feats = torch.cat([x.view(n, 1, k).expand(n, POINTS, k), self.points.expand(n, -1, -1)], dim=-1)
        out = self.gino(self.points, self.latent, self.points, x=feats)
        return out.reshape(n, POINTS)


def _physicsnemo_fno(c):
    from physicsnemo.models.fno import FNO

    return FNO(in_channels=c, out_channels=1, decoder_layers=1, decoder_layer_size=32, dimension=1,
               latent_channels=32, num_fno_layers=4, num_fno_modes=16, padding=8)


def _physicsnemo_afno(c2):
    from physicsnemo.models.afno import AFNO

    return AFNO(inp_shape=list(GRID_2D), in_channels=c2, out_channels=1, patch_size=[2, 2],
                embed_dim=32, depth=2, num_blocks=4)


class KANLayer(torch.nn.Module):
    """y = W_b silu(x) + W_s B(x): B the order-3 B-spline basis on a fixed
    uniform grid over [-2, 2] (Cox-de Boor recursion), as efficient-KAN."""

    def __init__(self, n_in, n_out, grid=5, order=3):
        super().__init__()
        h = 4.0 / grid
        knots = torch.arange(-order, grid + order + 1, dtype=torch.float32) * h - 2.0
        self.register_buffer("knots", knots)
        self.order = order
        self.base = torch.nn.Linear(n_in, n_out)
        self.spline = torch.nn.Parameter(torch.randn(n_out, n_in, grid + order) * 0.1)

    def basis(self, x):
        g = self.knots
        x = x.unsqueeze(-1)
        b = ((x >= g[:-1]) & (x < g[1:])).to(x.dtype)
        for k in range(1, self.order + 1):
            b = (x - g[: -(k + 1)]) / (g[k:-1] - g[: -(k + 1)]) * b[..., :-1] + (
                g[k + 1 :] - x
            ) / (g[k + 1 :] - g[1:-k]) * b[..., 1:]
        return b  # (n, n_in, grid + order)

    def forward(self, x):
        return self.base(torch.nn.functional.silu(x)) + torch.einsum("nik,oik->no", self.basis(x), self.spline)


class _Flat(torch.nn.Module):
    def __init__(self, inner):
        super().__init__()
        self.inner = inner

    def forward(self, x):
        return self.inner(x)


def _physicsnemo_mlp(n_in):
    from physicsnemo.models.mlp import FullyConnected

    return _Flat(FullyConnected(in_features=n_in, layer_size=64, out_features=POINTS, num_layers=4))


def _physicsnemo_meshgraphnet(c):
    # PhysicsNeMo 2.2's MeshGraphNet message passing needs torch_geometric (PyG),
    # which the Torch build base does not ship: a dependency limit, recorded as such.
    from physicsnemo.nn.module.gnn_layers.utils import PYG_AVAILABLE

    if not PYG_AVAILABLE:
        raise ImportError("MeshGraphNet needs torch_geometric, not in the Torch build base")
    from physicsnemo.models.meshgraphnet import MeshGraphNet

    return MeshGraphNet(input_dim_nodes=c, input_dim_edges=1, output_dim=1, processor_size=2,
                        hidden_dim_node_encoder=16, hidden_dim_edge_encoder=16, hidden_dim_node_decoder=16)


NAMES = tuple(_registry(8))


def build_backbone(name, n_in):
    """The named backbone as a fresh module, or `KeyError`."""
    return _registry(n_in)[name]()
