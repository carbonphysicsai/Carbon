"""THUML Neural-Solver-Library backbones on Motor's job (packs lane, DEVELOPMENT).

Each entry builds a fresh, untrained `torch.nn.Module` mapping (cases, 8) Motor
inputs to (cases, 60) torque points, using the library's own model classes
unmodified: the upstream tree (commit db942b7, MIT licence) is vendored beside
this module and every file is sha256-checked before import. Models are
constructed exactly as the library's `run.py` does, `Model(args)`, from its
documented argument defaults with only the problem's shape overridden. The 60
curve points are the mesh (space dim 1, position in [0, 1]); every point carries
the case's 8 inputs as its observed function. `structured_1D` entries treat the
60 points as a regular 1-D grid; `unstructured` entries as a point cloud (for
FNO that is the library's Geo-FNO projection). Nothing is downloaded or
pretrained. Same registry shape as Launchpad's `backbones.py`.
"""

from __future__ import annotations

import contextlib
import hashlib
import importlib
import sys
from pathlib import Path
from types import SimpleNamespace

import torch

POINTS = 7  # this Challenge's outputs
LIBRARY = "neural-solver-library-db942b7"
SOURCE_HASHES = {
    "layers/Basic.py": "f5315fa5148ed0401b35b263dd3451b92581080a134d7e1a8ce1acb1f7d63b26",
    "layers/Embedding.py": "135678a3058155be4f000233dd2010b8bfd020e8a16e0cc80acce335e5191741",
    "layers/FFNO_Layers.py": "24ef13cc49298a0c71c492003a0ed0b212327e4b8f89e859d9675604cca492c3",
    "layers/FNO_Layers.py": "19f69d6cdf714c77476002a52a6fdece0a4bafe083f8e0a086f41412e2d133cd",
    "layers/GeoFNO_Projection.py": "8e6f84466cdf8d2c06e478a9f993953c96ae45fe3776c7d9611037596d0b162f",
    "layers/MWT_Layers.py": "1b251447e22f2c229e625b8291c4aaf640d2e1e894a9d05f9d29036e77991d12",
    "layers/Neural_Spectral_Block.py": "678f0dc429830f95e0a3bd02154088c297870b5a035290c293690b2118276d64",
    "layers/UNet_Blocks.py": "6b4c394dfd53afc3750f3a4e4a03cca6088a19beee588c37f334677cb66773c5",
    "models/FNO.py": "297beafbe0a9640cc6670b134fb7286c3e2a7248f0eff6d060ae286a9102b040",
    "models/F_FNO.py": "03c8525abf6dbf5754561b049aafadd7e554b61edeec27abba337b80b4968430",
    "models/Factformer.py": "dc02a43acade23b0bbf3896d7a7a9f4130acf4faee3113677618495e7a604607",
    "models/GNOT.py": "5657dd7be52f6da16a76551dcc4cc032e1346163eddedd12d706bd6bb03190dd",
    "models/Galerkin_Transformer.py": "885e06bfa9d8b119671e4d9e9dda6fecc7120d8b407bfc42f579d8be898d6292",
    "models/LSM.py": "0e4a1f2fc8db1e30b4dd7f2aee74f7d2a72e63d57d116a909527f95a293c3ac4",
    "models/MWT.py": "f96f166ce804c4738020264d546bb204365ce389847c3f62522d5e018a97155a",
    "models/ONO.py": "dcee17e3637ee735829a736b336779750220b6e5e8252eca4a45879ec6d7ad1a",
    "models/Transformer.py": "71eff776e1209910126517bdefee809c2c0c67830a04ee9acecb542875ba0bad",
    "models/U_FNO.py": "44b275acdb94a1e16142400e51048d6c1e3cb50d78c7f26caf02307b8d3737ba",
    "models/U_NO.py": "9ba2b4cefe3abfe06c9624e9a6898532c7f37e38d2df44c9ac1a5cf7e44342e7",
    "models/U_Net.py": "cf7f140f1d9c3670b22ccd13c6246b057b63cb7a034eccdb0f30eed0407ddaa1",
    "models/Transolver.py": "6d4281397733cd89d209c94e8c2b73952c13ee880b9408ac25c41b6dca6b85b5",
    "layers/Physics_Attention.py": "ae344a0dbc99b755a2ff6afaebaf8ad0969ba7e7ea9ac2ae6665b66d039d1f0d",
}
#: The library's run.py argument defaults (only those its models read).
DEFAULTS = {
    "act": "gelu",
    "attn_type": "nystrom",
    "dropout": 0.0,
    "mlp_ratio": 1,
    "modes": 3,  # at most half this Challenge outputs
    "mwt_k": 3,
    "n_heads": 4,
    "n_hidden": 64,
    "n_layers": 3,
    "num_output_tokens": 1024,
    "psi_dim": 8,
    "ref": 8,
    "slice_num": 32,
    "task": "steady",
    "time_input": False,
    "unified_pos": 0,
}


def _root() -> Path:
    here = Path(__file__).resolve().parent
    for candidate in (here.parent / LIBRARY, here.parent / "vendor" / LIBRARY):
        if candidate.is_dir():
            return candidate
    raise RuntimeError("vendored Neural-Solver-Library tree not found")


@contextlib.contextmanager
def _cpu_construction():
    """Build upstream code that hard-codes CUDA at construction (`device="cuda"`
    in `torch.tensor` / `torch.arange`, and `Tensor.cuda()`), on whatever device
    the host has: those tensors are created on the CPU, and `_follow_module`
    then makes them move with the module. Upstream files stay byte-identical."""
    real_tensor, real_arange, real_cuda = torch.tensor, torch.arange, torch.Tensor.cuda

    def retarget(real):
        def call(*args, **kwargs):
            if kwargs.get("device") == "cuda":
                kwargs = {**kwargs, "device": "cpu"}
            return real(*args, **kwargs)

        return call

    torch.tensor, torch.arange = retarget(real_tensor), retarget(real_arange)
    torch.Tensor.cuda = lambda self, *args, **kwargs: self
    try:
        yield
    finally:
        torch.tensor, torch.arange, torch.Tensor.cuda = real_tensor, real_arange, real_cuda


def _follow_module(model):
    """Plain tensor attributes (upstream keeps constants as bare attributes) become
    non-persistent buffers, so `.to(device)` / `.double()` move them with the module
    and the module's state_dict is unchanged."""
    for module in model.modules():
        for name, value in list(vars(module).items()):
            if isinstance(value, torch.Tensor) and not isinstance(value, torch.nn.Parameter):
                delattr(module, name)
                module.register_buffer(name, value, persistent=False)
    return model


def _freeze_iphi(model, positions):
    """`model.iphi` (Geo-FNO's deformation network) for the fixed query `positions`
    (1, n, 2): its angle and radius features, which depend only on the positions, become
    buffers; every other line of the forward is upstream's."""
    iphi = model.iphi
    angle = torch.atan2(positions[:, :, 1] - iphi.center[:, :, 1], positions[:, :, 0] - iphi.center[:, :, 0])
    radius = torch.norm(positions - iphi.center, dim=-1, p=2)

    class FrozenIPHI(type(iphi)):
        def forward(self, x, code=None):
            assert x.shape[1:] == self.positions.shape[1:], "the deformation features are built for the curve"
            xd = torch.stack(
                [x[:, :, 0], x[:, :, 1], self.angle.expand(x.shape[0], -1), self.radius.expand(x.shape[0], -1)],
                dim=-1,
            )
            b, n, d = xd.shape[0], xd.shape[1], xd.shape[2]
            x_sin = torch.sin(self.B * xd.view(b, n, d, 1)).view(b, n, d * self.width // 4)
            x_cos = torch.cos(self.B * xd.view(b, n, d, 1)).view(b, n, d * self.width // 4)
            xd = self.fc0(xd)
            xd = torch.cat([xd, x_sin, x_cos], dim=-1).reshape(b, n, 3 * self.width)
            if code is not None:
                cd = self.fc_code(code)
                cd = cd.unsqueeze(1).repeat(1, xd.shape[1], 1)
                xd = torch.cat([cd, xd], dim=-1)
            else:
                xd = self.fc_no_code(xd)
            xd = self.activation(self.fc1(xd))
            xd = self.activation(self.fc2(xd))
            xd = self.activation(self.fc3(xd))
            xd = self.fc4(xd)
            return x + x * xd

    iphi.__class__ = FrozenIPHI
    iphi.register_buffer("positions", positions.clone(), persistent=False)
    iphi.register_buffer("angle", angle, persistent=False)
    iphi.register_buffer("radius", radius, persistent=False)
    return model


def _freeze_irregular(model, module):
    """`fftproject_in` / `fftproject_out` (Geo-FNO's NUFFT-style projections) with their Fourier
    basis written in real arithmetic; weights, slicing and the spectral multiply are upstream's."""
    base = module.SpectralConv2d_IrregularGeo

    class FrozenIrregular(base):
        def _phase(self, x):
            k = x[..., 0].unsqueeze(-1).unsqueeze(-1) * self.k1 + x[..., 1].unsqueeze(-1).unsqueeze(-1) * self.k2
            return 2 * torch.pi * k

        def fft2d(self, u, x_in, iphi=None, code=None):
            x = x_in if iphi is None else iphi(x_in, code)
            phase = self._phase(x)  # (batch, N, m1, m2)
            real = torch.einsum("bcn,bnxy->bcxy", u, torch.cos(phase))
            imag = -torch.einsum("bcn,bnxy->bcxy", u, torch.sin(phase))
            return torch.view_as_complex(torch.stack([real, imag], dim=-1))

        def ifft2d(self, u_ft, x_out, iphi=None, code=None):
            x = x_out if iphi is None else iphi(x_out, code)
            phase = self._phase(x)
            parts = torch.view_as_real(u_ft)
            re, im = parts[..., 0], parts[..., 1]
            # the conjugate-symmetric half: u_ft[..., 1:] flipped over its last two dims, conjugated
            re2 = re[..., 1:].index_select(-2, self.flip_x).index_select(-1, self.flip_y)
            im2 = -im[..., 1:].index_select(-2, self.flip_x).index_select(-1, self.flip_y)
            re, im = torch.cat([re, re2], dim=-1), torch.cat([im, im2], dim=-1)
            return torch.einsum("bcxy,bnxy->bcn", re, torch.cos(phase)) - torch.einsum(
                "bcxy,bnxy->bcn", im, torch.sin(phase)
            )

    for projection in (model.fftproject_in, model.fftproject_out):
        m1, m2 = 2 * projection.modes1, 2 * projection.modes2 - 1
        k1 = torch.cat((torch.arange(0, projection.modes1), torch.arange(-projection.modes1, 0))).reshape(m1, 1).repeat(1, m2)
        k2 = torch.cat((torch.arange(0, projection.modes2), torch.arange(-(projection.modes2 - 1), 0))).reshape(1, m2).repeat(m1, 1)
        projection.__class__ = FrozenIrregular
        projection.register_buffer("k1", k1.to(torch.float32), persistent=False)
        projection.register_buffer("k2", k2.to(torch.float32), persistent=False)
        projection.register_buffer("flip_x", torch.arange(m1 - 1, -1, -1), persistent=False)
        projection.register_buffer("flip_y", torch.arange(projection.modes2 - 2, -1, -1), persistent=False)
    return model


def _model_class(name: str):
    root = _root()
    for relative, expected in SOURCE_HASHES.items():
        if hashlib.sha256((root / relative).read_bytes()).hexdigest() != expected:
            raise RuntimeError("pinned Neural-Solver-Library source differs: " + relative)
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))  # upstream imports `models.*` and `layers.*`
    return importlib.import_module(f"models.{name}").Model


_EXACT_MAX = [False]


def _tree_max(t):
    """The largest element of `t`, as the same value `torch.max(t)` returns, built
    from slices, a comparison and `where` only."""
    t = t.reshape(-1)
    while t.shape[0] > 1:
        half = t.shape[0] // 2
        a, b, rest = t[:half], t[half : 2 * half], t[2 * half :]
        t = torch.cat([torch.where(a > b, a, b), rest])
    return t[0]


def _nystrom_with_graph_max():
    """Route the wheel's `moore_penrose_iter_pinv` through `_tree_max` while the frozen
    eval path runs (`_EXACT_MAX`); every other call is the wheel's own function."""
    import nystrom_attention.nystrom_attention as wheel

    if getattr(wheel, "_carbon_routed", False):
        return
    original = wheel.moore_penrose_iter_pinv

    def pinv(x, iters=6):
        if not _EXACT_MAX[0]:
            return original(x, iters)
        abs_x = torch.abs(x)
        col, row = abs_x.sum(dim=-1), abs_x.sum(dim=-2)
        z = x.transpose(-1, -2) / (_tree_max(col) * _tree_max(row))
        # a constant identity: `torch.eye` decomposes to a uint16 arange, a dtype graphs do not carry
        identity = torch.as_tensor(__import__("numpy").eye(x.shape[-1], dtype="float32")).to(x.dtype).unsqueeze(0)
        for _ in range(iters):
            xz = x @ z
            z = 0.25 * z @ (13 * identity - (xz @ (15 * identity - (xz @ (7 * identity - xz)))))
        return z

    wheel.moore_penrose_iter_pinv = pinv
    wheel._carbon_routed = True


def _freeze_ono(model, module):
    """Give each ONO block an eval path that reads the inverse Cholesky factor of its
    running feature covariance from a buffer computed once at `.eval()`, instead of
    recomputing it in the forward (upstream: `psd_safe_cholesky(feature_cov)` and
    `.inverse()` with a data-dependent NaN check). Training mode is upstream's forward."""
    upstream = module.ONOBlock
    if getattr(model.args, "attn_type", None) == "nystrom":
        _nystrom_with_graph_max()

    class FrozenCovBlock(upstream):
        def train(self, mode=True):
            super().train(mode)
            if not mode and self.feature_cov is not None:
                factor = module.psd_safe_cholesky(self.feature_cov.detach())
                self.register_buffer("l_inv_t", factor.inverse().transpose(-2, -1).contiguous(), persistent=False)
            return self

        def forward(self, x, fx):
            if self.training or getattr(self, "l_inv_t", None) is None:
                return super().forward(x, fx)
            _EXACT_MAX[0] = True
            try:
                x = self.Attn(self.ln_1(x)) + x
            finally:
                _EXACT_MAX[0] = False
            x = self.mlp(self.ln_2(x)) + x
            x_ = self.proj(x) @ self.l_inv_t
            fx = (x_ * torch.nn.functional.softplus(self.mu)) @ (x_.transpose(-2, -1) @ fx) + fx
            fx = self.mlp2(self.ln_3(fx))
            return x, fx

    for block in model.modules():
        if type(block) is upstream:
            block.__class__ = FrozenCovBlock
    return model


class OnCurve(torch.nn.Module):
    """(n, 8) -> library model over the 60-point curve -> (n, 60)."""

    def __init__(self, model, grid=POINTS, lift=1):
        super().__init__()
        self.model = model
        if grid == POINTS:
            positions = torch.linspace(0.0, 1.0, POINTS)
        else:
            # Extended curve: Motor's 60 points, then further points at the same
            # spacing; the output keeps only the first 60.
            positions = torch.arange(grid, dtype=torch.float32) / (POINTS - 1)
        # `lift` 2: the library's Geo-FNO projection is defined on 2-D point clouds
        # (locations in [0, 1]^2), so the curve is laid along the unit square's
        # diagonal, position s -> (s, s); its learned deformation moves each
        # coordinate separately, so the second axis does not collapse.
        self.register_buffer("grid", positions.view(1, grid, 1).expand(1, grid, lift).contiguous())

    def forward(self, x):
        n, points = x.shape[0], self.grid.shape[1]
        x = x.to(self.grid.dtype)
        positions = self.grid.expand(n, points, self.grid.shape[2])
        features = x.unsqueeze(1).expand(n, points, x.shape[1])
        return self.model(positions, features)[:, :POINTS, 0]


def _library(name, n_in, geotype, **overrides):
    """`grid` (an adapter setting, not a library argument) runs the model on a
    longer 1-D grid. Upstream db942b7 computes 1-D padding for U-Net, U-FNO,
    U-NO and MWT but applies it only for 2-D and 3-D meshes, so a 60-point
    curve breaks their down/up-sampling (U-models need a multiple of 16, MWT a
    power of 2). Those run on 64 points: Motor's 60 plus 4 beyond the end."""
    grid = overrides.pop("grid", POINTS)
    lift = overrides.pop("lift", 1)
    args = SimpleNamespace(
        **{**DEFAULTS, **overrides},
        model=name,
        geotype=geotype,
        space_dim=lift,
        fun_dim=n_in,
        out_dim=1,
        shapelist=[grid] if geotype == "structured_1D" else None,
    )
    with _cpu_construction():
        model = _model_class(name)(args)
    if name == "ONO":
        model = _freeze_ono(model, sys.modules["models.ONO"])
    if name == "FNO" and geotype == "unstructured":
        model = _freeze_iphi(model, torch.linspace(0.0, 1.0, grid).view(1, grid, 1).expand(1, grid, lift).contiguous())
        model = _freeze_irregular(model, sys.modules["layers.GeoFNO_Projection"])
    return OnCurve(_follow_module(model), grid=grid, lift=lift)


#: (library model, geometry type, overrides). Sizes stay small so a rebuild is
#: minutes on CPU; overrides only change capacity, never the method.
ENTRIES = {
    "thuml.FNO": ("FNO", "structured_1D", {"n_hidden": 32}),
    "thuml.GeoFNO": ("FNO", "unstructured", {"n_hidden": 32, "lift": 2}),
    "thuml.F_FNO": ("F_FNO", "structured_1D", {"n_hidden": 32}),
    "thuml.U_FNO": ("U_FNO", "structured_1D", {"n_hidden": 32, "grid": 64}),
    "thuml.U_NO": ("U_NO", "structured_1D", {"n_hidden": 32, "grid": 64}),
    "thuml.MWT": ("MWT", "structured_1D", {"n_hidden": 32, "grid": 64}),
    "thuml.LSM": ("LSM", "structured_1D", {"n_hidden": 16, "grid": 64, "task": "dynamic"}),
    "thuml.U_Net": ("U_Net", "structured_1D", {"n_hidden": 32, "grid": 64}),
    "thuml.GNOT": ("GNOT", "unstructured", {"n_hidden": 32}),
    "thuml.Galerkin_Transformer": ("Galerkin_Transformer", "unstructured", {"n_hidden": 32}),
    "thuml.Transformer": ("Transformer", "unstructured", {"n_hidden": 32}),
    "thuml.Factformer": ("Factformer", "structured_1D", {"n_hidden": 32}),  # refuses unstructured
    "thuml.ONO": ("ONO", "unstructured", {"n_hidden": 32}),
    "thuml.Transolver": ("Transolver", "unstructured", {"n_hidden": 32, "slice_num": 8}),
}


# --- Batch 2: other upstream research codes (pinned commits, vendored) -------
#: (vendored dir, {file: sha256}). Each tree keeps its own upstream LICENSE.
UPSTREAM = {
    "cno-6e76519": {  # camlab-ethz/ConvolutionalNeuralOperator, MIT
        "LICENSE": "687a617aa02794f450a493bccab173fa2da18c5973761b79b3170747266c7d90",
        "CNO1d_simplified/CNO1d.py": "628b4109da7a17c68bba5b9cc97fe27d6f8f891f35d7e56b759766388a68c82e",
    },
    "lno-78c64ef": {  # qianyingcao/Laplace-Neural-Operator, MIT
        "LICENSE": "6c0bb34f39076b7c40c792c6253e4f589484e95fb546a1f24a2aa02d6820fc62",
        "1D_Pendulum_c0/main.py": "a9e20ea59c29f14ddcf6411c3443c449eb88fafa79d98bbbcd1122ce661b0b1e",
    },
    "oformer-f1111b3": {  # BaratiLab/OFormer, MIT
        "LICENSE": "fccaaedad8a1e8803e37b260a376d918b9a9fa6c940ffc09df158a8f592d81a2",
        "uniform_grids/nn_module/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "uniform_grids/nn_module/attention_module.py": "4cf124a9d5f2f6688408c88c269e3185190e33290c5c5284791f9827dda08c8f",
        "uniform_grids/nn_module/cnn_module.py": "11fcbfd7398a0e3f6763362c944eb719d8cd3fde3e820dcfb28146b18f575fcf",
        "uniform_grids/nn_module/decoder_module.py": "f6581892938c9a27cc2f3e49e35eb9e32385fef527affd9642dfa8453366a11b",
        "uniform_grids/nn_module/encoder_module.py": "a0bcf389718de4f271609d39fa53c5edd30612c743fdbac6e3572ab487741547",
    },
}


def _tree(name: str) -> Path:
    here = Path(__file__).resolve().parent
    for root in (here.parent / name, here.parent / "vendor" / name):
        if root.is_dir():
            for relative, expected in UPSTREAM[name].items():
                if hashlib.sha256((root / relative).read_bytes()).hexdigest() != expected:
                    raise RuntimeError(f"pinned {name} source differs: {relative}")
            return root
    raise RuntimeError(f"vendored {name} tree not found")


def _file_module(path: Path, name: str):
    """Import one pinned upstream file, keeping the caller's RNG state (some
    upstream modules reseed torch at import)."""
    import importlib.util

    state = torch.random.get_rng_state()
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    torch.random.set_rng_state(state)
    return module


class OnGrid(torch.nn.Module):
    """(n, k) -> channels-first (n, k + 1, 60) or channels-last (n, 60, k + 1)
    grid of the case's inputs plus the coordinate -> backbone -> (n, 60).
    Same adapter as Launchpad's `backbones.OnGrid` (1-D case); a tuple output
    takes its first element; a multi-channel output takes channel 0."""

    def __init__(self, backbone, channels_last=False):
        super().__init__()
        self.backbone, self.channels_last = backbone, channels_last
        self.register_buffer("coords", torch.linspace(0.0, 1.0, POINTS).view(1, 1, POINTS))

    def forward(self, x):
        n, k = x.shape
        x = x.to(self.coords.dtype)
        grid = torch.cat([x.view(n, k, 1).expand(n, k, POINTS), self.coords.expand(n, -1, -1)], dim=1)
        if self.channels_last:
            grid = grid.movedim(1, -1)
        out = self.backbone(grid)
        if isinstance(out, (tuple, list)):
            out = out[0]
        if self.channels_last:
            out = out.movedim(-1, 1)
        return out[:, 0, :]


def _cno(n_in):
    module = _file_module(_tree("cno-6e76519") / "CNO1d_simplified" / "CNO1d.py", "dc_cno1d")
    return OnGrid(module.CNO1d(in_dim=n_in + 1, out_dim=1, size=POINTS, N_layers=2,
                               N_res=2, N_res_neck=2, channel_multiplier=16))


class _OFormer(torch.nn.Module):
    """OFormer's own 1-D encoder + point-wise decoder, as its train_burgers.py
    pairs them: encode the input points, decode at the query points."""

    def __init__(self, encoder, decoder):
        super().__init__()
        self.encoder, self.decoder = encoder, decoder

    def forward(self, grid):  # (n, 60, k + 1), last channel the coordinate
        pos = grid[..., -1:]
        z = self.encoder(grid, pos)
        return self.decoder(z, pos, pos)


def _absent_fourier_module():
    """Upstream finding: OFormer f1111b3's uniform_grids/nn_module/cnn_module.py
    imports `.fourier_neural_operator`, a file absent from that commit, so the
    package cannot import as published. Only the 2-D FourierConv2d uses it; the
    1-D Encoder1D / PointWiseDecoder1D never do. Stand in a module whose class
    refuses construction, so any use of the missing code fails loudly."""
    import types

    importlib.import_module("nn_module")
    name = "nn_module.fourier_neural_operator"
    if name in sys.modules:
        return

    class SpectralConv2d_fast:  # noqa: N801 - upstream's name
        def __init__(self, *args, **kwargs):
            raise RuntimeError("OFormer f1111b3 lacks fourier_neural_operator.py")

    stand_in = types.ModuleType(name)
    stand_in.SpectralConv2d_fast = SpectralConv2d_fast
    sys.modules[name] = stand_in
    sys.modules["nn_module"].fourier_neural_operator = stand_in


def _oformer(n_in):
    root = _tree("oformer-f1111b3") / "uniform_grids"
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))  # upstream imports the `nn_module` package
    _absent_fourier_module()
    state = torch.random.get_rng_state()
    encoder_module = importlib.import_module("nn_module.encoder_module")
    decoder_module = importlib.import_module("nn_module.decoder_module")
    torch.random.set_rng_state(state)
    encoder = encoder_module.Encoder1D(n_in + 1, 32, 32, 4, res=POINTS)
    decoder = decoder_module.PointWiseDecoder1D(32, 1, 3, scale=2, res=POINTS)
    return OnGrid(_OFormer(encoder, decoder), channels_last=True)


def _lno(n_in):
    """The upstream PR and LNO1d classes, executed unmodified from the pinned
    research script (its module-level data loading and training are not run).
    Upstream PR.forward reads a global `grid_x_train` and calls `.cuda()`: the
    adapter supplies Motor's 60-point grid as that global and a learned
    8 -> 1 projection, because LNO1d takes one input channel. The two `.cuda()`
    calls become `.to(x.device)`, so the model runs on the host's device."""
    import ast

    import numpy as np

    path = _tree("lno-78c64ef") / "1D_Pendulum_c0" / "main.py"
    tree = ast.parse(path.read_text(encoding="utf-8"))
    keep = [n for n in tree.body if isinstance(n, ast.ClassDef) and n.name in ("PR", "LNO1d")]

    class Retarget(ast.NodeTransformer):
        """`t.cuda()` -> `t.to(x.device)` inside PR.forward(self, x): the tensor
        goes where the input is (the host's device), not to CUDA unconditionally."""

        count = 0
        folded = 0
        dft = 0

        def visit_Assign(self, node):
            self.generic_visit(node)
            if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == "lambda0":
                node.value = ast.Name("_lambda0", ast.Load())  # fftfreq(60, dt) * 2 pi i, a constant of the grid
                self.dft += 1
            if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == "dt":
                grid = torch.linspace(0.0, 1.0, POINTS)
                node.value = ast.Constant(float((grid[1] - grid[0]).item()))  # the same float32 step, as a constant
                self.folded += 1
            return node

        def visit_Call(self, node):
            self.generic_visit(node)
            name = ast.unparse(node.func)
            if name == "torch.fft.fft":
                node.func = ast.Name("_dft", ast.Load())
                self.dft += 1
            elif name == "torch.fft.ifft":
                node.func = ast.Name("_idft_real", ast.Load())
                node.keywords = []  # n=x.size(-1) is the grid length
                self.dft += 1
            if isinstance(node.func, ast.Attribute) and node.func.attr == "cuda" and not node.args:
                self.count += 1
                node.func.attr = "to"
                node.args = [ast.Attribute(ast.Name("x", ast.Load()), "device", ast.Load())]
            return node

    retarget = Retarget()
    keep = [ast.fix_missing_locations(retarget.visit(n)) for n in keep]
    assert (retarget.count, retarget.folded, retarget.dft) == (2, 1, 3), (retarget.count, retarget.folded, retarget.dft)
    def _mats():  # the DFT's cos/sin matrices, computed in the graph from an arange (float64, then float32), not carried as 2 x 14 KiB of constants
        k = torch.arange(POINTS, dtype=torch.float64)
        angle = (2 * np.pi / POINTS) * (k.view(-1, 1) * k.view(1, -1))
        return torch.cos(angle).to(torch.float32), torch.sin(angle).to(torch.float32)

    step = float((torch.linspace(0.0, 1.0, POINTS)[1] - torch.linspace(0.0, 1.0, POINTS)[0]).item())
    lambda0 = torch.tensor(np.fft.fftfreq(POINTS, step) * 2 * np.pi * 1j, dtype=torch.complex64)

    def _dft(x):  # torch.fft.fft of a real signal over its last axis, as a DFT matrix product
        cos_m, sin_m = _mats()
        return torch.view_as_complex(torch.stack([x @ cos_m, -(x @ sin_m)], dim=-1))

    def _idft_real(z):  # Re(torch.fft.ifft(z)): the inverse DFT's real part
        cos_m, sin_m = _mats()
        parts = torch.view_as_real(z)
        return (parts[..., 0] @ cos_m - parts[..., 1] @ sin_m) / POINTS

    namespace = {"torch": torch, "nn": torch.nn, "F": torch.nn.functional, "np": np,
                 "_dft": _dft, "_idft_real": _idft_real, "_lambda0": lambda0,
                 "time": __import__("time"),
                 "grid_x_train": torch.linspace(0.0, 1.0, POINTS)}
    exec(compile(ast.Module(body=keep, type_ignores=[]), str(path), "exec"), namespace)

    class _OneChannel(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.project = torch.nn.Linear(n_in + 1, 1)
            self.lno = namespace["LNO1d"](4, 20)

        def forward(self, grid):  # (n, 60, k + 1)
            return self.lno(self.project(grid))

    return OnGrid(_OneChannel(), channels_last=True)


BATCH2 = {
    "cno.CNO1d": _cno,
    "oformer.Encoder1D_PointWiseDecoder1D": _oformer,
    "lno.LNO1d": _lno,
}


# --- Batch 3: wheel-installed libraries (pinned wheels in the packet) --------
def _deepxde():
    """Import DeepXDE (wheel 1.15.0) on its PyTorch backend, restoring the
    process-wide torch defaults its backend import changes (default device on a
    CUDA host, default dtype)."""
    import os

    os.environ["DDE_BACKEND"] = "pytorch"
    dtype = torch.get_default_dtype()
    device = torch.get_default_device()
    import deepxde

    torch.set_default_dtype(dtype)
    torch.set_default_device(device)
    return deepxde


class _DeepONet(torch.nn.Module):
    """DeepXDE's DeepONetCartesianProd: the branch net reads the case's 8
    inputs, the trunk net the 60 curve positions; output (n, 60)."""

    def __init__(self, model):
        super().__init__()
        self.model = model
        self.register_buffer("positions", torch.linspace(0.0, 1.0, POINTS).view(POINTS, 1))

    def forward(self, x):
        x = x.to(self.positions.dtype)
        return self.model((x, self.positions))


def _deeponet(n_in):
    dde = _deepxde()
    return _DeepONet(dde.nn.DeepONetCartesianProd(
        [n_in, 64, 64, 32], [1, 64, 64, 32], "tanh", "Glorot normal"))


UPSTREAM["transolver_plus-d5a23"] = {  # thuml/Transolver_plus, MIT
    "LICENSE": "996b7ed7b544265d5759c96e1918588129d7a1c50024a80afc111c2324755e8c",
    "models/Transolver_plus.py": "b5b73c2b1f21f06397bd53d800bb70627033920e5c95d4ecb2b0527cfc225a24",
}


class _TransolverPlus(torch.nn.Module):
    """Transolver++'s own Model: each curve point's token is its position plus
    the case's inputs; no condition vector.

    Upstream samples Gumbel noise (`torch.rand_like`) in its slice attention on
    every forward pass. Carbon's adaptation (owner, 2026-10-20): the noise is
    used only while training, drawn from this model's own generator, seeded once
    from torch's generator, which the training loop seeds, so paired rebuilds
    draw the same noise; in eval and at export the slice weights are upstream's
    noise-free `softmax(logits / tau)`, so the graded graph is deterministic."""

    def __init__(self, model, module):
        super().__init__()
        self.model = model
        self.noise = torch.Generator().manual_seed(
            int(torch.randint(0, 2**31 - 1, (1,)))
        )
        owner = self

        def gumbel_softmax(logits, tau=1, hard=False):
            y = logits
            if owner.training:
                u = torch.rand(
                    logits.shape, generator=owner.noise, dtype=logits.dtype
                ).to(logits.device)
                y = y - torch.log(-torch.log(u + 1e-8) + 1e-8)
            y = torch.nn.functional.softmax(y / tau, dim=-1)
            if hard:  # upstream's straight-through branch, unchanged
                _, y_hard = y.max(dim=-1)
                y_one_hot = torch.zeros_like(y).scatter_(-1, y_hard.unsqueeze(-1), 1.0)
                y = (y_one_hot - y).detach() + y
            return y

        # A fresh module per model (`_file_module`), so this binds only here.
        module.gumbel_softmax = gumbel_softmax

    def forward(self, grid):  # (n, 60, k + 1), last channel the coordinate
        pos = grid[..., -1:]
        tokens = torch.cat([pos, grid[..., :-1]], dim=-1)
        return self.model((tokens, pos, None))


class _SingleProcess:
    """Stand-in for torch.distributed.nn in Transolver++'s module namespace.
    Upstream calls `dist_nn.all_reduce(t, op=SUM)` and discards the returned
    tensor (the functional all_reduce does not write in place), so the call
    never affects outputs; one process needs no process group. Upstream finding:
    without a group the call raises, so the published Model is multi-GPU only."""

    class ReduceOp:
        SUM = "sum"

    @staticmethod
    def all_reduce(tensor, op=None, group=None):
        return tensor


def _transolver_plus(n_in):
    module = _file_module(_tree("transolver_plus-d5a23") / "models" / "Transolver_plus.py",
                          "dc_transolver_plus")
    module.dist_nn = _SingleProcess
    model = module.Model(space_dim=1, n_layers=2, n_hidden=32, n_head=4, fun_dim=n_in,
                         out_dim=1, slice_num=8)
    return OnGrid(_TransolverPlus(model, module), channels_last=True)


class _NoSearch(torch.nn.Module):
    """Stands in for a GNO block's neighbour search: its result is a constant of the fixed
    geometry and lives in the (class-swapped) integral transform."""

    def forward(self, data, queries, radius):
        return {}


def _constant_gino_transforms(gino, points, latent):
    """GINO's two GNO blocks on the fixed geometry (60 curve points, 16 latent points): the
    library's `native_neighbor_search` runs once here; the integral transform then gathers with
    constant indices and reduces with a constant matrix (a mean or sum over each neighbourhood,
    which is what `segment_csr` computes), so no value-dependent shape reaches a graph."""
    from neuralop.layers.integral_transform import IntegralTransform
    from neuralop.layers.neighbor_search import native_neighbor_search

    class ConstantTransform(IntegralTransform):
        def forward(self, y, neighbors, x=None, f_y=None, weights=None):
            if x is None:
                x = y
            agg = torch.cat(
                [y.index_select(0, self.nbr_index), x.index_select(0, self.query_index)], dim=-1
            )
            rep = self.channel_mlp(agg)
            if f_y is not None:
                rep = rep * f_y.index_select(f_y.ndim - 2, self.nbr_index)
            # the per-query mean/sum as a one-hot matrix built here from the two index constants (a dense
            # constant matrix of the same values would exceed the graph's 16 KiB constant limit)
            rows, owner = torch.arange(self.n_queries).view(-1, 1), self.query_index.view(1, -1)
            reduce = (rows >= owner).to(rep.dtype) * (rows <= owner).to(rep.dtype)
            return torch.matmul(reduce * self.entry_weight.view(1, -1), rep)

    from neuralop.layers.embeddings import SinusoidalEmbedding

    class FrozenSinusoidal(SinusoidalEmbedding):
        def forward(self, x):
            batched = x.ndim == 3
            x = x if batched else x.unsqueeze(0)
            batch_size, n_in, _ = x.shape
            freqs = torch.einsum("bij, k -> bijk", x, self.freqs)
            freqs = torch.stack((freqs.sin(), freqs.cos()), dim=-1).view(batch_size, n_in, -1)
            return freqs if batched else freqs.squeeze(0)

    for block, (data, queries) in ((gino.gno_in, (points, latent)), (gino.gno_out, (latent, points))):
        embedding = block.pos_embedding
        if embedding is not None:
            steps = torch.arange(0, embedding.num_frequencies)
            if embedding.embedding_type == "nerf":
                freqs = 2 ** steps * torch.pi
            else:
                freqs = (1 / embedding.max_positions) ** (steps / embedding.num_frequencies * 2)
            embedding.__class__ = FrozenSinusoidal
            embedding.register_buffer("freqs", freqs, persistent=False)
        transform = block.integral_transform
        if transform.transform_type != "linear":
            raise RuntimeError("GINO adapter covers the linear transform only")
        found = native_neighbor_search(data, queries, block.radius, False)
        index, splits = found["neighbors_index"], found["neighbors_row_splits"]
        counts = splits[1:] - splits[:-1]
        entry_weight = torch.ones(len(index))
        for row in range(len(queries)):
            lo, hi = int(splits[row]), int(splits[row + 1])
            if hi > lo and transform.reduction == "mean":
                entry_weight[lo:hi] = 1.0 / (hi - lo)
        block.neighbor_search = _NoSearch()
        transform.__class__ = ConstantTransform
        transform.register_buffer("nbr_index", index, persistent=False)
        transform.register_buffer("query_index", torch.repeat_interleave(torch.arange(len(queries)), counts), persistent=False)
        transform.register_buffer("entry_weight", entry_weight, persistent=False)
        transform.n_queries = len(queries)
    return gino


class _GINOOnCurve(torch.nn.Module):
    """GINO on Motor's curve as a 1-D point cloud: the 60 curve points are both the input
    geometry and the output queries, a 16-point latent grid between them (Launchpad's
    configuration for this entry)."""

    def __init__(self, n_in):
        super().__init__()
        import neuralop.models as models

        c = n_in + 1
        gino = models.GINO(
            in_channels=c, out_channels=1, gno_coord_dim=1, in_gno_radius=0.1, out_gno_radius=0.1,
            fno_n_modes=(8,), fno_hidden_channels=32, fno_n_layers=2, fno_in_channels=c,
            gno_embed_channels=16, in_gno_channel_mlp_hidden_layers=[32, 32],
            out_gno_channel_mlp_hidden_layers=[32, 32], gno_use_open3d=False,
            gno_use_torch_scatter=False,
        )
        points = torch.linspace(0.0, 1.0, POINTS).view(1, POINTS, 1)
        latent = torch.linspace(0.0, 1.0, 16).view(1, 16, 1)
        self.gino = _constant_gino_transforms(gino, points[0], latent[0])
        self.register_buffer("points", points)
        self.register_buffer("latent", latent)

    def forward(self, x):
        n, k = x.shape
        x = x.to(self.points.dtype)
        feats = torch.cat([x.view(n, 1, k).expand(n, POINTS, k), self.points.expand(n, -1, -1)], dim=-1)
        return self.gino(self.points, self.latent, self.points, x=feats).reshape(n, POINTS)


BATCH3 = {
    "deepxde.DeepONetCartesianProd": _deeponet,
    "thuml.Transolver_plus": _transolver_plus,
    "neuralop.GINO": _GINOOnCurve,
}
#: Pinned wheels each batch-3 entry installs (name -> sha256); see assemble_dc.
WHEELS = {
    "thuml.ONO": ("nystrom_attention-0.0.14-py3-none-any.whl",),  # ONO's default nystrom attention
    "deepxde.DeepONetCartesianProd": (
        "deepxde-1.15.0-py3-none-any.whl",
        "scikit_learn-1.7.2-cp311-cp311-manylinux2014_x86_64.manylinux_2_17_x86_64.whl",
        "scikit_optimize-0.10.2-py2.py3-none-any.whl",
        "joblib-1.5.2-py3-none-any.whl",
        "threadpoolctl-3.6.0-py3-none-any.whl",
        "pyaml-25.7.0-py3-none-any.whl",
    ),
}


def _registry(n_in):
    entries = {
        key: (lambda m=m, g=g, o=o: _library(m, n_in, g, **o))
        for key, (m, g, o) in ENTRIES.items()
    }
    entries.update({key: (lambda f=f: f(n_in)) for key, f in {**BATCH2, **BATCH3}.items()})
    return entries


NAMES = tuple(ENTRIES) + tuple(BATCH2) + tuple(BATCH3)


def build_backbone(name, n_in):
    """The named backbone as a fresh module, or `KeyError`."""
    return _registry(n_in)[name]()
