"""Backbone coverage: one open-source operator backbone (named in the
configuration, `backbones.py`) trained fresh on Motor TRAIN.

Training runs in the backbone's own float precision (float32 by default:
several libraries keep complex64 spectral weights), and the output is cast to
float64, which Motor's judge requires. Optional customization:
`train_use.loss` = "mse" (default) or "derivative" (MSE plus a penalty on the
curve's second difference: a PINO-style smoothness term; no Motor PDE residual
is published to use instead).
"""

from __future__ import annotations

import torch

from .backbones import build_backbone
from .common import DEVICE, only, positive_int, prepare, rate


def build(train_inputs, train_targets, *, seed, configuration, train_use):
    only(configuration, {"backbone", "learning_rate"}, "configuration")
    only(train_use, {"steps", "loss", "derivative_weight"}, "train_use")
    lr = rate(configuration.get("learning_rate"), 1e-3)
    steps = positive_int(train_use.get("steps"), "steps", 200)
    loss_kind = train_use.get("loss", "mse")
    weight = float(train_use.get("derivative_weight", 0.1))
    if loss_kind not in ("mse", "derivative"):
        raise ValueError("loss must be mse or derivative")
    z, t, stats = prepare(train_inputs, train_targets, seed)
    model = build_backbone(configuration["backbone"], z.shape[1]).to(DEVICE)
    precision = next((p.dtype for p in model.parameters() if p.is_floating_point()), torch.float32)
    precision = torch.float32 if precision.is_complex else precision
    x, y = z.to(precision), t.to(precision)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    model.train()
    for _ in range(steps):
        optimizer.zero_grad(set_to_none=True)
        pred = model(x)
        loss = torch.mean((pred - y) ** 2)
        if loss_kind == "derivative":
            loss = loss + weight * torch.mean((pred[:, 2:] - 2 * pred[:, 1:-1] + pred[:, :-2]) ** 2)
        if not bool(torch.isfinite(loss)):
            raise RuntimeError("nonfinite TRAIN loss")
        loss.backward()
        optimizer.step()

    model = model.cpu().eval()
    named = list(model.named_parameters())
    names = tuple(n for n, _ in named)
    buffers = {n: b.detach().clone() for n, b in model.named_buffers()}
    parameters = [p.detach().clone() for _, p in named]
    mx, sx, my, sy = (stats[k] for k in ("mx", "sx", "my", "sy"))

    def apply(params, inputs):
        q = ((torch.as_tensor(inputs) - mx) / sx).to(precision)
        out = torch.func.functional_call(model, (dict(zip(names, params)), buffers), (q,))
        return out.to(torch.float64) * sy + my

    return {"framework": "torch", "apply": apply, "parameters": parameters}
