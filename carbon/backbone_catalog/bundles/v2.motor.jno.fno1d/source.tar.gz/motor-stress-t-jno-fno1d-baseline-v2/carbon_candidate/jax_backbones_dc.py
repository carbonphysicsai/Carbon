"""foundax 0.2.0 (the architecture package behind FhG-IISB jNO) backbones on
Motor's job (packs lane, DEVELOPMENT).

Every entry builds a fresh, untrained Equinox model with a foundax factory,
unmodified, at the smallest configuration that factory allows, and returns
`(model, forward)` where `forward(model, x)` maps a standardised (n, 8) float64
batch to (n, 60). Architecture only, no pretrained weights: nothing is loaded
or downloaded anywhere in this module.

Shared adapters (same conventions as the Torch `backbones_dc.OnGrid`):
- grid: the case's 8 inputs broadcast over the 60 curve points plus the point's
  coordinate in [0, 1] (last channel) = a 9-channel 1-D function (60, 9);
- 6x10: that grid reshaped row-major to a 6x10 image (2-D-only models);
- square(s): the 60 points row-major in the first 60 cells of an s x s image,
  the remaining cells repeating the last point (models that require a square
  image); the readout takes the first 60 cells;
- tokens: 60 tokens of [position, 8 inputs] (point-cloud / transformer models);
- DeepONet-style: branch = the 8 inputs, trunk = the 60 positions.
A multi-channel output is read at channel 0 unless an entry says otherwise.
Outputs are cast to float64 (several vendored models keep float32/complex64
internals); Motor requires float64.

Training (in `jax_backbone.build`) updates every inexact array leaf of the
Equinox model, as `eqx.filter(model, eqx.is_inexact_array)` selects them; for a
few models that includes arrays the upstream code treats as fixed (GeoFNO and
PCNO Fourier modes, PiT distance matrices, PROSE sinusoidal tables, DPOT
time-aggregation frequencies). Each such case is named in its entry.

Only the smallest size variant of each family is built (poseidonT, morph_Ti,
mpp_Ti, pdeformer2_small, dpot_Ti); the larger shortcuts (B/L, S/M/L, base,
fast, S/M/L/H) are the same architecture classes at larger widths.
"""

from __future__ import annotations

import numpy as np

import foundax
import jax
import jax.numpy as jnp

POINTS = 60
POS = np.linspace(0.0, 1.0, POINTS)

#: Every architecture factory has an entry below; nothing is inapplicable.
NOT_APPLICABLE: dict[str, str] = {}

#: Source-read predictions (unexecuted) the probe should confirm or refute.
EXPECTED = {
    "transformer": "forward fails: architectures/transformer.py PositionalEncoding "
    "uses inputs.shape[1] (the embedding width) as the sequence length and adds a "
    "3-D (1, L, E) table to the 2-D (T, E) token embeddings that eqx.nn.Embedding "
    "requires (scalar index under vmap), so the next eqx LayerNorm(E) refuses a "
    "(T, E) or (L, E) input for any T, E, max_len.",
    "prose_ode_2to1": "train/trace fail: jax_prose DataOperatorModel.forward_hidden "
    "calls int(jnp.max(src_data_len)) (no_text=False is fixed by the factory), a "
    "concretization error under jit/make_jaxpr.",
    "prose_pde_2to1": "train/trace fail: same int(jnp.max(src_data_len)) as prose_ode_2to1.",
    "pdeformer2": "closed form over the constant cap: Conv2dFuncEncoderV3 has fixed "
    "32 and 128-channel 4x4 convolutions (about 66k weights) that no factory "
    "argument shrinks.",
    "prose_fd_1to1": "closed form far over the cap: fd_1to1 fixes dim_emb=1024 with "
    "7 encoder and 12 decoder layers; training may exceed the probe timeout.",
    "prose_fd_2to1": "closed form far over the cap: fd_2to1 fixes dim_emb=1024 and "
    "a 1024x1024 sinusoidal table.",
}

#: foundax.nn shortcut -> (submodule, factory) it delegates to. Read from source:
#: every shortcut except prose_* forwards keyword arguments the submodule
#: factory does not accept, so calling the shortcut raises TypeError; entries
#: therefore use the submodule's callable form `foundax.<model>(..., key=)`.
NN_SHORTCUTS = {
    "poseidonT": ("poseidon", "T"),
    "morph_Ti": ("morph", "Ti"),
    "mpp_Ti": ("mpp", "Ti"),
    "walrus": ("walrus", "base"),
    "bcat": ("bcat", "base"),
    "pdeformer2_small": ("pdeformer2", "small"),
    "dpot_Ti": ("dpot", "Ti"),
    "prose_fd_1to1": ("prose", "fd_1to1"),
    "prose_fd_2to1": ("prose", "fd_2to1"),
    "prose_ode_2to1": ("prose", "ode_2to1"),
    "prose_pde_2to1": ("prose", "pde_2to1"),
}


# --- shape adapters ----------------------------------------------------------
def _grid(x):
    """(n, k) -> (n, 60, k + 1): inputs broadcast over the curve, coordinate last."""
    n, k = x.shape
    pos = jnp.broadcast_to(jnp.asarray(POS, x.dtype)[None, :, None], (n, POINTS, 1))
    return jnp.concatenate([jnp.broadcast_to(x[:, None, :], (n, POINTS, k)), pos], -1)


def _image(x):
    """(n, k) -> (n, 6, 10, k + 1), row-major."""
    g = _grid(x)
    return g.reshape(g.shape[0], 6, 10, g.shape[-1])


def _tokens(x):
    """(n, k) -> (n, 60, 1 + k): [position, inputs] per curve point."""
    g = _grid(x)
    return jnp.concatenate([g[..., -1:], g[..., :-1]], -1)


def _square(g, side):
    """(n, 60, c) -> (n, side, side, c): row-major, tail repeats the last point."""
    pad = side * side - POINTS
    g = jnp.concatenate([g, jnp.repeat(g[:, -1:], pad, axis=1)], 1)
    return g.reshape(g.shape[0], side, side, g.shape[-1])


def _unsquare(o):
    """(n, side, side) -> (n, 60): the first 60 cells."""
    return o.reshape(o.shape[0], -1)[:, :POINTS]


def _f64(y):
    return jnp.asarray(y).astype(jnp.float64)


# --- non-foundation architectures --------------------------------------------
def _linear(key, n_in):
    """foundax.linear: (n, 8) -> (n, 60) directly (batched Linear)."""
    model = foundax.linear(n_in, POINTS, key=key)
    return model, lambda m, x: _f64(m(x))


def _mlp(key, n_in):
    """foundax.mlp: one hidden layer of width 8, (8,) -> (60,) per case."""
    model = foundax.mlp(n_in, output_dim=POINTS, hidden_dims=8, num_layers=1, key=key)
    return model, lambda m, x: _f64(jax.vmap(m)(x))


def _fno1d(key, n_in):
    """foundax.fno1d on the grid (60, 9) -> (1, 60, 1). Its projection MLP has a
    fixed 128-wide hidden layer."""
    model = foundax.fno1d(n_in + 1, hidden_channels=2, n_modes=2, n_layers=1, key=key)
    return model, lambda m, x: _f64(jax.vmap(lambda g: m(g)[0, :, 0])(_grid(x)))


def _fno2d(key, n_in):
    """foundax.fno2d on the 6x10 image (6, 10, 9) -> (6, 10, 1)."""
    model = foundax.fno2d(n_in + 1, hidden_channels=2, n_modes=2, n_layers=1,
                          d_model=(6, 10), norm=None, key=key)
    return model, lambda m, x: _f64(jax.vmap(lambda g: m(g)[..., 0])(_image(x)).reshape(-1, POINTS))


def _fno3d(key, n_in):
    """foundax.fno3d on the grid reshaped row-major to a 3x4x5 lattice
    (3, 4, 5, 9) -> (3, 4, 5, 1). The 3-D layout is an adapter, not geometry."""
    model = foundax.fno3d(n_in + 1, hidden_channels=2, n_modes=2, n_layers=1,
                          d_model=(3, 4, 5), norm=None, key=key)

    def forward(m, x):
        g = _grid(x).reshape(x.shape[0], 3, 4, 5, n_in + 1)
        return _f64(jax.vmap(lambda v: m(v)[..., 0])(g).reshape(-1, POINTS))

    return model, forward


def _deeponet(key, n_in):
    """foundax.deeponet (MLP branch and trunk, dot product): branch = the 8
    inputs as 8 one-channel sensors, trunk = the 60 positions."""
    model = foundax.deeponet(n_sensors=n_in, sensor_channels=1, coord_dim=1, n_outputs=1,
                             basis_functions=8, hidden_dim=8, n_layers=1, key=key)

    def forward(m, x):
        y = jnp.asarray(POS, x.dtype)[:, None]
        return _f64(jax.vmap(lambda u: m(u, y))(x))

    return model, forward


def _cno2d(key, n_in):
    """foundax.cno2d needs a square image: square(8) (8, 8, 9) -> (1, 8, 8, 1).
    Its lift/project blocks have a fixed 64-channel latent."""
    model = foundax.cno2d(in_dim=n_in + 1, out_dim=1, size=8, N_layers=1, N_res=1,
                          N_res_neck=1, channel_multiplier=2, key=key)
    return model, lambda m, x: _f64(_unsquare(jax.vmap(lambda g: m(g)[0, ..., 0])(_square(_grid(x), 8))))


def _unet1d(key, n_in):
    """foundax.unet1d on the grid (60, 9) -> (60, 1); depth 1, 2 base channels."""
    model = foundax.unet1d(n_in + 1, 1, depth=1, wf=1, key=key)
    return model, lambda m, x: _f64(jax.vmap(lambda g: m(g)[:, 0])(_grid(x)))


def _unet2d(key, n_in):
    """foundax.unet2d on the 6x10 image -> (6, 10, 1)."""
    model = foundax.unet2d(n_in + 1, 1, depth=1, wf=1, key=key)
    return model, lambda m, x: _f64(jax.vmap(lambda g: m(g)[..., 0])(_image(x)).reshape(-1, POINTS))


def _unet3d(key, n_in):
    """foundax.unet3d: its average pooling needs even sizes on all three axes,
    which no 60-point lattice has, so the 6x10 image is duplicated along a depth
    axis of 2 (2, 6, 10, 9) and slab 0 is read. The factory's default
    activation is the string "celu", which UNetConv3d would call; the callable
    jax.nn.celu (the same function) is passed instead."""
    model = foundax.unet3d(n_in + 1, 1, depth=1, wf=1, activation=jax.nn.celu, key=key)

    def forward(m, x):
        g = _image(x)
        return _f64(jax.vmap(lambda v: m(v)[0, ..., 0])(jnp.stack([g, g], 1)).reshape(-1, POINTS))

    return model, forward


def _mgno1d(key, n_in):
    """foundax.mgno1d on the grid (60, 9) -> (60, 1), two multigrid levels with
    one pre-smoothing step each. MgNO1D runs a (60, 1) 2-D grid; prolongation
    widens the singleton axis to 2 and upstream broadcasting absorbs it (read
    from source, unverified)."""
    model = foundax.mgno1d(POINTS, num_layer=1, num_channel_u=2, num_channel_f=n_in + 1,
                           num_iteration=[(1, 0), (1, 0)], key=key)
    return model, lambda m, x: _f64(jax.vmap(lambda g: m(g)[:, 0])(_grid(x)))


def _mgno2d(key, n_in):
    """foundax.mgno2d on the 6x10 image -> (6, 10, 1), two levels (6x10, 3x5)."""
    model = foundax.mgno2d((6, 10), num_layer=1, num_channel_u=2, num_channel_f=n_in + 1,
                           num_iteration=[(1, 0), (1, 0)], key=key)
    return model, lambda m, x: _f64(jax.vmap(lambda g: m(g)[..., 0])(_image(x)).reshape(-1, POINTS))


def _geofno(key, n_in):
    """foundax.geofno, 1-D with 4 Fourier modes on domain length 1: the 60
    points as nodes (all valid, weights 1/60), node features = the grid. Its
    `modes` array is an inexact leaf, so training updates it."""
    model = foundax.geofno(ndims=1, nks=(4,), Ls=(1.0,), layers=(2, 2), fc_dim=0,
                           in_dim=n_in + 1, out_dim=1, key=key)

    def forward(m, x):
        nodes = jnp.asarray(POS, x.dtype)[:, None]
        mask = jnp.ones_like(nodes)
        weights = mask / POINTS
        return _f64(jax.vmap(lambda g: m(g, mask, nodes, weights))(_grid(x)))

    return model, forward


def _chain_edges():
    """1-D chain: directed edges (target, source) to each neighbour and the
    least-squares gradient weights dx / sum(dx^2) at the target node."""
    idx = np.arange(POINTS)
    target = np.concatenate([idx[1:], idx[:-1]])
    source = np.concatenate([idx[:-1], idx[1:]])
    dx = POS[source] - POS[target]
    denom = np.zeros(POINTS)
    np.add.at(denom, target, dx**2)
    return np.stack([target, source], -1), (dx / denom[target])[:, None]


def _pcno(key, n_in):
    """foundax.pcno, 1-D, one measure, 4 Fourier modes: the 60 points as a
    point cloud (weights 1/60) with a 1-D chain graph for its gradient operator
    (least-squares weights). Called per case with a leading batch of 1. Its
    `modes` array is an inexact leaf, so training updates it."""
    model = foundax.pcno(ndims=1, nks=(4,), Ls=(1.0,), layers=(2, 2), fc_dim=0,
                         in_dim=n_in + 1, out_dim=1, key=key)
    edges, edge_weights = _chain_edges()

    def forward(m, x):
        nodes = jnp.asarray(POS, x.dtype)[None, :, None]
        mask = jnp.ones_like(nodes)
        args = (mask, nodes, mask / POINTS, jnp.asarray(edges)[None],
                jnp.asarray(edge_weights, x.dtype)[None])
        return _f64(jax.vmap(lambda g: m(g[None], *args)[0, :, 0])(_grid(x)))

    return model, forward


def _trunk_branch(x):
    """GNOT family: trunk = the 60 positions (n, 60, 1), branch = one sensor
    token carrying the 8 inputs (n, 1, 8)."""
    trunk = jnp.broadcast_to(jnp.asarray(POS, x.dtype)[None, :, None], (x.shape[0], POINTS, 1))
    return trunk, x[:, None, :]


def _cgptno(key, n_in):
    """foundax.cgptno: query = position, one input function = the 8 inputs."""
    model = foundax.cgptno(1, branch_sizes=[n_in], n_layers=1, n_hidden=4, n_inner=1, key=key)

    def forward(m, x):
        trunk, branch = _trunk_branch(x)
        return _f64(m(trunk, [branch])[..., 0])

    return model, forward


def _gnot(key, n_in):
    """foundax.gnot: as cgptno, with position-gated mixture of 2 experts
    (space_dim=1: the trunk's first column, the position, drives the gate)."""
    model = foundax.gnot(1, [n_in], space_dim=1, n_layers=1, n_hidden=4, n_experts=2,
                         n_inner=1, key=key)

    def forward(m, x):
        trunk, branch = _trunk_branch(x)
        return _f64(m(trunk, [branch])[..., 0])

    return model, forward


def _moegptno(key, n_in):
    """foundax.moegptno: single-input GNOT (its FFN width multiplier is fixed at 4)."""
    model = foundax.moegptno(1, n_in, space_dim=1, n_layers=1, n_hidden=4, n_experts=2, key=key)

    def forward(m, x):
        trunk, branch = _trunk_branch(x)
        return _f64(m(trunk, branch)[..., 0])

    return model, forward


def _pit(key, n_in):
    """foundax.pit (PiTWithCoords): the 60 tokens on a 60x1 input/output grid
    with a 6x1 latent grid, one processor block. Its distance matrices are
    inexact leaves, so training updates them."""
    model = foundax.pit(n_in + 1, 1, hid_channels=2, n_head=1, localities=(100, 50, 100),
                        input_res=(POINTS, 1), latent_res=(6, 1), output_res=(POINTS, 1),
                        key=key)
    return model, lambda m, x: _f64(jax.vmap(lambda t: m(t)[:, 0])(_tokens(x)))


def _pointnet(key, n_in):
    """foundax.pointnet on the 60 tokens; encoder 2-2-2, decoder 2."""
    model = foundax.pointnet(n_in + 1, 1, hidden_dims=[2, 2, 2, 2], key=key)
    return model, lambda m, x: _f64(m(_tokens(x))[..., 0])


VOCAB, BINS = 64, 8
CENTERS = np.linspace(-3.0, 3.0, VOCAB)


def _transformer(key, n_in):
    """foundax.transformer is a token encoder-decoder; closest honest adapter:
    encoder tokens = each standardised input quantised to 8 bins over [-2, 2]
    and offset by 8 x its index (8 tokens, vocabulary 64); decoder tokens = the
    60 position indices; the curve value = softmax(logits) . 64 fixed bin
    centres in [-3, 3]. Expected to fail at forward (see EXPECTED)."""
    model = foundax.transformer(num_layers=1, embed_dim=4, num_heads=1, mlp_features=4,
                                dropout_rate=0.0, vocab_size=VOCAB, max_len=VOCAB, key=key)

    def forward(m, x):
        offsets = BINS * jnp.arange(n_in)
        positions = jnp.arange(POINTS)
        centers = jnp.asarray(CENTERS, x.dtype)

        def one(u):
            tokens = jnp.clip(jnp.floor((u + 2.0) * BINS / 4.0), 0, BINS - 1).astype(jnp.int32)
            logits = m(tokens + offsets, positions)
            return jax.nn.softmax(logits, axis=-1) @ centers

        return _f64(jax.vmap(one)(x))

    return model, forward


# --- foundation-model architectures (architecture only, no pretrained weights) -
def _dpot(key, n_in):
    """DPOT (dpot_Ti family) via foundax.dpot(..., key=): square(8), one input
    and one output step, patch 2, width 8 (its GroupNorm has 8 groups), one
    AFNO block. Architecture only, no pretrained weights. Its time-aggregation
    frequencies `gamma` are an inexact leaf, so training updates them."""
    model = foundax.dpot(img_size=8, patch_size=2, in_channels=n_in + 1, out_channels=1,
                         in_timesteps=1, out_timesteps=1, n_blocks=1, embed_dim=8,
                         out_layer_dim=2, depth=1, modes=2, n_cls=1, key=key)

    def forward(m, x):
        out, _ = m(_square(_grid(x), 8)[:, None])
        return _f64(_unsquare(out[:, 0, ..., 0]))

    return model, forward


def _poseidon(key, n_in):
    """Poseidon ScOT (poseidonT family) via foundax.poseidon(..., key=):
    square(8), patch 2, two Swin stages of depth 1 (width 4, 8), window 2, one
    ConvNeXt skip block, no lead-time conditioning. Architecture only, no
    pretrained weights."""
    model = foundax.poseidon(image_size=8, patch_size=2, num_channels=n_in + 1,
                             num_out_channels=1, embed_dim=4, depths=(1, 1), num_heads=(1, 1),
                             skip_connections=(1, 0), window_size=2, mlp_ratio=1.0,
                             use_conditioning=False, key=key)
    return model, lambda m, x: _f64(_unsquare(m(_square(_grid(x), 8)).output[..., 0]))


def _morph(key, n_in):
    """MORPH ViT3DRegression (morph_Ti family) via foundax.morph(..., key=):
    the 6x10 image as one frame, its 9 channels as field components
    (max_components=9), patch 2 (15 patches), width 4, one block. Architecture
    only, no pretrained weights."""
    model = foundax.morph(patch_size=2, dim=4, depth=1, heads=1, heads_xa=1, mlp_dim=4,
                          max_components=n_in + 1, conv_filter=1, max_ar=1, max_patches=15,
                          max_fields=1, dropout=0.0, emb_dropout=0.0, key=key)

    def forward(m, x):
        _, _, pred = m(_image(x)[:, None])
        return _f64(pred[..., 0].reshape(-1, POINTS))

    return model, forward


def _mpp(key, n_in):
    """MPP AViT (mpp_Ti family) via foundax.mpp(..., key=): square(32) (its
    fixed 16-pixel patching needs at least 2x2 tokens: RMSInstanceNorm2d uses
    ddof=1), the 9 channels as 9 states, width 4, one block. AViT predicts the
    next frame and de-normalises each output channel by its own input
    channel's spatial mean and std; the 8 inputs are spatially constant, so the
    curve is read from the coordinate channel (index 8), the only one that
    varies. Architecture only, no pretrained weights."""
    model = foundax.mpp(patch_size=(16, 16), embed_dim=4, processor_blocks=1,
                        n_states=n_in + 1, drop_path=0.0, num_heads=1, key=key)

    def forward(m, x):
        labels = jnp.arange(n_in + 1)
        bcs = jnp.zeros((x.shape[0], 2), jnp.int32)
        return _f64(_unsquare(m(_square(_grid(x), 32)[:, None], labels, bcs)[..., n_in]))

    return model, forward


def _walrus(key, n_in):
    """Walrus IsotropicModel via foundax.walrus(..., key=): the 6x10 image as
    one frame, 9 states, width 8, one block, unit base kernels (no spatial
    downsampling; strides for a 6x10 grid are 1 by its own table), open
    boundaries. Architecture only, no pretrained weights."""
    model = foundax.walrus(hidden_dim=8, intermediate_dim=4, n_states=n_in + 1,
                           processor_blocks=1, groups=1, num_heads=1, causal_in_time=False,
                           drop_path=0.0, base_kernel_size=((1, 1), (1, 1), (1, 1)),
                           include_d=(2,), encoder_groups=1, key=key)

    def forward(m, x):
        labels = jnp.arange(n_in + 1)
        out = m(_image(x)[:, None], labels, [[0, 0], [0, 0], [0, 0]])
        return _f64(out[:, 0, ..., 0].reshape(-1, POINTS))

    return model, forward


def _bcat(key, n_in):
    """BCAT via foundax.bcat(..., key=): square(8) as the input frame and a
    zero placeholder as the target frame (BCAT drops the last frame in its
    forward), input_len=1, 4x4 patches, width 4, one layer. Architecture only,
    no pretrained weights."""
    model = foundax.bcat(n_layer=1, dim_emb=4, dim_ffn=4, n_head=1, x_num=8, patch_num=4,
                         patch_num_output=4, conv_dim=4, max_time_len=1, max_data_len=1,
                         data_dim=n_in + 1, key=key)

    def forward(m, x):
        frame = _square(_grid(x), 8)
        data = jnp.stack([frame, jnp.zeros_like(frame)], 1)
        times = jnp.broadcast_to(jnp.asarray([[0.0], [1.0]], x.dtype), (x.shape[0], 2, 1))
        return _f64(_unsquare(m(data, times, input_len=1)[:, 0, ..., 0]))

    return model, forward


def _pdeformer2(key, n_in):
    """PDEformer-2 (pdeformer2_small family) via foundax.pdeformer2(..., key=):
    its input is a PDE computation graph; closest honest adapter: 8 scalar
    nodes (types 1..8), one per Motor input carrying its value, no function
    nodes, all-zero attention bias, spatial distance 1, degrees 0; the INR is
    queried at (t, x, y, z) = (0, position, 0, 0) for the 60 points.
    Architecture only, no pretrained weights."""
    model = foundax.pdeformer2(num_node_type=n_in, num_in_degree=1, num_out_degree=1,
                               num_spatial=2, num_encoder_layers=1, embed_dim=4,
                               ffn_embed_dim=4, num_heads=1, scalar_dim_hidden=4,
                               scalar_num_layers=1, func_enc_resolution=64, inr_dim_hidden=4,
                               inr_num_layers=2, hyper_dim_hidden=4, hyper_num_layers=1, key=key)

    def forward(m, x):
        n = x.shape[0]
        node_type = jnp.broadcast_to(jnp.arange(1, n_in + 1)[None, :, None], (n, n_in, 1))
        zeros_int = jnp.zeros((n, n_in), jnp.int32)
        coordinate = jnp.zeros((n, POINTS, 4), x.dtype).at[:, :, 1].set(jnp.asarray(POS, x.dtype))
        out = m(node_type, x[..., None], jnp.zeros((n, 0, 64 * 64, 4), x.dtype), zeros_int,
                zeros_int, jnp.zeros((n, n_in, n_in), x.dtype),
                jnp.ones((n, n_in, n_in), jnp.int32), coordinate)
        return _f64(out[..., 0])

    return model, forward


def _prose_fd(variant):
    def builder(key, n_in):
        """PROSE finite-difference model via foundax.prose.fd_1to1 / fd_2to1
        (key=): square(16) as one input frame of 9 channels, queried at one
        output time; fd_2to1's symbol branch gets a constant one-token sequence
        (no Motor equation text exists). Widths are fixed by the factory.
        Architecture only, no pretrained weights; its sinusoidal tables are
        inexact leaves, so training updates them."""
        if variant == "fd_1to1":
            model = foundax.prose.fd_1to1(x_num=16, max_output_dim=n_in + 1, output_len=1, key=key)
        else:
            model = foundax.prose.fd_2to1(2, x_num=16, max_output_dim=n_in + 1, key=key)

        def forward(m, x):
            n = x.shape[0]
            frame = _square(_grid(x), 16)[:, None]
            t_in, t_out = jnp.zeros((n, 1, 1), x.dtype), jnp.ones((n, 1, 1), x.dtype)
            if variant == "fd_1to1":
                out = m(frame, t_in, t_out)
            else:
                out = m(frame, t_in, t_out, jnp.ones((n, 1), jnp.int32))
            return _f64(_unsquare(out[:, 0, ..., 0]))

        return model, forward

    return builder


def _prose_2to1(variant):
    def builder(key, n_in):
        """PROSE ODE/PDE 2-to-1 via foundax.prose.ode_2to1 / pde_2to1 (key=):
        the 8 inputs as an observed 1-D sequence of (t_i = i/7, value_i)
        points; the text branch gets a constant one-token sequence (no Motor
        equation text exists). ode: queried at the 60 positions as times, one
        state. pde: x_grid_size=60, queried at t=1, the decoder emits the 60
        curve values. Widths fixed by the factory. Architecture only, no
        pretrained weights. Expected to fail under jit/trace (see EXPECTED)."""
        if variant == "ode":
            model = foundax.prose.ode_2to1(2, 0, max_output_dimension=1, key=key)
        else:
            model = foundax.prose.pde_2to1(2, 0, max_output_dimension=1, x_patch_size=1,
                                           x_grid_size=POINTS, key=key)

        def forward(m, x):
            n = x.shape[0]
            t = jnp.broadcast_to(jnp.linspace(0.0, 1.0, n_in, dtype=x.dtype)[:, None], (n_in, n))
            data = jnp.stack([t, x.T], -1)
            lengths = jnp.full((n,), n_in, jnp.int32)
            text, text_lengths = jnp.ones((1, n), jnp.int32), jnp.ones((n,), jnp.int32)
            if variant == "ode":
                out = m(data, lengths, jnp.asarray(POS, x.dtype), text, text_lengths)
                return _f64(out[..., 0].T)
            out = m(data, lengths, jnp.ones((1,), x.dtype), text, text_lengths)
            return _f64(out[0])

        return model, forward

    return builder


ENTRIES = {
    "linear": _linear,
    "mlp": _mlp,
    "fno1d": _fno1d,
    "fno2d": _fno2d,
    "fno3d": _fno3d,
    "deeponet": _deeponet,
    "cno2d": _cno2d,
    "unet1d": _unet1d,
    "unet2d": _unet2d,
    "unet3d": _unet3d,
    "mgno1d": _mgno1d,
    "mgno2d": _mgno2d,
    "geofno": _geofno,
    "pcno": _pcno,
    "cgptno": _cgptno,
    "gnot": _gnot,
    "moegptno": _moegptno,
    "pit": _pit,
    "pointnet": _pointnet,
    "transformer": _transformer,
    "dpot": _dpot,
    "poseidon": _poseidon,
    "morph": _morph,
    "mpp": _mpp,
    "walrus": _walrus,
    "bcat": _bcat,
    "pdeformer2": _pdeformer2,
    "prose_fd_1to1": _prose_fd("fd_1to1"),
    "prose_fd_2to1": _prose_fd("fd_2to1"),
    "prose_ode_2to1": _prose_2to1("ode"),
    "prose_pde_2to1": _prose_2to1("pde"),
}
NAMES = tuple(ENTRIES)


def build_backbone(name, key, n_in):
    """`(model, forward)` for the named entry, freshly built, or `KeyError`.
    `forward(model, x)` maps a standardised (n, n_in) batch to (n, 60) float64."""
    return ENTRIES[name](key, n_in)


__all__ = ["ENTRIES", "EXPECTED", "NAMES", "NN_SHORTCUTS", "NOT_APPLICABLE", "build_backbone"]
