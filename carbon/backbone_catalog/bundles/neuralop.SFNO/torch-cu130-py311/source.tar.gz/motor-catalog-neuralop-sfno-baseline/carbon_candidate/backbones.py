"""Open-source operator backbones adapted to Motor's job (8 inputs -> a 60-point
torque curve), for the backbone coverage matrix (DEVELOPMENT examples).

Each entry builds a fresh, untrained `torch.nn.Module` mapping a (cases, 8)
float tensor to (cases, 60). Grid operators see the case's inputs broadcast over
the curve's grid plus the grid coordinate (a 1-D function with 9 channels);
2-D-only backbones see the 60 points as a 6 x 10 grid. Nothing is downloaded or
pretrained. The adapter is stated per entry so a result can be read honestly.
"""

from __future__ import annotations

import torch

POINTS = 60
GRID_2D = (6, 10)


class OnGrid(torch.nn.Module):
    """(n, k) inputs -> (n, k + 1, 60) [or (n, k + dims, 6, 10)] -> backbone -> (n, 60)."""

    def __init__(self, backbone, n_in, two_d=False, channels_last=False, grid=GRID_2D):
        super().__init__()
        self.backbone, self.two_d, self.channels_last, self.grid = backbone, two_d, channels_last, tuple(grid)
        if two_d:
            a = torch.linspace(0.0, 1.0, self.grid[0])
            b = torch.linspace(0.0, 1.0, self.grid[1])
            yy, xx = torch.meshgrid(a, b, indexing="ij")
            self.register_buffer("coords", torch.stack([yy, xx]).unsqueeze(0))
        else:
            self.register_buffer("coords", torch.linspace(0.0, 1.0, POINTS).view(1, 1, POINTS))

    def forward(self, x):
        n, k = x.shape
        x = x.to(self.coords.dtype)
        if self.two_d:
            feats = x.view(n, k, 1, 1).expand(n, k, *self.grid)
            grid = torch.cat([feats, self.coords.expand(n, -1, -1, -1)], dim=1)
        else:
            feats = x.view(n, k, 1).expand(n, k, POINTS)
            grid = torch.cat([feats, self.coords.expand(n, -1, -1)], dim=1)
        if self.channels_last:
            grid = grid.movedim(1, -1)
        out = self.backbone(grid)
        if isinstance(out, (tuple, list)):
            out = out[0]
        if self.channels_last:
            out = out.movedim(-1, 1)
        return out.reshape(n, -1)[:, :POINTS]


def _flip_filter_once(model):
    """DISCO convolutions flip their constant local filter matrix on every forward
    (`get_local_filter_matrix`); it depends on no parameter, so it is flipped once and kept as a buffer."""
    for module in model.modules():
        if hasattr(module, "local_filter_matrix") and hasattr(module, "get_local_filter_matrix"):
            flipped = module.get_local_filter_matrix().contiguous()

            class Flipped(type(module)):
                def get_local_filter_matrix(self):
                    return self.flipped_filter_matrix

            module.__class__ = Flipped
            module.register_buffer("flipped_filter_matrix", flipped, persistent=False)
    return model


def _neuralop(name, n_in, **kw):
    import neuralop.models as m

    if not hasattr(m, name):
        # neuralop 2.0 exports LocalNO and SFNO only when torch-harmonics is installed,
        # which the Torch build base does not ship: a dependency limit.
        raise ImportError(f"neuralop.models.{name} needs torch-harmonics, not in the Torch build base")
    return _flip_filter_once(getattr(m, name)(**kw))


def _registry(n_in):
    c = n_in + 1  # channels on the 1-D grid
    c2 = n_in + 2  # channels on the 2-D grid
    return {
        # --- neuraloperator 2.0 -------------------------------------------
        "neuralop.FNO": lambda: OnGrid(
            _neuralop("FNO", n_in, n_modes=(16,), hidden_channels=32, in_channels=c, out_channels=1, n_layers=4), n_in),
        "neuralop.TFNO": lambda: OnGrid(
            _neuralop("TFNO", n_in, n_modes=(16,), hidden_channels=32, in_channels=c, out_channels=1, n_layers=4,
                      factorization="tucker", rank=0.42), n_in),
        "neuralop.UNO": lambda: OnGrid(
            _neuralop("UNO", n_in, in_channels=c, out_channels=1, hidden_channels=32, n_layers=3,
                      uno_out_channels=[32, 32, 32], uno_n_modes=[[8], [8], [8]],
                      uno_scalings=[[1.0], [1.0], [1.0]], channel_mlp_skip="linear",
                      positional_embedding=None), n_in),
        "neuralop.LocalNO": lambda: OnGrid(
            _neuralop("LocalNO", n_in, n_modes=(4, 4), in_channels=c2, out_channels=1, hidden_channels=32,
                      n_layers=4, default_in_shape=(8, 8), conv_padding_mode="zeros"), n_in, two_d=True, grid=(8, 8)),
        "neuralop.SFNO": lambda: OnGrid(
            _neuralop("SFNO", n_in, n_modes=GRID_2D, hidden_channels=32, in_channels=c2, out_channels=1,
                      n_layers=4), n_in, two_d=True),
        # CODANO's attention normalises 2-D+ fields (instance norm), so it sees the 6 x 10
        # grid; each input channel is one of its variables.
        "neuralop.CODANO": lambda: OnGrid(
            _neuralop("CODANO", n_in, output_variable_codimension=1, hidden_variable_codimension=8,
                      lifting_channels=16, use_positional_encoding=False, n_layers=2,
                      n_heads=[2, 2], n_modes=[[3, 4], [3, 4]], per_layer_scaling_factors=[[1.0, 1.0], [1.0, 1.0]],
                      attention_scaling_factors=[1.0, 1.0]), n_in, two_d=True),
        # UQNO trains in two stages (a frozen base FNO, then a residual FNO for the
        # uncertainty ball); its forward runs the base under no_grad. The adapter
        # trains and deploys stage 1, the solution head, so UQNO's operators are FNO's.
        "neuralop.UQNO": lambda: OnGrid(
            _UQNOSolution(_neuralop("UQNO", n_in,
                      base_model=_neuralop("FNO", n_in, n_modes=(16,), hidden_channels=16, in_channels=c,
                                           out_channels=1, n_layers=2),
                      residual_model=_neuralop("FNO", n_in, n_modes=(16,), hidden_channels=16, in_channels=c,
                                               out_channels=1, n_layers=2))), n_in),
        # GINO on Motor's curve as a 1-D point cloud: the 60 grid points are both the
        # input geometry and the output queries, a 16-point latent grid in between,
        # neighbour search in plain torch (no open3d / torch_scatter).
        "neuralop.GINO": lambda: _GINOOnCurve(c),
        # --- PhysicsNeMo 2.2 -----------------------------------------------
        "physicsnemo.FNO": lambda: OnGrid(_physicsnemo_fno(c), n_in),
        "physicsnemo.AFNO": lambda: OnGrid(_physicsnemo_afno(c2), n_in, two_d=True),
        "physicsnemo.FullyConnected": lambda: _physicsnemo_mlp(n_in),
        "physicsnemo.MeshGraphNet": lambda: _MeshGraphNetOnCurve(c),
    }


class _UQNOSolution(torch.nn.Module):
    def __init__(self, uqno):
        super().__init__()
        self.uqno = uqno

    def forward(self, x):
        return self.uqno.base_model(x)


class _GINOOnCurve(torch.nn.Module):
    def __init__(self, c):
        super().__init__()
        import neuralop.models as m

        self.gino = m.GINO(in_channels=c, out_channels=1, gno_coord_dim=1, in_gno_radius=0.1,
                           out_gno_radius=0.1, fno_n_modes=(8,), fno_hidden_channels=32, fno_n_layers=2,
                           fno_in_channels=c, gno_embed_channels=16,
                           in_gno_channel_mlp_hidden_layers=[32, 32], out_gno_channel_mlp_hidden_layers=[32, 32],
                           gno_use_open3d=False, gno_use_torch_scatter=False)
        self.register_buffer("points", torch.linspace(0.0, 1.0, POINTS).view(1, POINTS, 1))
        self.register_buffer("latent", torch.linspace(0.0, 1.0, 16).view(1, 16, 1))

    def forward(self, x):
        n, k = x.shape
        x = x.to(self.points.dtype)
        feats = torch.cat([x.view(n, 1, k).expand(n, POINTS, k), self.points.expand(n, -1, -1)], dim=-1)
        out = self.gino(self.points, self.latent, self.points, x=feats)
        return out.reshape(n, POINTS)


def _physicsnemo_fno(c):
    from physicsnemo.models.fno import FNO

    return FNO(in_channels=c, out_channels=1, decoder_layers=1, decoder_layer_size=32, dimension=1,
               latent_channels=32, num_fno_layers=4, num_fno_modes=16, padding=8)


def _physicsnemo_afno(c2):
    from physicsnemo.models.afno import AFNO

    return AFNO(inp_shape=list(GRID_2D), in_channels=c2, out_channels=1, patch_size=[2, 2],
                embed_dim=32, depth=2, num_blocks=4)


class _Flat(torch.nn.Module):
    def __init__(self, inner):
        super().__init__()
        self.inner = inner

    def forward(self, x):
        return self.inner(x)


def _physicsnemo_mlp(n_in):
    from physicsnemo.models.mlp import FullyConnected

    return _Flat(FullyConnected(in_features=n_in, layer_size=64, out_features=POINTS, num_layers=4))


def _torch_scatter_standin():
    """The one `torch_scatter` function physicsnemo's PyG path calls (`scatter` over dim 0, sum or mean), in
    plain torch, registered as the `torch_scatter` module together with the version gate's answer for it."""
    import sys
    import types

    if "torch_scatter" in sys.modules:
        return

    def scatter(src, index, dim=0, out=None, dim_size=None, reduce="sum"):
        if dim != 0 or out is not None or reduce not in ("sum", "mean"):
            raise NotImplementedError("torch_scatter stand-in: scatter(dim=0, reduce=sum|mean) only")
        size = int(index.max()) + 1 if dim_size is None else dim_size
        summed = torch.zeros((size,) + tuple(src.shape[1:]), dtype=src.dtype, device=src.device).index_add(0, index, src)
        if reduce == "sum":
            return summed
        counts = torch.zeros(size, dtype=src.dtype, device=src.device).index_add(
            0, index, torch.ones(index.shape[0], dtype=src.dtype, device=src.device)
        )
        return summed / counts.clamp(min=1).view(-1, *([1] * (src.dim() - 1)))

    module = types.ModuleType("torch_scatter")
    module.scatter = scatter
    sys.modules["torch_scatter"] = module
    import physicsnemo.core.version_check as version_check

    real = version_check.check_version_spec
    version_check.check_version_spec = lambda name, *a, **k: True if name == "torch_scatter" else real(name, *a, **k)


def _constant_graph_helpers():
    """`concat_efeat` / `aggregate_and_concat` for a graph whose edge list is a numpy constant
    (`graph.src_np`, `graph.dst_np`): the same values physicsnemo's PyG versions compute, with
    constant indices (`index_select` gathers, a `scatter_add` accumulation)."""
    import numpy as np
    from physicsnemo.nn.module.gnn_layers import mesh_graph_mlp, mesh_node_block

    if getattr(mesh_graph_mlp.concat_efeat, "_carbon_constant", False):
        return

    def concat_efeat(efeat, nfeat, graph):
        src_feat, dst_feat = nfeat if isinstance(nfeat, tuple) else (nfeat, nfeat)
        src = torch.as_tensor(graph.src_np).to(efeat.device)
        dst = torch.as_tensor(graph.dst_np).to(efeat.device)
        return torch.cat((efeat, src_feat.index_select(0, src), dst_feat.index_select(0, dst)), dim=1)

    def aggregate_and_concat(efeat, nfeat, graph, aggregation):
        # The batch is `cases` copies of one chain graph, edges case-major: each case's per-node edge sum is a
        # product with one constant (nodes x edges) 0/1 matrix, whatever the batch size.
        cases, nodes = graph.cases, graph.nodes_per_case
        local = graph.dst_local
        matrix = np.zeros((nodes, len(local)), dtype=np.float64)
        matrix[local, np.arange(len(local))] = 1.0
        if aggregation == "mean":
            matrix = matrix / np.maximum(matrix.sum(axis=1, keepdims=True), 1.0)
        elif aggregation != "sum":
            raise ValueError(aggregation)
        per_case = efeat.reshape(cases, len(local), efeat.shape[1])
        summed = torch.matmul(torch.as_tensor(matrix, dtype=efeat.dtype, device=efeat.device), per_case)
        return torch.cat((summed.reshape(cases * nodes, efeat.shape[1]), nfeat), -1)

    concat_efeat._carbon_constant = True
    mesh_graph_mlp.concat_efeat = concat_efeat
    mesh_node_block.aggregate_and_concat = aggregate_and_concat


class _MeshGraphNetOnCurve(torch.nn.Module):
    """physicsnemo MeshGraphNet on Motor's curve as a 60-node chain graph: node features are the case's
    inputs plus the node position, edge features the signed position step, one output per node."""

    def __init__(self, c):
        super().__init__()
        _torch_scatter_standin()
        _constant_graph_helpers()
        from physicsnemo.models.meshgraphnet import MeshGraphNet

        self.net = MeshGraphNet(input_dim_nodes=c, input_dim_edges=1, output_dim=1, processor_size=2,
                                hidden_dim_node_encoder=16, hidden_dim_edge_encoder=16, hidden_dim_node_decoder=16)
        source = torch.arange(POINTS - 1)
        edges = torch.stack([torch.cat([source, source + 1]), torch.cat([source + 1, source])])
        step = torch.full((POINTS - 1,), 1.0 / (POINTS - 1))
        self.edges_np = edges.numpy()  # a numpy constant: the batch's edge list is built from it at trace time
        self.register_buffer("edge_attr", torch.cat([step, -step]).view(-1, 1), persistent=False)
        self.register_buffer("positions", torch.linspace(0.0, 1.0, POINTS).view(POINTS, 1), persistent=False)

    def forward(self, x):
        import numpy as np
        from torch_geometric.data import Data

        n = x.shape[0]
        x = x.to(self.positions.dtype)
        nodes = torch.cat([x.view(n, 1, -1).expand(n, POINTS, x.shape[1]), self.positions.expand(n, POINTS, 1)], dim=-1)
        # the batch's block-diagonal edge list, built from the (static) batch size as a constant
        edges_np = (self.edges_np.reshape(2, 1, -1) + POINTS * np.arange(n).reshape(1, n, 1)).reshape(2, -1)
        edges = torch.as_tensor(edges_np).to(x.device)
        graph = Data(edge_index=edges, num_nodes=n * POINTS)
        graph.src_np, graph.dst_np = edges_np[0], edges_np[1]
        graph.cases, graph.nodes_per_case, graph.dst_local = n, POINTS, self.edges_np[1]
        out = self.net(nodes.reshape(n * POINTS, -1), self.edge_attr.repeat(n, 1), graph)
        return out.view(n, POINTS)


def _physicsnemo_meshgraphnet(c):
    # PhysicsNeMo 2.2's MeshGraphNet message passing needs torch_geometric (PyG),
    # which the Torch build base does not ship: a dependency limit, recorded as such.
    from physicsnemo.nn.module.gnn_layers.utils import PYG_AVAILABLE

    if not PYG_AVAILABLE:
        raise ImportError("MeshGraphNet needs torch_geometric, not in the Torch build base")
    from physicsnemo.models.meshgraphnet import MeshGraphNet

    return MeshGraphNet(input_dim_nodes=c, input_dim_edges=1, output_dim=1, processor_size=2,
                        hidden_dim_node_encoder=16, hidden_dim_edge_encoder=16, hidden_dim_node_decoder=16)


NAMES = tuple(_registry(8))


def build_backbone(name, n_in):
    """The named backbone as a fresh module, or `KeyError`."""
    return _registry(n_in)[name]()
