"""Stress S7, Transolver: the original THUML Transolver irregular-mesh model
(pinned upstream commit 75e0f676, vendored beside this package with its MIT
licence) over the 60-point torque curve. Points are the curve's grid (space
dim 1); each point's features are the case's 8 inputs."""

from __future__ import annotations

import hashlib
import importlib
import sys
from pathlib import Path

import torch

from .common import DEVICE, fit, module_product, only, positive_int, prepare, rate

ROOT = Path(__file__).resolve().parent.parent
UPSTREAM = ROOT / "Transolver-75e0f67643806a81cd1d3f6adc88dd8c02416fe7"
BENCHMARK = UPSTREAM / "PDE-Solving-StandardBenchmark"
SOURCE_HASHES = {
    "model/Transolver_Irregular_Mesh.py": "5259759f7ecc6a954c8442ac8359990b9f242f1437c452c69e5e0f03549b5311",
    "model/Embedding.py": "1371e3c234d2d29be783ee817ecc7e65e8e0b36024b95b6c3c256b2054a9720d",
    "model/Physics_Attention.py": "4fc710f6f96788fb59cb19fab8d64873d3d16e9e182f12a544d451c74c548cc7",
}


def _model_class():
    for relative, expected in SOURCE_HASHES.items():
        body = (BENCHMARK / relative).read_bytes()
        if hashlib.sha256(body).hexdigest() != expected:
            raise RuntimeError("pinned Transolver source differs: " + relative)
    if str(BENCHMARK) not in sys.path:
        sys.path.insert(0, str(BENCHMARK))  # upstream uses `from model.* import`
    return importlib.import_module("model.Transolver_Irregular_Mesh").Model


class CurveTransolver(torch.nn.Module):
    def __init__(self, model, points):
        super().__init__()
        self.model = model
        self.register_buffer(
            "grid", torch.linspace(0.0, 1.0, points, dtype=torch.float64).view(1, points, 1)
        )

    def forward(self, x):  # (n, 8) -> (n, points)
        n, points = x.shape[0], self.grid.shape[1]
        positions = self.grid.expand(n, points, 1)
        features = x.unsqueeze(1).expand(n, points, x.shape[1])
        return self.model(positions, features, T=None)[:, :, 0]


def build(train_inputs, train_targets, *, seed, configuration, train_use):
    only(configuration, {"layers", "hidden", "heads", "slices", "learning_rate"}, "configuration")
    only(train_use, {"steps"}, "train_use")
    layers = positive_int(configuration.get("layers"), "layers", 2)
    hidden = positive_int(configuration.get("hidden"), "hidden", 32)
    heads = positive_int(configuration.get("heads"), "heads", 4)
    slices = positive_int(configuration.get("slices"), "slices", 8)
    lr = rate(configuration.get("learning_rate"), 1e-3)
    steps = positive_int(train_use.get("steps"), "steps", 200)
    if hidden % heads:
        raise ValueError("hidden must be a multiple of heads")
    z, t, stats = prepare(train_inputs, train_targets, seed)
    Model = _model_class()
    model = CurveTransolver(
        Model(
            space_dim=1,
            fun_dim=z.shape[1],
            out_dim=1,
            n_layers=layers,
            n_hidden=hidden,
            n_head=heads,
            slice_num=slices,
            dropout=0.0,
            Time_Input=False,
            unified_pos=False,
        ),
        t.shape[1],
    ).double()
    return module_product(fit(model.to(DEVICE), z, t, steps, lr), stats)


# --- F02 readout (see backbones.py) ---
_curve_forward = CurveTransolver.forward


def _curve_forward_mean(self, *args, **kwargs):
    return _curve_forward(self, *args, **kwargs).mean(dim=-1, keepdim=True)


CurveTransolver.forward = _curve_forward_mean
