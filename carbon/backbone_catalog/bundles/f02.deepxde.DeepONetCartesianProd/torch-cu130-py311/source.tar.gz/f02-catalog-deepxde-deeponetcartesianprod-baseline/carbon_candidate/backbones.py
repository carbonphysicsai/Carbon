"""THUML Neural-Solver-Library backbones on Motor's job (packs lane, DEVELOPMENT).

Each entry builds a fresh, untrained `torch.nn.Module` mapping (cases, 8) Motor
inputs to (cases, 60) torque points, using the library's own model classes
unmodified: the upstream tree (commit db942b7, MIT licence) is vendored beside
this module and every file is sha256-checked before import. Models are
constructed exactly as the library's `run.py` does, `Model(args)`, from its
documented argument defaults with only the problem's shape overridden. The 60
curve points are the mesh (space dim 1, position in [0, 1]); every point carries
the case's 8 inputs as its observed function. `structured_1D` entries treat the
60 points as a regular 1-D grid; `unstructured` entries as a point cloud (for
FNO that is the library's Geo-FNO projection). Nothing is downloaded or
pretrained. Same registry shape as Launchpad's `backbones.py`.
"""

from __future__ import annotations

import hashlib
import importlib
import sys
from pathlib import Path
from types import SimpleNamespace

import torch

POINTS = 1  # this Challenge's outputs
LIBRARY = "neural-solver-library-db942b7"
SOURCE_HASHES = {
    "layers/Basic.py": "f5315fa5148ed0401b35b263dd3451b92581080a134d7e1a8ce1acb1f7d63b26",
    "layers/Embedding.py": "135678a3058155be4f000233dd2010b8bfd020e8a16e0cc80acce335e5191741",
    "layers/FFNO_Layers.py": "24ef13cc49298a0c71c492003a0ed0b212327e4b8f89e859d9675604cca492c3",
    "layers/FNO_Layers.py": "19f69d6cdf714c77476002a52a6fdece0a4bafe083f8e0a086f41412e2d133cd",
    "layers/GeoFNO_Projection.py": "8e6f84466cdf8d2c06e478a9f993953c96ae45fe3776c7d9611037596d0b162f",
    "layers/MWT_Layers.py": "1b251447e22f2c229e625b8291c4aaf640d2e1e894a9d05f9d29036e77991d12",
    "layers/Neural_Spectral_Block.py": "678f0dc429830f95e0a3bd02154088c297870b5a035290c293690b2118276d64",
    "layers/UNet_Blocks.py": "6b4c394dfd53afc3750f3a4e4a03cca6088a19beee588c37f334677cb66773c5",
    "models/FNO.py": "297beafbe0a9640cc6670b134fb7286c3e2a7248f0eff6d060ae286a9102b040",
    "models/F_FNO.py": "03c8525abf6dbf5754561b049aafadd7e554b61edeec27abba337b80b4968430",
    "models/Factformer.py": "dc02a43acade23b0bbf3896d7a7a9f4130acf4faee3113677618495e7a604607",
    "models/GNOT.py": "5657dd7be52f6da16a76551dcc4cc032e1346163eddedd12d706bd6bb03190dd",
    "models/Galerkin_Transformer.py": "885e06bfa9d8b119671e4d9e9dda6fecc7120d8b407bfc42f579d8be898d6292",
    "models/LSM.py": "0e4a1f2fc8db1e30b4dd7f2aee74f7d2a72e63d57d116a909527f95a293c3ac4",
    "models/MWT.py": "f96f166ce804c4738020264d546bb204365ce389847c3f62522d5e018a97155a",
    "models/ONO.py": "dcee17e3637ee735829a736b336779750220b6e5e8252eca4a45879ec6d7ad1a",
    "models/Transformer.py": "71eff776e1209910126517bdefee809c2c0c67830a04ee9acecb542875ba0bad",
    "models/U_FNO.py": "44b275acdb94a1e16142400e51048d6c1e3cb50d78c7f26caf02307b8d3737ba",
    "models/U_NO.py": "9ba2b4cefe3abfe06c9624e9a6898532c7f37e38d2df44c9ac1a5cf7e44342e7",
    "models/U_Net.py": "cf7f140f1d9c3670b22ccd13c6246b057b63cb7a034eccdb0f30eed0407ddaa1",
    "models/Transolver.py": "6d4281397733cd89d209c94e8c2b73952c13ee880b9408ac25c41b6dca6b85b5",
    "layers/Physics_Attention.py": "ae344a0dbc99b755a2ff6afaebaf8ad0969ba7e7ea9ac2ae6665b66d039d1f0d",
}
#: The library's run.py argument defaults (only those its models read).
DEFAULTS = {
    "act": "gelu",
    "attn_type": "nystrom",
    "dropout": 0.0,
    "mlp_ratio": 1,
    "modes": 1,  # at most half this Challenge outputs
    "mwt_k": 3,
    "n_heads": 4,
    "n_hidden": 64,
    "n_layers": 3,
    "num_output_tokens": 1024,
    "psi_dim": 8,
    "ref": 8,
    "slice_num": 32,
    "task": "steady",
    "time_input": False,
    "unified_pos": 0,
}


def _root() -> Path:
    here = Path(__file__).resolve().parent
    for candidate in (here.parent / LIBRARY, here.parent / "vendor" / LIBRARY):
        if candidate.is_dir():
            return candidate
    raise RuntimeError("vendored Neural-Solver-Library tree not found")


def _model_class(name: str):
    root = _root()
    for relative, expected in SOURCE_HASHES.items():
        if hashlib.sha256((root / relative).read_bytes()).hexdigest() != expected:
            raise RuntimeError("pinned Neural-Solver-Library source differs: " + relative)
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))  # upstream imports `models.*` and `layers.*`
    return importlib.import_module(f"models.{name}").Model


class OnCurve(torch.nn.Module):
    """(n, 8) -> library model over the 60-point curve -> (n, 60)."""

    def __init__(self, model, grid=POINTS):
        super().__init__()
        self.model = model
        if grid == POINTS:
            positions = torch.linspace(0.0, 1.0, POINTS)
        else:
            # Extended curve: Motor's 60 points, then further points at the same
            # spacing; the output keeps only the first 60.
            positions = torch.arange(grid, dtype=torch.float32) / (POINTS - 1)
        self.register_buffer("grid", positions.view(1, grid, 1))

    def forward(self, x):
        n, points = x.shape[0], self.grid.shape[1]
        x = x.to(self.grid.dtype)
        positions = self.grid.expand(n, points, 1)
        features = x.unsqueeze(1).expand(n, points, x.shape[1])
        return self.model(positions, features)[:, :POINTS, 0]


def _library(name, n_in, geotype, **overrides):
    """`grid` (an adapter setting, not a library argument) runs the model on a
    longer 1-D grid. Upstream db942b7 computes 1-D padding for U-Net, U-FNO,
    U-NO and MWT but applies it only for 2-D and 3-D meshes, so a 60-point
    curve breaks their down/up-sampling (U-models need a multiple of 16, MWT a
    power of 2). Those run on 64 points: Motor's 60 plus 4 beyond the end."""
    grid = overrides.pop("grid", POINTS)
    args = SimpleNamespace(
        **{**DEFAULTS, **overrides},
        model=name,
        geotype=geotype,
        space_dim=1,
        fun_dim=n_in,
        out_dim=1,
        shapelist=[grid] if geotype == "structured_1D" else None,
    )
    return OnCurve(_model_class(name)(args), grid=grid)


#: (library model, geometry type, overrides). Sizes stay small so a rebuild is
#: minutes on CPU; overrides only change capacity, never the method.
ENTRIES = {
    "thuml.FNO": ("FNO", "structured_1D", {"n_hidden": 32}),
    "thuml.GeoFNO": ("FNO", "unstructured", {"n_hidden": 32}),
    "thuml.F_FNO": ("F_FNO", "structured_1D", {"n_hidden": 32}),
    "thuml.U_FNO": ("U_FNO", "structured_1D", {"n_hidden": 32, "grid": 64}),
    "thuml.U_NO": ("U_NO", "structured_1D", {"n_hidden": 32, "grid": 64}),
    "thuml.MWT": ("MWT", "structured_1D", {"n_hidden": 32, "grid": 64}),
    "thuml.LSM": ("LSM", "structured_1D", {"n_hidden": 32}),
    "thuml.U_Net": ("U_Net", "structured_1D", {"n_hidden": 32, "grid": 64}),
    "thuml.GNOT": ("GNOT", "unstructured", {"n_hidden": 32}),
    "thuml.Galerkin_Transformer": ("Galerkin_Transformer", "unstructured", {"n_hidden": 32}),
    "thuml.Transformer": ("Transformer", "unstructured", {"n_hidden": 32}),
    "thuml.Factformer": ("Factformer", "structured_1D", {"n_hidden": 32}),  # refuses unstructured
    "thuml.ONO": ("ONO", "unstructured", {"n_hidden": 32}),
    "thuml.Transolver": ("Transolver", "unstructured", {"n_hidden": 32, "slice_num": 8}),
}


# --- Batch 2: other upstream research codes (pinned commits, vendored) -------
#: (vendored dir, {file: sha256}). Each tree keeps its own upstream LICENSE.
UPSTREAM = {
    "cno-6e76519": {  # camlab-ethz/ConvolutionalNeuralOperator, MIT
        "LICENSE": "687a617aa02794f450a493bccab173fa2da18c5973761b79b3170747266c7d90",
        "CNO1d_simplified/CNO1d.py": "628b4109da7a17c68bba5b9cc97fe27d6f8f891f35d7e56b759766388a68c82e",
    },
    "lno-78c64ef": {  # qianyingcao/Laplace-Neural-Operator, MIT
        "LICENSE": "6c0bb34f39076b7c40c792c6253e4f589484e95fb546a1f24a2aa02d6820fc62",
        "1D_Pendulum_c0/main.py": "a9e20ea59c29f14ddcf6411c3443c449eb88fafa79d98bbbcd1122ce661b0b1e",
    },
    "oformer-f1111b3": {  # BaratiLab/OFormer, MIT
        "LICENSE": "fccaaedad8a1e8803e37b260a376d918b9a9fa6c940ffc09df158a8f592d81a2",
        "uniform_grids/nn_module/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "uniform_grids/nn_module/attention_module.py": "4cf124a9d5f2f6688408c88c269e3185190e33290c5c5284791f9827dda08c8f",
        "uniform_grids/nn_module/cnn_module.py": "11fcbfd7398a0e3f6763362c944eb719d8cd3fde3e820dcfb28146b18f575fcf",
        "uniform_grids/nn_module/decoder_module.py": "f6581892938c9a27cc2f3e49e35eb9e32385fef527affd9642dfa8453366a11b",
        "uniform_grids/nn_module/encoder_module.py": "a0bcf389718de4f271609d39fa53c5edd30612c743fdbac6e3572ab487741547",
    },
}


def _tree(name: str) -> Path:
    here = Path(__file__).resolve().parent
    for root in (here.parent / name, here.parent / "vendor" / name):
        if root.is_dir():
            for relative, expected in UPSTREAM[name].items():
                if hashlib.sha256((root / relative).read_bytes()).hexdigest() != expected:
                    raise RuntimeError(f"pinned {name} source differs: {relative}")
            return root
    raise RuntimeError(f"vendored {name} tree not found")


def _file_module(path: Path, name: str):
    """Import one pinned upstream file, keeping the caller's RNG state (some
    upstream modules reseed torch at import)."""
    import importlib.util

    state = torch.random.get_rng_state()
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    torch.random.set_rng_state(state)
    return module


class OnGrid(torch.nn.Module):
    """(n, k) -> channels-first (n, k + 1, 60) or channels-last (n, 60, k + 1)
    grid of the case's inputs plus the coordinate -> backbone -> (n, 60).
    Same adapter as Launchpad's `backbones.OnGrid` (1-D case); a tuple output
    takes its first element; a multi-channel output takes channel 0."""

    def __init__(self, backbone, channels_last=False):
        super().__init__()
        self.backbone, self.channels_last = backbone, channels_last
        self.register_buffer("coords", torch.linspace(0.0, 1.0, POINTS).view(1, 1, POINTS))

    def forward(self, x):
        n, k = x.shape
        x = x.to(self.coords.dtype)
        grid = torch.cat([x.view(n, k, 1).expand(n, k, POINTS), self.coords.expand(n, -1, -1)], dim=1)
        if self.channels_last:
            grid = grid.movedim(1, -1)
        out = self.backbone(grid)
        if isinstance(out, (tuple, list)):
            out = out[0]
        if self.channels_last:
            out = out.movedim(-1, 1)
        return out[:, 0, :]


def _cno(n_in):
    module = _file_module(_tree("cno-6e76519") / "CNO1d_simplified" / "CNO1d.py", "dc_cno1d")
    return OnGrid(module.CNO1d(in_dim=n_in + 1, out_dim=1, size=POINTS, N_layers=2,
                               N_res=2, N_res_neck=2, channel_multiplier=16))


class _OFormer(torch.nn.Module):
    """OFormer's own 1-D encoder + point-wise decoder, as its train_burgers.py
    pairs them: encode the input points, decode at the query points."""

    def __init__(self, encoder, decoder):
        super().__init__()
        self.encoder, self.decoder = encoder, decoder

    def forward(self, grid):  # (n, 60, k + 1), last channel the coordinate
        pos = grid[..., -1:]
        z = self.encoder(grid, pos)
        return self.decoder(z, pos, pos)


def _absent_fourier_module():
    """Upstream finding: OFormer f1111b3's uniform_grids/nn_module/cnn_module.py
    imports `.fourier_neural_operator`, a file absent from that commit, so the
    package cannot import as published. Only the 2-D FourierConv2d uses it; the
    1-D Encoder1D / PointWiseDecoder1D never do. Stand in a module whose class
    refuses construction, so any use of the missing code fails loudly."""
    import types

    importlib.import_module("nn_module")
    name = "nn_module.fourier_neural_operator"
    if name in sys.modules:
        return

    class SpectralConv2d_fast:  # noqa: N801 - upstream's name
        def __init__(self, *args, **kwargs):
            raise RuntimeError("OFormer f1111b3 lacks fourier_neural_operator.py")

    stand_in = types.ModuleType(name)
    stand_in.SpectralConv2d_fast = SpectralConv2d_fast
    sys.modules[name] = stand_in
    sys.modules["nn_module"].fourier_neural_operator = stand_in


def _oformer(n_in):
    root = _tree("oformer-f1111b3") / "uniform_grids"
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))  # upstream imports the `nn_module` package
    _absent_fourier_module()
    state = torch.random.get_rng_state()
    encoder_module = importlib.import_module("nn_module.encoder_module")
    decoder_module = importlib.import_module("nn_module.decoder_module")
    torch.random.set_rng_state(state)
    encoder = encoder_module.Encoder1D(n_in + 1, 32, 32, 4, res=POINTS)
    decoder = decoder_module.PointWiseDecoder1D(32, 1, 3, scale=2, res=POINTS)
    return OnGrid(_OFormer(encoder, decoder), channels_last=True)


def _lno(n_in):
    """The upstream PR and LNO1d classes, executed unmodified from the pinned
    research script (its module-level data loading and training are not run).
    Upstream PR.forward reads a global `grid_x_train` and calls `.cuda()`: the
    adapter supplies Motor's 60-point grid as that global and a learned
    8 -> 1 projection, because LNO1d takes one input channel. A CPU-only host
    therefore fails at forward: that is the upstream code's own requirement."""
    import ast

    import numpy as np

    path = _tree("lno-78c64ef") / "1D_Pendulum_c0" / "main.py"
    tree = ast.parse(path.read_text(encoding="utf-8"))
    keep = [n for n in tree.body if isinstance(n, ast.ClassDef) and n.name in ("PR", "LNO1d")]
    namespace = {"torch": torch, "nn": torch.nn, "F": torch.nn.functional, "np": np,
                 "time": __import__("time"),
                 "grid_x_train": torch.linspace(0.0, 1.0, POINTS)}
    exec(compile(ast.Module(body=keep, type_ignores=[]), str(path), "exec"), namespace)

    class _OneChannel(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.project = torch.nn.Linear(n_in + 1, 1)
            self.lno = namespace["LNO1d"](4, 20)

        def forward(self, grid):  # (n, 60, k + 1)
            return self.lno(self.project(grid))

    return OnGrid(_OneChannel(), channels_last=True)


BATCH2 = {
    "cno.CNO1d": _cno,
    "oformer.Encoder1D_PointWiseDecoder1D": _oformer,
    "lno.LNO1d": _lno,
}


# --- Batch 3: wheel-installed libraries (pinned wheels in the packet) --------
def _deepxde():
    """Import DeepXDE (wheel 1.15.0) on its PyTorch backend, restoring the
    process-wide torch defaults its backend import changes (default device on a
    CUDA host, default dtype)."""
    import os

    os.environ["DDE_BACKEND"] = "pytorch"
    dtype = torch.get_default_dtype()
    device = torch.get_default_device()
    import deepxde

    torch.set_default_dtype(dtype)
    torch.set_default_device(device)
    return deepxde


class _DeepONet(torch.nn.Module):
    """DeepXDE's DeepONetCartesianProd: the branch net reads the case's 8
    inputs, the trunk net the 60 curve positions; output (n, 60)."""

    def __init__(self, model):
        super().__init__()
        self.model = model
        self.register_buffer("positions", torch.linspace(0.0, 1.0, POINTS).view(POINTS, 1))

    def forward(self, x):
        x = x.to(self.positions.dtype)
        return self.model((x, self.positions))


def _deeponet(n_in):
    dde = _deepxde()
    return _DeepONet(dde.nn.DeepONetCartesianProd(
        [n_in, 64, 64, 32], [1, 64, 64, 32], "tanh", "Glorot normal"))


UPSTREAM["transolver_plus-d5a23"] = {  # thuml/Transolver_plus, MIT
    "LICENSE": "996b7ed7b544265d5759c96e1918588129d7a1c50024a80afc111c2324755e8c",
    "models/Transolver_plus.py": "b5b73c2b1f21f06397bd53d800bb70627033920e5c95d4ecb2b0527cfc225a24",
}


class _TransolverPlus(torch.nn.Module):
    """Transolver++'s own Model: each curve point's token is its position plus
    the case's inputs; no condition vector. Note upstream samples Gumbel noise in
    its slice attention, which the probe and judge will show as they find it."""

    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, grid):  # (n, 60, k + 1), last channel the coordinate
        pos = grid[..., -1:]
        tokens = torch.cat([pos, grid[..., :-1]], dim=-1)
        return self.model((tokens, pos, None))


class _SingleProcess:
    """Stand-in for torch.distributed.nn in Transolver++'s module namespace.
    Upstream calls `dist_nn.all_reduce(t, op=SUM)` and discards the returned
    tensor (the functional all_reduce does not write in place), so the call
    never affects outputs; one process needs no process group. Upstream finding:
    without a group the call raises, so the published Model is multi-GPU only."""

    class ReduceOp:
        SUM = "sum"

    @staticmethod
    def all_reduce(tensor, op=None, group=None):
        return tensor


def _transolver_plus(n_in):
    module = _file_module(_tree("transolver_plus-d5a23") / "models" / "Transolver_plus.py",
                          "dc_transolver_plus")
    module.dist_nn = _SingleProcess
    model = module.Model(space_dim=1, n_layers=2, n_hidden=32, n_head=4, fun_dim=n_in,
                         out_dim=1, slice_num=8)
    return OnGrid(_TransolverPlus(model), channels_last=True)


BATCH3 = {
    "deepxde.DeepONetCartesianProd": _deeponet,
    "thuml.Transolver_plus": _transolver_plus,
}
#: Pinned wheels each batch-3 entry installs (name -> sha256); see assemble_dc.
WHEELS = {
    "thuml.ONO": ("nystrom_attention-0.0.14-py3-none-any.whl",),  # ONO's default nystrom attention
    "deepxde.DeepONetCartesianProd": (
        "deepxde-1.15.0-py3-none-any.whl",
        "scikit_learn-1.7.2-cp311-cp311-manylinux2014_x86_64.manylinux_2_17_x86_64.whl",
        "scikit_optimize-0.10.2-py2.py3-none-any.whl",
        "joblib-1.5.2-py3-none-any.whl",
        "threadpoolctl-3.6.0-py3-none-any.whl",
        "pyaml-25.7.0-py3-none-any.whl",
    ),
}


def _registry(n_in):
    entries = {
        key: (lambda m=m, g=g, o=o: _library(m, n_in, g, **o))
        for key, (m, g, o) in ENTRIES.items()
    }
    entries.update({key: (lambda f=f: f(n_in)) for key, f in {**BATCH2, **BATCH3}.items()})
    return entries


NAMES = tuple(ENTRIES) + tuple(BATCH2) + tuple(BATCH3)


def build_backbone(name, n_in):
    """The named backbone as a fresh module, or `KeyError`."""
    return _registry(n_in)[name]()
