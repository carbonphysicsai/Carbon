/* Strict read-only adapter for source-owned C-05 public DEVELOPMENT evidence. */
(function (root) {
  "use strict";
  const F = root.CarbonFit;
  const BUNDLE_VERSION = "carbon.goal-workbench.c05-evidence-bundle.v1";
  const ASSOCIATION_VERSION =
    "carbon.goal-workbench.c05-evidence-association.v1";
  const REQUEST_SCHEMA = "carbon.c05.burgers-measurement.v1";
  const RESULT_SCHEMA = "carbon.c05.burgers-measurement-result.v1";
  const SCOPE = "PUBLIC_QUALIFICATION_CANDIDATE_ONLY";
  const OUTPUT = "RAW_UNCERTAINTY_BEARING_NO_SCORE_INPUT";
  const MEASUREMENTS = [
    "field_phase_rms",
    "maximum_compression",
    "peak_dissipation",
    "energy_half_time",
  ];
  const PHYSICS = [
    "initial_condition",
    "periodicity",
    "conserved_mean",
    "maximum_principle",
    "energy_dissipation_balance",
    "weak_local_pde",
  ];
  const DISPOSITIONS = [
    "COMPLETE_DEVELOPMENT_ONLY",
    "UNSUPPORTED",
    "INVALID",
    "REFERENCE_UNRESOLVED",
    "NUMERICAL_FAILURE",
    "CANCELLED",
    "INFRASTRUCTURE_FAILURE",
  ];
  const CLASSIFICATIONS = [
    "OBSERVABLE_WITH_CURRENT_C05_RESULT",
    "REQUIRES_DEDICATED_PUBLIC_FIXTURE",
    "REQUIRES_QUALIFIED_FLOOR_OR_UNCERTAINTY",
    "REQUIRES_SCOREPACK_DIAGNOSTIC_CONTRACT",
    "NOT_APPLICABLE",
  ];
  const EXAMPLES = [
    "PEAK_MISSED",
    "OVERSMOOTHED",
    "MANDATORY_FAILURE",
    "NONFINITE_OR_WITHHELD",
    "DROPPED_WORK",
    "UNIT_OR_FLOOR",
    "BELOW_UNCERTAINTY",
    "PERSISTENCE_OR_MEMORIZATION",
  ];
  let fixtureIndex = null;
  const verifiedRecords = new WeakSet();
  const clone = (v) => JSON.parse(JSON.stringify(v));
  function exact(o, keys, label) {
    if (
      !o ||
      typeof o !== "object" ||
      Array.isArray(o) ||
      Object.keys(o).sort().join("|") !== [...keys].sort().join("|")
    )
      throw Error("SOURCE_MEASUREMENT_EVIDENCE_REJECTED: " + label + " fields");
    return o;
  }
  function string(v, label, max = 8000) {
    if (typeof v !== "string" || !v || v.length > max || /[^\x20-\x7e]/.test(v))
      throw Error("SOURCE_MEASUREMENT_EVIDENCE_REJECTED: " + label);
    return v;
  }
  function digest(v, label) {
    string(v, label, 71);
    if (!/^sha256:[a-f0-9]{64}$/.test(v))
      throw Error("SOURCE_MEASUREMENT_EVIDENCE_REJECTED: " + label);
    return v;
  }
  function number(v, label, { nonnegative = false, positive = false } = {}) {
    if (
      typeof v !== "number" ||
      !Number.isFinite(v) ||
      (nonnegative && v < 0) ||
      (positive && v <= 0)
    )
      throw Error("SOURCE_MEASUREMENT_EVIDENCE_REJECTED: " + label);
    return v;
  }
  function stable(v) {
    if (Array.isArray(v)) return v.map(stable);
    if (v && typeof v === "object")
      return Object.fromEntries(
        Object.keys(v)
          .sort()
          .map((k) => [k, stable(v[k])]),
      );
    return v;
  }
  function same(a, b, label) {
    if (JSON.stringify(stable(a)) !== JSON.stringify(stable(b)))
      throw Error("SOURCE_MEASUREMENT_EVIDENCE_REJECTED: " + label);
  }
  function installFixtureIndex(value) {
    exact(
      value,
      ["schema_version", "source_interface", "fixtures", "authority"],
      "fixture index",
    );
    if (
      value.schema_version !== "carbon.goal-workbench.c05-fixture-index.v2" ||
      value.authority !== "PUBLIC_DEVELOPMENT_BYTES_ONLY_NO_QUALIFICATION"
    )
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: fixture index authority",
      );
    exact(
      value.source_interface,
      ["request_schema", "result_schema", "measurement_ids", "physics_ids"],
      "source interface",
    );
    if (
      value.source_interface.request_schema !== REQUEST_SCHEMA ||
      value.source_interface.result_schema !== RESULT_SCHEMA
    )
      same(false, true, "source interface schema");
    same(
      value.source_interface.measurement_ids,
      MEASUREMENTS,
      "measurement interface",
    );
    same(value.source_interface.physics_ids, PHYSICS, "physics interface");
    if (
      !Array.isArray(value.fixtures) ||
      !value.fixtures.length ||
      value.fixtures.length > 16
    )
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: fixture index entries",
      );
    for (const item of value.fixtures) {
      exact(
        item,
        [
          "fixture_id",
          "request_digest",
          "result_digest",
          "case_digest",
          "candidate_artifact_digest",
          "candidate_binding_digest",
          "candidate_source_digest",
          "candidate_environment_digest",
          "candidate_plan_digest",
          "candidate_replica_id",
          "measurement_contract_digest",
          "measurement_environment_digest",
          "measurement_implementation_digest",
          "source_revision",
          "association",
          "saved_projection",
        ],
        "fixture entry",
      );
      exact(
        item.association,
        [
          "request_id",
          "job_id",
          "design_id",
          "design_revision",
          "requirement_trace_ids",
          "case_family_ids",
          "challenge",
          "template_id",
          "expected_source_interface",
          "evidence_scope",
        ],
        "registered fixture association",
      );
      for (const key of Object.keys(item)) {
        if (key === "association" || key === "saved_projection") continue;
        if (key === "fixture_id" || key === "candidate_replica_id")
          string(item[key], key, 160);
        else if (key === "source_revision") {
          string(item[key], key, 40);
          if (!/^[a-f0-9]{40}$/.test(item[key]))
            throw Error(
              "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: source revision",
            );
        } else digest(item[key], key);
      }
      exact(
        item.saved_projection,
        [
          "evidence_state",
          "source_disposition",
          "measurements",
          "physics",
          "diagnostics",
          "behavior_classification",
          "limitations",
          "trace_state",
          "imported_artifact_digest",
        ],
        "saved fixture projection",
      );
      digest(
        item.saved_projection.imported_artifact_digest,
        "saved fixture artifact digest",
      );
    }
    fixtureIndex = clone(value);
    return clone(value);
  }
  function requestDocument(v) {
    exact(
      v,
      [
        "schema",
        "scope",
        "challenge",
        "case_digest",
        "candidate",
        "reference",
        "measurement",
        "query",
        "eligibility",
      ],
      "C-05 request",
    );
    exact(v.challenge, ["id", "version"], "challenge");
    exact(
      v.candidate,
      [
        "artifact_digest",
        "binding_digest",
        "source_digest",
        "environment_digest",
        "plan_digest",
        "replica_id",
      ],
      "candidate",
    );
    exact(
      v.reference,
      [
        "artifact_digest",
        "request_digest",
        "policy_digest",
        "environment_digest",
        "role",
        "scientifically_qualified",
      ],
      "reference",
    );
    exact(
      v.measurement,
      [
        "policy_id",
        "policy_version",
        "contract_digest",
        "environment_digest",
        "implementation_digest",
        "precision",
        "operator_ids",
        "physics_ids",
        "scientific_limits",
        "uncertainty_policy",
        "scientifically_qualified",
      ],
      "measurement",
    );
    exact(
      v.query,
      [
        "spatial_points",
        "requested_times",
        "initial_values",
        "domain_length",
        "viscosity",
        "characteristic_time",
        "amplitude",
        "k_rms",
        "output_semantics",
      ],
      "query",
    );
    exact(
      v.eligibility,
      [
        "development_only",
        "protected_execution",
        "reference_scientifically_qualified",
        "measurement_scientifically_qualified",
        "score",
      ],
      "request eligibility",
    );
    if (
      v.schema !== REQUEST_SCHEMA ||
      v.scope !== SCOPE ||
      v.challenge.id !== "burgers-dynamics-v1" ||
      v.challenge.version !== "1.0" ||
      v.measurement.policy_id !== "carbon.burgers.measurement.candidate.v1" ||
      v.measurement.policy_version !== "1.0" ||
      v.measurement.precision !== "float64" ||
      v.query.output_semantics !== "POINT_VALUE_U_T_X_REQUEST_ORDER_FLOAT64" ||
      v.reference.role !== "CANDIDATE_PRIMARY"
    )
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: source request interface",
      );
    same(v.measurement.operator_ids, MEASUREMENTS, "source measurement IDs");
    same(v.measurement.physics_ids, PHYSICS, "source physics IDs");
    if (
      v.measurement.scientific_limits !== null ||
      v.measurement.uncertainty_policy !== null ||
      v.measurement.scientifically_qualified !== false ||
      v.reference.scientifically_qualified !== false
    )
      same(false, true, "forged source qualification");
    same(
      v.eligibility,
      {
        development_only: true,
        protected_execution: false,
        reference_scientifically_qualified: false,
        measurement_scientifically_qualified: false,
        score: false,
      },
      "request eligibility",
    );
    for (const key of ["case_digest"]) digest(v[key], key);
    for (const key of [
      "artifact_digest",
      "binding_digest",
      "source_digest",
      "environment_digest",
      "plan_digest",
    ])
      digest(v.candidate[key], "candidate " + key);
    string(v.candidate.replica_id, "candidate replica", 160);
    for (const key of [
      "artifact_digest",
      "request_digest",
      "policy_digest",
      "environment_digest",
    ])
      digest(v.reference[key], "reference " + key);
    for (const key of [
      "contract_digest",
      "environment_digest",
      "implementation_digest",
    ])
      digest(v.measurement[key], "measurement " + key);
    for (const key of ["spatial_points", "requested_times", "initial_values"]) {
      if (
        !Array.isArray(v.query[key]) ||
        !v.query[key].length ||
        v.query[key].length > 4096
      )
        v.query[key] = null;
      if (v.query[key] === null)
        throw Error("SOURCE_MEASUREMENT_EVIDENCE_REJECTED: query " + key);
      v.query[key].forEach((x, i) => number(x, key + " " + i));
    }
    for (const key of [
      "domain_length",
      "viscosity",
      "characteristic_time",
      "amplitude",
      "k_rms",
    ])
      number(v.query[key], key, { positive: true });
    return v;
  }
  function observation(v, id, physics = false) {
    const keys = physics
      ? [
          "physics_id",
          "raw_defect",
          "normalization_scale",
          "normalized_defect",
          "uncertainty",
          "scientific_limit",
          "decision",
        ]
      : [
          "measurement_id",
          "candidate_value",
          "reference_value",
          "raw_absolute_error",
          "normalization_scale",
          "normalized_error",
          "uncertainty",
          "scientific_limit",
          "decision",
        ];
    exact(v, keys, physics ? "physics observation" : "measurement observation");
    const idKey = physics ? "physics_id" : "measurement_id";
    if (v[idKey] !== id)
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: duplicate, missing, or reordered " +
          idKey,
      );
    const raw = physics ? v.raw_defect : v.raw_absolute_error,
      normalized = physics ? v.normalized_defect : v.normalized_error;
    number(raw, "raw observation", { nonnegative: true });
    number(v.normalization_scale, "normalization scale", { positive: true });
    number(normalized, "normalized observation", { nonnegative: true });
    if (!physics) {
      number(v.candidate_value, "candidate value");
      number(v.reference_value, "reference value");
    }
    if (normalized !== raw / v.normalization_scale)
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: inconsistent normalization",
      );
    if (
      v.uncertainty !== null ||
      v.scientific_limit !== null ||
      v.decision !== "UNRESOLVED_NO_QUALIFIED_LIMIT"
    )
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: forged decision, uncertainty, or scientific limit",
      );
    return v;
  }
  function resultDocument(v) {
    exact(
      v,
      [
        "schema",
        "scope",
        "request_digest",
        "disposition",
        "measurements",
        "physics",
        "diagnostics",
        "output_semantics",
        "score_input",
        "eligibility",
      ],
      "C-05 result",
    );
    exact(
      v.eligibility,
      ["scientifically_qualified", "protected_execution", "score"],
      "result eligibility",
    );
    if (
      v.schema !== RESULT_SCHEMA ||
      v.scope !== SCOPE ||
      v.output_semantics !== OUTPUT ||
      v.score_input !== null ||
      !DISPOSITIONS.includes(v.disposition)
    )
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: source result interface",
      );
    same(
      v.eligibility,
      {
        scientifically_qualified: false,
        protected_execution: false,
        score: false,
      },
      "result eligibility",
    );
    digest(v.request_digest, "result request digest");
    if (
      !Array.isArray(v.measurements) ||
      !Array.isArray(v.physics) ||
      !Array.isArray(v.diagnostics) ||
      v.diagnostics.length > 64
    )
      throw Error("SOURCE_MEASUREMENT_EVIDENCE_REJECTED: source result arrays");
    const complete = v.disposition === "COMPLETE_DEVELOPMENT_ONLY";
    if (complete) {
      if (
        v.measurements.length !== MEASUREMENTS.length ||
        v.physics.length !== PHYSICS.length
      )
        throw Error(
          "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: incomplete complete result",
        );
      v.measurements.forEach((x, i) => observation(x, MEASUREMENTS[i]));
      v.physics.forEach((x, i) => observation(x, PHYSICS[i], true));
    } else if (v.measurements.length || v.physics.length)
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: non-complete result carries observations",
      );
    for (const item of v.diagnostics) {
      if (!Array.isArray(item) || item.length !== 2)
        throw Error("SOURCE_MEASUREMENT_EVIDENCE_REJECTED: diagnostic shape");
      string(item[0], "diagnostic id", 200);
      if (typeof item[1] === "number") number(item[1], "diagnostic value");
      else string(item[1], "diagnostic value", 1000);
    }
    return v;
  }
  function validateAssociation(a, request) {
    exact(
      a,
      [
        "request_id",
        "job_id",
        "design_id",
        "design_revision",
        "requirement_trace_ids",
        "case_family_ids",
        "challenge",
        "template_id",
        "expected_source_interface",
        "evidence_scope",
      ],
      "workbench association",
    );
    exact(a.challenge, ["id", "version"], "association challenge");
    if (
      a.request_id !== request.request_id ||
      a.job_id !== request.job_id ||
      a.design_id !== request.design_id ||
      a.design_revision !== request.design_revision
    )
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: wrong job/design/revision/request",
      );
    same(
      a.requirement_trace_ids,
      request.source_association.requirement_trace_ids,
      "requested trace IDs",
    );
    same(
      a.case_family_ids,
      request.source_association.case_family_ids,
      "requested case families",
    );
    same(
      a.challenge,
      request.source_association.challenge,
      "Challenge identity",
    );
    for (const key of [
      "template_id",
      "expected_source_interface",
      "evidence_scope",
    ])
      if (a[key] !== request.source_association[key])
        throw Error("SOURCE_MEASUREMENT_EVIDENCE_REJECTED: " + key);
    return a;
  }
  function fixtureFor(source, requestDoc, association) {
    if (!fixtureIndex)
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: fixture index unavailable",
      );
    const found = fixtureIndex.fixtures.find(
      (x) => x.fixture_id === source.fixture_id,
    );
    if (!found)
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: unregistered source fixture",
      );
    const checks = {
      request_digest: source.request_digest,
      result_digest: source.result_digest,
      case_digest: requestDoc.case_digest,
      candidate_artifact_digest: requestDoc.candidate.artifact_digest,
      candidate_binding_digest: requestDoc.candidate.binding_digest,
      candidate_source_digest: requestDoc.candidate.source_digest,
      candidate_environment_digest: requestDoc.candidate.environment_digest,
      candidate_plan_digest: requestDoc.candidate.plan_digest,
      candidate_replica_id: requestDoc.candidate.replica_id,
      measurement_contract_digest: requestDoc.measurement.contract_digest,
      measurement_environment_digest: requestDoc.measurement.environment_digest,
      measurement_implementation_digest:
        requestDoc.measurement.implementation_digest,
      source_revision: source.source_revision,
    };
    for (const [key, value] of Object.entries(checks))
      if (found[key] !== value)
        throw Error(
          "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: wrong case/candidate/source identity " +
            key,
        );
    same(
      association,
      found.association,
      "registered manual fixture association",
    );
    return found;
  }
  async function importBundle(design, request, raw, sha256) {
    if (typeof raw !== "string" || typeof sha256 !== "function")
      throw Error("SOURCE_MEASUREMENT_EVIDENCE_REJECTED: import input");
    const bundle = F.strictJsonParse(raw, { maxBytes: 900000, maxDepth: 18 });
    exact(
      bundle,
      [
        "schema_version",
        "association",
        "source",
        "measurement_request_json",
        "measurement_result_json",
        "behavior_classification",
        "limitations",
        "authority",
      ],
      "C-05 evidence bundle",
    );
    if (bundle.schema_version !== BUNDLE_VERSION)
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: unknown adapter schema",
      );
    const a = validateAssociation(bundle.association, request);
    exact(
      bundle.source,
      [
        "fixture_id",
        "repository",
        "source_revision",
        "implementation",
        "request_schema",
        "result_schema",
        "request_digest",
        "result_digest",
      ],
      "source identity",
    );
    if (
      bundle.source.repository !== "carbonphysicsai/Carbon" ||
      bundle.source.implementation !==
        "carbon.measurement_runtime.model.execute_measurement" ||
      bundle.source.request_schema !== REQUEST_SCHEMA ||
      bundle.source.result_schema !== RESULT_SCHEMA
    )
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: wrong source schema or implementation",
      );
    string(
      bundle.measurement_request_json,
      "measurement request bytes",
      500000,
    );
    string(bundle.measurement_result_json, "measurement result bytes", 200000);
    const requestDoc = requestDocument(
      F.strictJsonParse(bundle.measurement_request_json, {
        maxBytes: 500000,
        maxDepth: 12,
      }),
    );
    const resultDoc = resultDocument(
      F.strictJsonParse(bundle.measurement_result_json, {
        maxBytes: 200000,
        maxDepth: 10,
      }),
    );
    const requestDigest =
        "sha256:" + (await sha256(bundle.measurement_request_json)),
      resultDigest = "sha256:" + (await sha256(bundle.measurement_result_json)),
      artifactDigest = "sha256:" + (await sha256(raw));
    if (
      requestDigest !== bundle.source.request_digest ||
      resultDigest !== bundle.source.result_digest ||
      resultDoc.request_digest !== requestDigest
    )
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: source request/result digest mismatch",
      );
    fixtureFor(bundle.source, requestDoc, a);
    if (
      !Array.isArray(bundle.behavior_classification) ||
      bundle.behavior_classification.length !== EXAMPLES.length
    )
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: behavior classification",
      );
    bundle.behavior_classification.forEach((x, i) => {
      exact(
        x,
        ["example", "classification", "reason"],
        "behavior classification",
      );
      if (
        x.example !== EXAMPLES[i] ||
        !CLASSIFICATIONS.includes(x.classification)
      )
        throw Error(
          "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: behavior classification value",
        );
      string(x.reason, "behavior classification reason", 1200);
    });
    if (
      !Array.isArray(bundle.limitations) ||
      !bundle.limitations.length ||
      bundle.limitations.length > 32
    )
      throw Error("SOURCE_MEASUREMENT_EVIDENCE_REJECTED: limitations");
    bundle.limitations.forEach((x) => string(x, "limitation", 1200));
    same(
      bundle.authority,
      {
        development_only: true,
        scientifically_qualified: false,
        protected_execution_eligible: false,
        score_eligible: false,
        approved: false,
        launch_authorized: false,
      },
      "bundle authority",
    );
    if (
      design.job_id !== a.job_id ||
      design.design_id !== a.design_id ||
      design.revision !== a.design_revision
    )
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: current design mismatch",
      );
    const associationId = a.request_id + "::" + resultDigest,
      prior = design.measurement_evidence.find(
        (x) => x.association_id === associationId,
      );
    if (prior) {
      if (prior.imported_artifact_digest === artifactDigest)
        return { disposition: "DEDUPLICATED", record: clone(prior) };
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: changed bytes conflict with claimed identity",
      );
    }
    const complete = resultDoc.disposition === "COMPLETE_DEVELOPMENT_ONLY",
      record = {
        schema_version: ASSOCIATION_VERSION,
        association_id: associationId,
        workbench_request_id: a.request_id,
        job_id: a.job_id,
        design_id: a.design_id,
        design_revision: a.design_revision,
        requirement_trace_ids: clone(a.requirement_trace_ids),
        case_family_ids: clone(a.case_family_ids),
        challenge: clone(a.challenge),
        template_id: a.template_id,
        evidence_scope: a.evidence_scope,
        evidence_state: complete
          ? "SOURCE_MEASUREMENT_EVIDENCE_BOUND"
          : "SOURCE_MEASUREMENT_EVIDENCE_NOT_EXECUTED",
        binding_status: "CURRENT_DESIGN_REVISION",
        source_disposition: resultDoc.disposition,
        source: {
          fixture_id: bundle.source.fixture_id,
          repository: bundle.source.repository,
          source_revision: bundle.source.source_revision,
          implementation: bundle.source.implementation,
          request_schema: bundle.source.request_schema,
          result_schema: bundle.source.result_schema,
          request_digest: requestDigest,
          result_digest: resultDigest,
          case_digest: requestDoc.case_digest,
          candidate: clone(requestDoc.candidate),
          reference: clone(requestDoc.reference),
          measurement: clone(requestDoc.measurement),
        },
        measurements: clone(resultDoc.measurements),
        physics: clone(resultDoc.physics),
        diagnostics: clone(resultDoc.diagnostics),
        behavior_classification: clone(bundle.behavior_classification),
        limitations: clone(bundle.limitations),
        trace_state: complete
          ? "SOURCE_MEASUREMENT_EXECUTED_SCIENTIFIC_DECISION_UNRESOLVED"
          : "SOURCE_MEASUREMENT_NOT_EXECUTED",
        imported_artifact_digest: artifactDigest,
        scientifically_qualified: false,
        score_eligible: false,
        approved: false,
        launch_authorized: false,
      };
    design.measurement_evidence.push(record);
    verifiedRecords.add(record);
    if (root.CarbonGoalRouting && Array.isArray(design.evidence_bindings))
      root.CarbonGoalRouting.bindC05Record(design, record);
    return { disposition: "IMPORTED", record: clone(record) };
  }
  function clientSummary(record) {
    return {
      evidence_state: record.evidence_state,
      source_disposition: record.source_disposition,
      requirements_informed: clone(record.requirement_trace_ids),
      case_families: clone(record.case_family_ids),
      summary:
        record.evidence_state === "SOURCE_MEASUREMENT_EVIDENCE_BOUND"
          ? "Public DEVELOPMENT measurement evidence exists for this proposed requirement, but the scientific limit and uncertainty rule remain unqualified."
          : "The source returned a typed non-complete DEVELOPMENT disposition; no measurement or score was inferred.",
      scientific_decision: "UNRESOLVED",
      qualification: "NOT_QUALIFIED",
    };
  }
  function validateSavedSource(s) {
    exact(
      s,
      [
        "fixture_id",
        "repository",
        "source_revision",
        "implementation",
        "request_schema",
        "result_schema",
        "request_digest",
        "result_digest",
        "case_digest",
        "candidate",
        "reference",
        "measurement",
      ],
      "saved source",
    );
    exact(
      s.candidate,
      [
        "artifact_digest",
        "binding_digest",
        "source_digest",
        "environment_digest",
        "plan_digest",
        "replica_id",
      ],
      "saved candidate",
    );
    exact(
      s.reference,
      [
        "artifact_digest",
        "request_digest",
        "policy_digest",
        "environment_digest",
        "role",
        "scientifically_qualified",
      ],
      "saved reference",
    );
    exact(
      s.measurement,
      [
        "policy_id",
        "policy_version",
        "contract_digest",
        "environment_digest",
        "implementation_digest",
        "precision",
        "operator_ids",
        "physics_ids",
        "scientific_limits",
        "uncertainty_policy",
        "scientifically_qualified",
      ],
      "saved measurement",
    );
    for (const key of ["request_digest", "result_digest", "case_digest"])
      digest(s[key], key);
    for (const key of [
      "artifact_digest",
      "binding_digest",
      "source_digest",
      "environment_digest",
      "plan_digest",
    ])
      digest(s.candidate[key], "candidate " + key);
    for (const key of [
      "artifact_digest",
      "request_digest",
      "policy_digest",
      "environment_digest",
    ])
      digest(s.reference[key], "reference " + key);
    for (const key of [
      "contract_digest",
      "environment_digest",
      "implementation_digest",
    ])
      digest(s.measurement[key], "measurement " + key);
    same(s.measurement.operator_ids, MEASUREMENTS, "saved measurement IDs");
    same(s.measurement.physics_ids, PHYSICS, "saved physics IDs");
    if (
      s.reference.scientifically_qualified !== false ||
      s.measurement.scientifically_qualified !== false ||
      s.measurement.scientific_limits !== null ||
      s.measurement.uncertainty_policy !== null
    )
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: saved source authority",
      );
    return s;
  }
  function validateRecord(r, design) {
    const keys = [
      "schema_version",
      "association_id",
      "workbench_request_id",
      "job_id",
      "design_id",
      "design_revision",
      "requirement_trace_ids",
      "case_family_ids",
      "challenge",
      "template_id",
      "evidence_scope",
      "evidence_state",
      "binding_status",
      "source_disposition",
      "source",
      "measurements",
      "physics",
      "diagnostics",
      "behavior_classification",
      "limitations",
      "trace_state",
      "imported_artifact_digest",
      "scientifically_qualified",
      "score_eligible",
      "approved",
      "launch_authorized",
    ];
    exact(r, keys, "saved evidence association");
    if (
      r.schema_version !== ASSOCIATION_VERSION ||
      r.job_id !== design.job_id ||
      r.design_id !== design.design_id ||
      r.design_revision !== design.revision ||
      ![
        "SOURCE_MEASUREMENT_EVIDENCE_BOUND",
        "SOURCE_MEASUREMENT_EVIDENCE_NOT_EXECUTED",
      ].includes(r.evidence_state) ||
      !["CURRENT_DESIGN_REVISION", "STALE_DESIGN_CHANGED"].includes(
        r.binding_status,
      ) ||
      !DISPOSITIONS.includes(r.source_disposition)
    )
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: saved association identity",
      );
    if (
      !Array.isArray(r.requirement_trace_ids) ||
      !Array.isArray(r.case_family_ids) ||
      r.requirement_trace_ids.some(
        (x) => !design.traces.some((t) => t.trace_id === x),
      ) ||
      r.case_family_ids.some(
        (x) => !design.cases.some((c) => c.case_family_id === x),
      )
    )
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: saved trace association",
      );
    exact(r.challenge, ["id", "version"], "saved challenge");
    validateSavedSource(r.source);
    const fixture = validateSavedFixture(r.source);
    digest(r.imported_artifact_digest, "imported artifact digest");
    if (
      r.source.repository !== "carbonphysicsai/Carbon" ||
      r.source.request_schema !== REQUEST_SCHEMA ||
      r.source.result_schema !== RESULT_SCHEMA ||
      r.scientifically_qualified !== false ||
      r.score_eligible !== false ||
      r.approved !== false ||
      r.launch_authorized !== false
    )
      throw Error("SOURCE_MEASUREMENT_EVIDENCE_REJECTED: saved authority");
    if (
      !Array.isArray(r.measurements) ||
      !Array.isArray(r.physics) ||
      !Array.isArray(r.diagnostics) ||
      !Array.isArray(r.behavior_classification) ||
      !Array.isArray(r.limitations)
    )
      throw Error("SOURCE_MEASUREMENT_EVIDENCE_REJECTED: saved arrays");
    if (r.source_disposition === "COMPLETE_DEVELOPMENT_ONLY") {
      if (r.measurements.length !== 4 || r.physics.length !== 6)
        throw Error(
          "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: saved complete observations",
        );
      r.measurements.forEach((x, i) => observation(x, MEASUREMENTS[i]));
      r.physics.forEach((x, i) => observation(x, PHYSICS[i], true));
    } else if (r.measurements.length || r.physics.length)
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: saved non-complete observations",
      );
    const savedProjection = {
      evidence_state: r.evidence_state,
      source_disposition: r.source_disposition,
      measurements: r.measurements,
      physics: r.physics,
      diagnostics: r.diagnostics,
      behavior_classification: r.behavior_classification,
      limitations: r.limitations,
      trace_state: r.trace_state,
      imported_artifact_digest: r.imported_artifact_digest,
    };
    same(savedProjection, fixture.saved_projection, "saved fixture projection bytes");
    return clone(r);
  }
  function validateSavedFixture(s) {
    if (!fixtureIndex)
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: fixture index unavailable",
      );
    const f = fixtureIndex.fixtures.find((x) => x.fixture_id === s.fixture_id);
    if (!f)
      throw Error(
        "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: unregistered saved fixture",
      );
    const checks = {
      request_digest: s.request_digest,
      result_digest: s.result_digest,
      case_digest: s.case_digest,
      candidate_artifact_digest: s.candidate.artifact_digest,
      candidate_binding_digest: s.candidate.binding_digest,
      candidate_source_digest: s.candidate.source_digest,
      candidate_environment_digest: s.candidate.environment_digest,
      candidate_plan_digest: s.candidate.plan_digest,
      candidate_replica_id: s.candidate.replica_id,
      measurement_contract_digest: s.measurement.contract_digest,
      measurement_environment_digest: s.measurement.environment_digest,
      measurement_implementation_digest: s.measurement.implementation_digest,
      source_revision: s.source_revision,
    };
    for (const [key, value] of Object.entries(checks))
      if (f[key] !== value)
        throw Error(
          "SOURCE_MEASUREMENT_EVIDENCE_REJECTED: saved fixture identity " + key,
        );
    return f;
  }
  function isVerifiedRecord(record) {
    return (
      !!record && typeof record === "object" && verifiedRecords.has(record)
    );
  }
  const api = {
    BUNDLE_VERSION,
    ASSOCIATION_VERSION,
    REQUEST_SCHEMA,
    RESULT_SCHEMA,
    MEASUREMENTS,
    PHYSICS,
    DISPOSITIONS,
    CLASSIFICATIONS,
    EXAMPLES,
    installFixtureIndex,
    requestDocument,
    resultDocument,
    validateRecord,
    importBundle,
    clientSummary,
    isVerifiedRecord,
  };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.CarbonC05Evidence = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
