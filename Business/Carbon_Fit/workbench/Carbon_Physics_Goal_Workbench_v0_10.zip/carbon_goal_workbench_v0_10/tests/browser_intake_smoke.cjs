"use strict";
const { chromium } = require("playwright");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const ROOT = path.resolve(__dirname, "..");
const PREVIEW = path.join(ROOT, "Carbon_Client_Pilot_Designer_Preview.html");
const WORKBENCH = path.join(ROOT, "Carbon_Opportunity_Workbench.html");
const FIXTURES = path.join(ROOT, "intake", "fixtures");
const ASSESSMENT = path.join(ROOT, "source_assessment/repository_snapshot/v1/candidate/assessment_pending_adoption.json");
const checks = [];
function check(name, value) { assert.ok(value, name); checks.push(name); }
async function saveDownload(page, selector, target) {
  const pending = page.waitForEvent("download");
  await page.locator(selector).click();
  await (await pending).saveAs(target);
}
(async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "carbon-intake-browser-"));
  const errors = [], outbound = [];
  const browser = await chromium.launch({ headless: true, ...(process.env.CARBON_BROWSER_EXECUTABLE
      ? { executablePath: process.env.CARBON_BROWSER_EXECUTABLE }
      : {}), });
  const context = await browser.newContext({ acceptDownloads: true, viewport: process.env.CARBON_MOBILE === "1" ? { width: 390, height: 844 } : { width: 1440, height: 1000 } });
  context.on("request", (request) => { if (/^(https?|wss?):/.test(request.url())) outbound.push(request.url()); });

  const formOnly = await context.newPage();
  formOnly.on("pageerror", (error) => errors.push(String(error)));
  formOnly.on("dialog", (dialog) => dialog.accept());
  await formOnly.goto("file://" + PREVIEW);
  check("local preview offers guided conversation and the same form", await formOnly.locator("#guided-panel").isVisible() && (await formOnly.locator("#show-form").count()) === 1);
  check("missing pilot fields are visible rather than implied complete", await formOnly.locator("#assumption-list").innerText().then((text) => text.includes("bounded first pilot") && text.includes("next discussion")));
  const previewText = await formOnly.locator("body").innerText();
  check("preview states local-only boundary and has no enabled submit", previewText.includes("nothing is submitted") && !previewText.includes("Inquiry received") && (await formOnly.locator('button:has-text("Submit to Carbon"):not([disabled])').count()) === 0);
  await formOnly.locator("#show-form").click();
  await formOnly.locator('[data-text="intended_decision"]').fill("Decide whether the current method can support faster design comparisons.");
  await formOnly.locator('[data-text="requested_result"]').fill("Compare turnaround and one engineering output.");
  await formOnly.locator('[data-text="current_baseline"]').fill("Existing numerical method");
  await formOnly.locator('[data-text="baseline_limitation"]').fill("Turnaround is inconvenient; accuracy is unknown.");
  await formOnly.locator('[data-text="consequential_error"]').fill('Wrong comparison <img src=x onerror="window.intakePwned=true">');
  await formOnly.locator('[data-quantity-state="prediction_latency"]').selectOption("RANGE");
  await formOnly.locator('[data-quantity-unit="prediction_latency"]').fill("seconds/query");
  await formOnly.locator('[data-quantity-min="prediction_latency"]').fill("1");
  await formOnly.locator('[data-quantity-max="prediction_latency"]').fill("3");
  check("form mode preserves unknowns range units and inert text", await formOnly.locator("#summary-text").innerText().then((text) => text.includes("1–3 seconds/query") && text.includes("onerror") && text.includes("Preparation time: unknown")));
  const formPath = path.join(tmp, "form-only-intake.json");
  await saveDownload(formOnly, "#export-intake", formPath);
  const formPackage = JSON.parse(fs.readFileSync(formPath, "utf8"));
  check("form-only export uses the shared reviewed package without AI consent or conversation", formPackage.schema_version === "carbon.client-intake.reviewed.v2" && formPackage.brief.schema_version === "carbon.client-intake.draft.v2" && formPackage.ai_guidance.enabled === false && formPackage.sharing.conversation.length === 0);
  check("form-only export reports a local download rather than submission", await formOnly.locator("#intake-status").innerText().then((text) => text.includes("Nothing was transmitted")));
  // E6: the encrypted download is sealed to the published key, shows that key's
  // fingerprint, and carries none of the draft's text.
  const intakeKey = JSON.parse(fs.readFileSync(path.join(ROOT, "data/intake_public_key.json"), "utf8"));
  await formOnly.waitForFunction(() => !document.querySelector("#export-sealed").disabled);
  check("the page shows the published intake key's fingerprint", (await formOnly.locator("#intake-fingerprint").innerText()) === intakeKey.fingerprint);
  const sealedPath = path.join(tmp, "form-only.carbon-sealed");
  await saveDownload(formOnly, "#export-sealed", sealedPath);
  const sealedText = fs.readFileSync(sealedPath, "utf8");
  const sealedPackage = JSON.parse(sealedText);
  check("encrypted export is sealed to the published key and holds no draft text", sealedPackage.schema === "carbon.intake-sealed.v1" && sealedPackage.key_id === intakeKey.key_id && !sealedText.includes("faster design comparisons") && !sealedText.includes("seconds/query"));
  await formOnly.locator("#show-guided").click();
  await formOnly.locator("#show-consent").click();
  await formOnly.locator("#consent-check").check();
  await formOnly.locator("#enable-guidance").click();
  await formOnly.waitForFunction(() => document.querySelector("#guidance-status").textContent.includes("Continue through the form"));
  check("unavailable AI preserves the draft and degrades to the form", await formOnly.locator("#form-panel").isVisible() && (await formOnly.locator('[data-text="intended_decision"]').inputValue()).includes("faster design comparisons"));
  // enabled-but-unavailable is the configuration the product is actually in
  // today, and it is the one the enablement invariant cannot see: the consent
  // record is valid and complete while nothing was ever reached. What separates
  // it from a package where assistance worked is the attribution, so assert
  // exactly that rather than the enablement flag.
  const unavailablePath = path.join(tmp, "enabled-but-unavailable-intake.json");
  await saveDownload(formOnly, "#export-intake", unavailablePath);
  const unavailable = JSON.parse(fs.readFileSync(unavailablePath, "utf8"));
  check("enabled-but-unavailable export records consent and claims no AI contribution",
    unavailable.ai_guidance.enabled === true
      && unavailable.ai_guidance.consented_at !== null
      && unavailable.ai_guidance.notice_version !== null
      && unavailable.accepted_suggestions.length === 0
      && unavailable.field_provenance.every((item) => item.origin !== "AI_SUGGESTED_CLIENT_ACCEPTED")
      && unavailable.field_provenance.every((item) => item.suggestion_id === null)
      && unavailable.sharing.conversation.length === 0);
  // The client's next action is identical whether the endpoint is unreachable or
  // misconfigured, and distinguishing them would tell an external party about
  // operator configuration. One bit plus a usable next step is the boundary; the
  // four-state vocabulary belongs on the operator's own capability surface.
  const unavailableText = await formOnly.locator("#guidance-boundary, #guidance-status").allInnerTexts().then((parts) => parts.join(" "));
  check("the unavailable message names the next action without disclosing why it failed",
    /continue|form/i.test(unavailableText)
      && !/\b(401|403|404|429|500|502|503|ECONNREFUSED|ENOTFOUND|fetch failed)\b/i.test(unavailableText)
      && !/localhost|127\.0\.0\.1|https?:\/\//i.test(unavailableText)
      && !/\bapi[_-]?key|token|secret|provider key\b/i.test(unavailableText));
  // The meaningful assertion is that nothing left the device at all. A filter
  // naming the provider path would be trivially true here: the preview is loaded
  // from file://, so a relative fetch never matches the http(s) tracker and the
  // check would pass whatever the page did.
  check("drafting, enabling and exporting caused no off-device request",
    outbound.length === 0);
  // Prove the tracker can fail, so the assertion above is not vacuous. It has to
  // run from a page without the preview's policy: inside the preview the request
  // never becomes a network request at all, which is the next check.
  const detector = await context.newPage();
  await detector.goto("about:blank");
  await detector.evaluate(() => fetch("http://127.0.0.1:9/carbon-outbound-detector").catch(() => {}));
  await detector.waitForTimeout(250);
  check("the off-device request tracker detects a request when one is made",
    outbound.some((url) => url.includes("carbon-outbound-detector")));
  await detector.close();
  // The preview does not merely decline to call out; its policy forbids it, so a
  // future edit that added a call would be blocked rather than silently allowed.
  const blocked = await formOnly.evaluate(async () => {
    try { await fetch("http://127.0.0.1:9/carbon-policy-probe"); return "allowed"; }
    catch (error) { return String(error); }
  });
  check("the preview's connect policy blocks an off-device request outright",
    blocked !== "allowed" && !outbound.some((url) => url.includes("carbon-policy-probe")));
  outbound.length = 0;
  await formOnly.locator("#reset-draft").click();
  check("explicit reset clears the local draft without claiming provider deletion", await formOnly.locator("#guidance-status").innerText().then((text) => text.includes("does not delete provider records")) && (await formOnly.locator('[data-text="intended_decision"]').inputValue()) === "");

  await context.addInitScript(() => {
    let guidanceCalls = 0;
    window.fetch = async (url, options = {}) => {
      if (String(url).endsWith("/health")) return new Response(JSON.stringify({ active: true }), { status: 200, headers: { "content-type": "application/json" } });
      guidanceCalls += 1;
      const request = JSON.parse(options.body);
      window.__pilotRequests = [...(window.__pilotRequests || []), request];
      return new Response(JSON.stringify({
        mode: "PILOT_DESIGN",
        message: guidanceCalls === 1 ? "A draft pilot can connect temperature predictions to the design decision without promising execution." : "The accepted brief remains yours to review.",
        next_question: "Which load and flow conditions vary between designs?",
        proposals: guidanceCalls === 1 ? [
          { suggestion_id: "thermal-pilot-001", field: "pilot.bounded_first_pilot", value: "Compare temperature predictions across an agreed load and flow range, focusing on hotspots and design rankings.", rationale: "This makes the first comparison bounded and decision-relevant." },
          { suggestion_id: "thermal-claim-002", field: "requested_result", value: "Guaranteed 100x speedup", rationale: "A client may request this, but Carbon cannot promise it." },
        ] : [],
        unresolved_assumptions: ["Reference-data coverage and access rights remain unresolved."],
        sources: [], maturity_note: "Draft pilot for Carbon review.", request_id: "mock-guidance-001",
      }), { status: 200, headers: { "content-type": "application/json" } });
    };
  });
  const guided = await context.newPage();
  guided.on("pageerror", (error) => errors.push(String(error)));
  await guided.goto("file://" + PREVIEW);
  await guided.locator("#show-guided").focus();
  await guided.keyboard.press("ArrowRight");
  check("pilot designer tabs support keyboard navigation", await guided.locator("#form-panel").isVisible() && (await guided.locator("#show-form").getAttribute("aria-selected")) === "true");
  await guided.keyboard.press("ArrowLeft");
  await guided.locator("#show-consent").click();
  check("AI data disclosure appears before the first guidance request", await guided.locator("#consent-panel").isVisible() && (await guided.locator("#guidance-input").isDisabled()));
  await guided.locator("#consent-check").check();
  await guided.locator("#enable-guidance").click();
  await guided.waitForFunction(() => !document.querySelector("#guidance-input").disabled);
  await guided.locator("#guidance-input").fill("We want to predict cold-plate temperatures faster.");
  await guided.locator("#send-guidance").click();
  await guided.waitForFunction(() => document.querySelectorAll("#proposal-list .proposal").length === 2);
  await guided.locator("#proposal-list .proposal").nth(0).getByText("Accept change").click();
  await guided.locator("#proposal-list .proposal").getByText("Reject").click();
  check("accepted suggestion changes the shared brief while the rejected claim does not", await guided.locator("#pilot-text").innerText().then((text) => text.includes("hotspots and design rankings")) && (await guided.locator("#summary-text").innerText()).includes("Requested result: Unknown"));
  await guided.locator("#show-form").click();
  check("switching to the form preserves accepted conversational edits", (await guided.locator('[data-pilot="bounded_first_pilot"]').inputValue()).includes("hotspots and design rankings"));
  await guided.locator('[data-text="intended_decision"]').fill("Select a cold-plate design for further engineering review.");
  await guided.locator("#show-guided").click();
  check("switching back to conversation preserves client form edits in the disclosed context", await guided.locator("#context-preview").textContent().then((text) => text.includes("Select a cold-plate design")));
  check("the client can undo an accepted AI edit without losing the rest of the brief", await guided.locator("#undo-suggestion").isEnabled());
  await guided.locator("#undo-suggestion").click();
  check("undo removes only the accepted proposed change", (await guided.locator("#pilot-text").innerText()) === "Not yet proposed." && (await guided.locator("#context-preview").textContent()).includes("Select a cold-plate design"));
  await guided.locator("#guidance-input").fill("Keep the pilot scope unresolved for now.");
  await guided.locator("#send-guidance").click();
  await guided.waitForFunction(() => document.querySelector("#guidance-status").textContent.includes("Review each proposed change"));
  await guided.locator("#clear-conversation").click();
  check("clear is local and does not claim provider deletion", await guided.locator("#conversation").innerText().then((text) => text.includes("does not delete provider records")));
  await guided.screenshot({ path: path.join(ROOT, "tests/preview_intake.png"), fullPage: true });
  const draftPath = path.join(tmp, "downloaded-guided-intake.json");
  await saveDownload(guided, "#export-intake", draftPath);
  const draft = JSON.parse(fs.readFileSync(draftPath, "utf8"));
  check("guided export records consent, local clearing, unresolved assumptions, and conversation opt-out", draft.ai_guidance.enabled === true && draft.ai_guidance.cleared_locally === true && draft.unresolved_assumptions.includes("Reference-data coverage and access rights remain unresolved.") && draft.sharing.include_conversation === false && draft.sharing.conversation.length === 0);
  check("download has no authority-bearing shortcut", draft.qualified === undefined && draft.approved === undefined && draft.trusted === undefined);

  const workbench = await context.newPage();
  workbench.on("pageerror", (error) => errors.push(String(error)));
  workbench.on("dialog", (dialog) => dialog.accept());
  await workbench.goto("file://" + WORKBENCH);
  await workbench.locator('[data-tab="jobs"]').click();
  await workbench.locator("#intake-draft-file").setInputFiles(draftPath);
  await workbench.waitForFunction(() => document.querySelector("#toast").textContent.includes("preview prepared"));
  check("Workbench previews the reviewed package before mutation", (await workbench.locator("#jobs-view").innerText()).includes("CREATE_NEW_JOB") && (await workbench.locator("#jobs-view").innerText()).includes("Reviewed pilot package") && (await workbench.locator("[data-job-select]").count()) === 0);
  await workbench.locator("#commit-intake-draft").click();
  check("ordinary commit creates one unassessed job with retained AI provenance", (await workbench.locator("[data-job-select]").count()) === 1 && (await workbench.locator("#route-choice").inputValue()) === "UNASSESSED" && (await workbench.locator("#jobs-view").innerText()).includes("Source intake lineage (1)"));
  await workbench.locator('[data-job="lead"]').fill("S1");
  await workbench.locator('[data-job="accountable_owner"]').fill("Synthetic owner");
  await workbench.locator("#route-choice").selectOption("USE_EXISTING_CAPABILITY");
  await workbench.locator("#route-rationale").fill("Review the reported baseline before Challenge authoring.");
  await workbench.locator("#route-source").fill("reported-current-method");
  await workbench.locator("#route-basis").fill("Client assertion only; applicability unverified.");
  await workbench.locator("#route-conditions").fill("output compatibility\ndeployment evidence");
  await workbench.locator("#route-decision").fill("Clarify baseline applicability");
  await workbench.locator("#save-route").click();
  await workbench.locator("#handoff-question").fill("Can the current baseline satisfy the exact requested output and use?");
  await workbench.locator("#prepare-handoff").click();
  check("existing-capability route prepares one handoff without authoring or send", await workbench.locator("#jobs-view").innerText().then((text) => text.includes("USE_EXISTING_CAPABILITY") && text.includes("PREPARED") && text.includes("Send / launch unavailable")));
  await workbench.locator("#intake-draft-file").setInputFiles(draftPath);
  await workbench.waitForFunction(() => document.querySelector("#jobs-view").textContent.includes("EXACT_REPLAY"));
  await workbench.locator("#commit-intake-draft").click();
  check("exact replay creates no duplicate job or lineage", (await workbench.locator("[data-job-select]").count()) === 1 && (await workbench.locator("#jobs-view").innerText()).includes("Source intake lineage (1)"));

  const sessionPath = path.join(tmp, "session.json");
  await saveDownload(workbench, "#export-goal", sessionPath);
  const restored = await context.newPage();
  restored.on("pageerror", (error) => errors.push(String(error)));
  restored.on("dialog", (dialog) => dialog.accept());
  await restored.goto("file://" + WORKBENCH);
  await restored.locator("#goal-workspace-file").setInputFiles(sessionPath);
  await restored.waitForFunction(() => document.querySelector("#toast").textContent.includes("Imported v0.10"));
  await restored.locator('[data-tab="jobs"]').click();
  check("fresh-session save reload retains reviewed intake lineage and route", await restored.locator("#jobs-view").innerText().then((text) => text.includes("Source intake lineage (1)") && text.includes("USE_EXISTING_CAPABILITY")));
  await restored.locator("#intake-draft-file").setInputFiles(path.join(FIXTURES, "fresh_burgers_v1.json"));
  await restored.waitForFunction(() => document.querySelector("#jobs-view").textContent.includes("CREATE_NEW_JOB"));
  await restored.locator("#commit-intake-draft").click();
  await restored.locator("#source-assessment-file").setInputFiles(ASSESSMENT);
  await restored.waitForFunction(() => document.querySelector("#toast").textContent.includes("import rejected"));
  check("fresh Burgers-like intake cannot borrow the admitted 07A assessment", !(await restored.locator("#jobs-view").innerText()).includes("MATCHED_APPROVED_SOURCE_SNAPSHOT"));
  const jobsBeforeMalformed = await restored.locator("[data-job-select]").count();
  await restored.locator("#intake-draft-file").setInputFiles({ name: "malformed-utf8.carbon-intake.json", mimeType: "application/json", buffer: Buffer.from([0xff, 0xfe, 0x7b]) });
  await restored.waitForFunction(() => document.querySelector("#toast").textContent.includes("preview rejected"));
  check("malformed UTF-8 rejects before workspace mutation", (await restored.locator("[data-job-select]").count()) === jobsBeforeMalformed);

  await restored.setViewportSize({ width: 390, height: 844 });
  check("narrow Workbench remains free of page-level horizontal overflow", await restored.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth + 2));
  await guided.setViewportSize({ width: 390, height: 844 });
  check("narrow pilot designer remains free of page-level horizontal overflow", await guided.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth + 2));
  await guided.screenshot({ path: path.join(ROOT, "tests/preview_intake_mobile.png"), fullPage: true });
  check("preview and Workbench made zero off-device requests", outbound.length === 0);
  check("malicious text never executed", await formOnly.evaluate(() => window.intakePwned === undefined));
  check("browser contexts reported no page errors", errors.length === 0);
  const previewSource = fs.readFileSync(PREVIEW, "utf8");
  check("public preview excludes internal snapshot evidence and local paths", !previewSource.includes("OWNER-GW07-RYAN-SNAPSHOT-01") && !previewSource.includes("approved_assessments") && !previewSource.includes("/Users/"));
  fs.writeFileSync(path.join(ROOT, "tests/browser_intake_results.json"), JSON.stringify({ browser: "Google Chrome", checks, errors, outbound_requests: outbound, provider_calls: "MOCK_ONLY", live_model_calls: 0, authority: "Local synthetic product-flow evidence only; no customer, scientific, rights, security, hosting, or launch qualification." }, null, 2) + "\n");
  await browser.close();
  console.log(JSON.stringify({ checks: checks.length, failures: 0, outbound_requests: outbound.length, live_model_calls: 0 }));
})().catch((error) => { console.error(error); process.exit(1); });
