(function (root) {
  "use strict";
  const F = root.CarbonFit;
  const E = root.CarbonC05Evidence;
  const I =
    root.CarbonClientIntake ||
    (typeof require !== "undefined" ? require("./intake.js") : null);
  const T =
    root.CarbonTeamReview ||
    (typeof require !== "undefined" ? require("./team_review.js") : null);
  const S =
    root.CarbonSourceAssessment ||
    (typeof require !== "undefined" ? require("./source_assessment.js") : null);
  const R =
    root.CarbonGoalRouting ||
    (typeof require !== "undefined" ? require("./routing.js") : null);
  const VERSION = "carbon.goal-workbench.design.v0.9",
    WORKSPACE_VERSION = "carbon.goal-workbench.workspace.v0.9",
    APP_VERSION = "Carbon Goal-to-Challenge Workbench v0.9";
  const INTAKE_VERSION = "carbon.goal-workbench.design.v0.8",
    INTAKE_WORKSPACE_VERSION = "carbon.goal-workbench.workspace.v0.8",
    INTAKE_APP_VERSION = "Carbon Goal-to-Challenge Workbench v0.8";
  const ADMITTED_VERSION = "carbon.goal-workbench.design.v0.7",
    ADMITTED_WORKSPACE_VERSION = "carbon.goal-workbench.workspace.v0.7",
    ADMITTED_APP_VERSION = "Carbon Goal-to-Challenge Workbench v0.7";
  const ACCEPTED_VERSION = "carbon.goal-workbench.design.v0.6",
    ACCEPTED_WORKSPACE_VERSION = "carbon.goal-workbench.workspace.v0.6",
    ACCEPTED_APP_VERSION = "Carbon Goal-to-Challenge Workbench v0.6";
  const PRIOR_VERSION = "carbon.goal-workbench.design.v0.5",
    PRIOR_WORKSPACE_VERSION = "carbon.goal-workbench.workspace.v0.5",
    PRIOR_APP_VERSION = "Carbon Goal-to-Challenge Workbench v0.5";
  const OLD_VERSION = "carbon.goal-workbench.design.v0.4",
    OLD_WORKSPACE_VERSION = "carbon.goal-workbench.workspace.v0.4",
    OLD_APP_VERSION = "Carbon Goal-to-Challenge Workbench v0.4";
  const LEGACY_VERSION = "carbon.goal-workbench.design.v0.3",
    LEGACY_WORKSPACE_VERSION = "carbon.goal-workbench.workspace.v0.3",
    LEGACY_APP_VERSION = "Carbon Goal-to-Challenge Workbench v0.3";
  const HANDOFF_VERSION = "carbon.goal-workbench.handoff.v1",
    RESPONSE_VERSION = "carbon.goal-workbench.response.v1",
    LAUNCH_VERSION = "carbon.goal-workbench.launch-candidate.v1";
  const ROLES = ["MANDATORY", "SOFT", "DIAGNOSTIC", "DEPLOYMENT"],
    CASE_ROLES = [
      "TRAIN",
      "EVAL",
      "STRESS",
      "QUALIFICATION",
      "REFERENCE_AUDIT",
    ];
  const DIAGNOSTIC_EXAMPLES = [
    "PEAK_MISSED",
    "OVERSMOOTHED",
    "MANDATORY_FAILURE",
    "NONFINITE_OR_WITHHELD",
    "DROPPED_WORK",
    "UNIT_OR_FLOOR",
    "BELOW_UNCERTAINTY",
    "PERSISTENCE_OR_MEMORIZATION",
  ];
  const BLOCKERS = ["AT-09", "AT-16", "AT-19", "AT-22", "AT-30"],
    CONTROLS = ["P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8"];
  const AUTHORITY = {
    qualification: "NOT_QUALIFIED_BY_THIS_TOOL",
    launch: "NOT_LAUNCHED",
    sharing: "RETAIN_A_DEVELOPMENT_ONLY",
    submission: "NOT_SENT_BY_THIS_TOOL",
  };
  const clone = (v) => JSON.parse(JSON.stringify(v));
  function exact(o, keys, label) {
    const proto = o && Object.getPrototypeOf(o);
    if (!o || (proto !== Object.prototype && proto !== null))
      throw Error(label + " must be an object");
    const a = Object.keys(o).sort(),
      b = [...keys].sort();
    if (a.length !== b.length || a.some((x, i) => x !== b[i]))
      throw Error(label + " has unsupported or missing fields");
    return o;
  }
  function str(v, label, n = 8000, empty = true) {
    if (typeof v !== "string" || v.length > n || (!empty && !v))
      throw Error("Invalid " + label);
    return v;
  }
  function ident(v, label) {
    if (
      typeof v !== "string" ||
      !/^([A-Za-z0-9][A-Za-z0-9._:-]{0,127})$/.test(v)
    )
      throw Error("Invalid " + label);
    return v;
  }
  function nullableId(v, label) {
    if (v === null) return null;
    return ident(v, label);
  }
  function integer(v, label, min = 0) {
    if (!Number.isSafeInteger(v) || v < min) throw Error("Invalid " + label);
    return v;
  }
  function list(v, label, max = 128) {
    if (!Array.isArray(v) || v.length > max) throw Error("Invalid " + label);
    return v;
  }
  function enumValue(v, allowed, label) {
    if (!allowed.includes(v)) throw Error("Invalid " + label);
    return v;
  }
  function textMap() {
    return {
      source_reference: "",
      reviewer_notes: "",
      measurement_method: "",
      unresolved_assumptions: "",
    };
  }
  function emptyEconomics() {
    return {
      reference_work: "",
      reference_status: "unknown",
      group_overhead: "",
      overhead_status: "unknown",
      group_size: "",
      group_size_status: "unknown",
      unit: "",
      unit_scope: "",
      compatible_demand_status: "unknown",
      compatible_demand_source: "",
      field_dependent: "UNKNOWN",
      completed_comparisons: "",
      offered_requests: "",
      unresolved_or_censored: "",
      upfront_cost: "",
      upfront_duration: "",
      upfront_risk: "",
    };
  }
  function protection() {
    const controls = {},
      blockers = {};
    for (const id of CONTROLS)
      controls[id] = { state: "UNASSESSED", ...textMap() };
    for (const id of BLOCKERS)
      blockers[id] = { applicability: "UNKNOWN", ...textMap() };
    return {
      controls,
      blockers,
      publication_review: { rights_notes: "", retirement_notes: "" },
    };
  }
  function newDesign(
    jobId,
    id,
    revision = 1,
    parent = null,
    alternative = "Primary proposal",
  ) {
    return {
      schema_version: VERSION,
      job_id: ident(jobId, "job ID"),
      design_id: ident(id, "design ID"),
      revision: integer(revision, "design revision", 1),
      parent_design_id:
        parent === null ? null : ident(parent, "parent design ID"),
      status: "DRAFT",
      alternative_label: str(alternative, "alternative label", 300, false),
      scope: {
        physics_family: "",
        requested_goal: "",
        intended_use: "",
        inputs: "",
        outputs: "",
        units: "",
        geometry: "",
        conditions: "",
        regime: "",
        exclusions: "",
        query_workload: "",
        turnaround: "",
        failure_consequences: "",
        data_access: "",
        rights_scope: "UNRESOLVED",
        commercial_context: "",
        disclosure_scope: "",
        deployment_environment: "",
      },
      requirements: [],
      traces: [],
      cases: [],
      score_plan: {
        official_score_status: "PROPOSED_UNQUALIFIED",
        mandatory_gate_summary: "",
        soft_estimand: "",
        training_objective: "",
        reward_accounting: "SEPARATE_UNRESOLVED",
        deployment_acceptance: "",
        unresolved_tradeoffs: "",
      },
      reference_plan: {
        equation: "",
        role: "",
        method: "",
        configuration: "",
        convergence_evidence: "",
        uncertainty_evidence: "",
        applicable_envelope: "",
        failures: "",
        cost_scope: "",
        independence_limitations: "",
      },
      cpes: {
        study_ref: "CPES-REFERENCE-REUSE-GAUNTLET-V2",
        baseline: "RETAIN_A_DEVELOPMENT",
        design_binding_revision: revision,
        protection: protection(),
        economics: emptyEconomics(),
        invalidated_by: [],
      },
      authoring: {
        template_id: "",
        requested_goal: "",
        compatibility: "UNASSESSED",
        request_id: "",
        result_ref: "",
        semantic_receipt: null,
        extension_request: null,
      },
      route_plan: R.newRoutePlan(),
      measurement_evidence: [],
      evidence_bindings: [],
      source_assessments: S.newState(),
      assessment: T.newAssessment(),
      handoffs: [],
      responses: [],
      coordination: R.newCoordination(revision),
      decision: {
        client_interpretation: "UNRESOLVED",
        design_completeness: "INCOMPLETE",
        authoring_status: "NOT_ATTEMPTED",
        evidence_status: "PLANNED_OR_MISSING",
        scientific_qualification: "NOT_QUALIFIED",
        security_rights: "UNRESOLVED",
        launch_authorization: "NOT_AUTHORIZED",
        native_launch_status: "NOT_LAUNCHED",
        owner_decision: "",
        next_action: "",
        permitted_claims: "",
      },
      change_log: [],
    };
  }
  function newJob(id, title) {
    const first = newDesign(id, id + "-design-1");
    return {
      job_id: ident(id, "job ID"),
      title: str(title, "job title", 300, false),
      source_opportunity_id: null,
      native_task_id: "",
      accountable_owner: "",
      lead: "",
      assignment: {
        client_words: "",
        client_source: "",
        intended_decision: "",
        credible_baseline: "",
        context: "",
        allowances: "",
        rights_summary: "",
        next_owner_decision: "",
      },
      intake_records: [],
      team_review: T.newTeamReview(),
      working_design_id: first.design_id,
      designs: [first],
      created_from: "DIRECT_INTAKE",
    };
  }
  function newWorkspace(component) {
    return {
      schema_version: WORKSPACE_VERSION,
      application_version: APP_VERSION,
      decision_id: "GOAL-WORKBENCH-09",
      base_application_merge: "4afb80566fc695a873d7154c203787991bb64267",
      opportunity_workspace: clone(component),
      jobs: [],
      selected_job_id: null,
      selected_design_id: null,
      migration_receipts: [],
      authority: clone(AUTHORITY),
    };
  }
  function requirement(id, words, source, consequence, kind = "MATERIAL") {
    return {
      requirement_id: ident(id, "requirement ID"),
      original_words: str(words, "requirement words", 8000, false),
      source_reference: str(source, "requirement source"),
      decision_consequence: str(consequence, "decision consequence"),
      kind: enumValue(
        kind,
        ["MATERIAL", "PREFERENCE", "CONSTRAINT", "EXCLUSION"],
        "requirement kind",
      ),
      agreement_status: "CLIENT_ASSERTION",
    };
  }
  function trace(id, requirementId) {
    return {
      trace_id: ident(id, "trace ID"),
      requirement_id: ident(requirementId, "requirement ID"),
      observable: "",
      requested_output: "",
      measurement_definition: "",
      numerical_method: "",
      role: "DIAGNOSTIC",
      normalization: "",
      floor: "",
      aggregation: "",
      uncertainty: "",
      population_ref: "",
      stratum_ref: "",
      finite_case_coverage: "",
      reference_requirement: "",
      authoring_binding: "",
      gap: "",
    };
  }
  function caseFamily(id, role = "EVAL") {
    return {
      case_family_id: ident(id, "case family ID"),
      role: enumValue(role, CASE_ROLES, "case role"),
      requirement_ids: [],
      target_population: "",
      target_mass: "",
      sampling_frequency: "",
      analysis_weight: "",
      independent_physical_cases: "",
      reconstruction_replicas: "",
      generator_ref: "",
      rationale: "",
      support_status: "UNASSESSED",
    };
  }
  function validateEconomics(e) {
    exact(e, Object.keys(emptyEconomics()), "CPES economics");
    for (const k of [
      "reference_status",
      "overhead_status",
      "group_size_status",
      "compatible_demand_status",
    ])
      enumValue(e[k], F.QUANTITY_STATUS, "economics " + k);
    enumValue(e.unit, F.ECON_UNITS, "economics unit");
    enumValue(
      e.field_dependent,
      ["UNKNOWN", "YES", "NO"],
      "field-dependent evidence",
    );
    for (const v of Object.values(e)) str(v, "economics field", 300);
    const result = F.fixedGroupEconomics(e);
    if (result.status === "INVALID")
      throw Error("Invalid economics: " + result.message);
    return clone(e);
  }
  function validateReview(v, label) {
    exact(
      v,
      [
        "state",
        "source_reference",
        "reviewer_notes",
        "measurement_method",
        "unresolved_assumptions",
      ],
      label,
    );
    enumValue(
      v.state,
      ["UNASSESSED", "ASSEMBLED_FOR_REVIEW", "BLOCKED"],
      label + " state",
    );
    for (const k of Object.keys(textMap())) str(v[k], label + " " + k);
    return clone(v);
  }
  function validateProtection(p) {
    exact(p, ["controls", "blockers", "publication_review"], "protection");
    exact(p.controls, CONTROLS, "protection controls");
    exact(p.blockers, BLOCKERS, "protection blockers");
    for (const id of CONTROLS) validateReview(p.controls[id], id);
    for (const id of BLOCKERS) {
      const v = p.blockers[id];
      exact(
        v,
        [
          "applicability",
          "source_reference",
          "reviewer_notes",
          "measurement_method",
          "unresolved_assumptions",
        ],
        id,
      );
      enumValue(
        v.applicability,
        ["UNKNOWN", "APPLICABLE", "NOT_APPLICABLE_USER_ASSERTION"],
        id + " applicability",
      );
      for (const k of Object.keys(textMap())) str(v[k], id + " " + k);
    }
    exact(
      p.publication_review,
      ["rights_notes", "retirement_notes"],
      "publication review",
    );
    str(p.publication_review.rights_notes, "publication rights");
    str(p.publication_review.retirement_notes, "publication retirement");
    return clone(p);
  }
  function validateRequirement(r) {
    exact(
      r,
      [
        "requirement_id",
        "original_words",
        "source_reference",
        "decision_consequence",
        "kind",
        "agreement_status",
      ],
      "requirement",
    );
    ident(r.requirement_id, "requirement ID");
    str(r.original_words, "requirement words", 8000, false);
    str(r.source_reference, "requirement source");
    str(r.decision_consequence, "requirement consequence");
    enumValue(
      r.kind,
      ["MATERIAL", "PREFERENCE", "CONSTRAINT", "EXCLUSION"],
      "requirement kind",
    );
    enumValue(
      r.agreement_status,
      [
        "CLIENT_ASSERTION",
        "ANALYST_PROPOSAL",
        "CLIENT_CONFIRMED",
        "SCOPED_EXCLUSION",
      ],
      "agreement status",
    );
    return clone(r);
  }
  function validateTrace(t, reqs) {
    exact(
      t,
      [
        "trace_id",
        "requirement_id",
        "observable",
        "requested_output",
        "measurement_definition",
        "numerical_method",
        "role",
        "normalization",
        "floor",
        "aggregation",
        "uncertainty",
        "population_ref",
        "stratum_ref",
        "finite_case_coverage",
        "reference_requirement",
        "authoring_binding",
        "gap",
      ],
      "trace",
    );
    ident(t.trace_id, "trace ID");
    if (!reqs.has(t.requirement_id))
      throw Error("Trace references unknown requirement");
    enumValue(t.role, ROLES, "measurement role");
    for (const k of Object.keys(t))
      if (!["trace_id", "requirement_id", "role"].includes(k))
        str(t[k], "trace " + k);
    return clone(t);
  }
  function validateCase(c, reqs) {
    exact(
      c,
      [
        "case_family_id",
        "role",
        "requirement_ids",
        "target_population",
        "target_mass",
        "sampling_frequency",
        "analysis_weight",
        "independent_physical_cases",
        "reconstruction_replicas",
        "generator_ref",
        "rationale",
        "support_status",
      ],
      "case family",
    );
    ident(c.case_family_id, "case family ID");
    enumValue(c.role, CASE_ROLES, "case role");
    list(c.requirement_ids, "case requirements", 64).forEach((x) => {
      if (!reqs.has(x)) throw Error("Case references unknown requirement");
    });
    for (const k of [
      "target_population",
      "target_mass",
      "sampling_frequency",
      "analysis_weight",
      "independent_physical_cases",
      "reconstruction_replicas",
      "generator_ref",
      "rationale",
    ])
      str(c[k], "case " + k);
    enumValue(
      c.support_status,
      ["UNASSESSED", "PROPOSED", "SOURCE_SUPPORTED", "GAP"],
      "case support",
    );
    return clone(c);
  }
  function validateDesign(d, jobId) {
    exact(
      d,
      [
        "schema_version",
        "job_id",
        "design_id",
        "revision",
        "parent_design_id",
        "status",
        "alternative_label",
        "scope",
        "requirements",
        "traces",
        "cases",
        "score_plan",
        "reference_plan",
        "cpes",
        "authoring",
        "route_plan",
        "measurement_evidence",
        "evidence_bindings",
        "source_assessments",
        "assessment",
        "handoffs",
        "responses",
        "coordination",
        "decision",
        "change_log",
      ],
      "design",
    );
    if (d.schema_version !== VERSION || d.job_id !== jobId)
      throw Error("Design schema/job mismatch");
    ident(d.design_id, "design ID");
    integer(d.revision, "design revision", 1);
    nullableId(d.parent_design_id, "parent design ID");
    enumValue(d.status, ["DRAFT", "SEALED", "SUPERSEDED"], "design status");
    str(d.alternative_label, "alternative label", 300, false);
    exact(
      d.scope,
      [
        "physics_family",
        "requested_goal",
        "intended_use",
        "inputs",
        "outputs",
        "units",
        "geometry",
        "conditions",
        "regime",
        "exclusions",
        "query_workload",
        "turnaround",
        "failure_consequences",
        "data_access",
        "rights_scope",
        "commercial_context",
        "disclosure_scope",
        "deployment_environment",
      ],
      "design scope",
    );
    for (const [k, v] of Object.entries(d.scope)) str(v, "scope " + k);
    const rs = list(d.requirements, "requirements", 128).map(
        validateRequirement,
      ),
      rids = new Set(rs.map((x) => x.requirement_id));
    if (rids.size !== rs.length) throw Error("Duplicate requirement ID");
    const ts = list(d.traces, "traces", 256).map((x) => validateTrace(x, rids));
    if (new Set(ts.map((x) => x.trace_id)).size !== ts.length)
      throw Error("Duplicate trace ID");
    const cs = list(d.cases, "cases", 128).map((x) => validateCase(x, rids));
    if (new Set(cs.map((x) => x.case_family_id)).size !== cs.length)
      throw Error("Duplicate case family ID");
    exact(
      d.score_plan,
      [
        "official_score_status",
        "mandatory_gate_summary",
        "soft_estimand",
        "training_objective",
        "reward_accounting",
        "deployment_acceptance",
        "unresolved_tradeoffs",
      ],
      "score plan",
    );
    for (const v of Object.values(d.score_plan)) str(v, "score plan");
    exact(
      d.reference_plan,
      [
        "equation",
        "role",
        "method",
        "configuration",
        "convergence_evidence",
        "uncertainty_evidence",
        "applicable_envelope",
        "failures",
        "cost_scope",
        "independence_limitations",
      ],
      "reference plan",
    );
    for (const v of Object.values(d.reference_plan)) str(v, "reference plan");
    exact(
      d.cpes,
      [
        "study_ref",
        "baseline",
        "design_binding_revision",
        "protection",
        "economics",
        "invalidated_by",
      ],
      "CPES binding",
    );
    if (
      d.cpes.study_ref !== "CPES-REFERENCE-REUSE-GAUNTLET-V2" ||
      d.cpes.baseline !== "RETAIN_A_DEVELOPMENT" ||
      d.cpes.design_binding_revision !== d.revision
    )
      throw Error("CPES authority/binding mismatch");
    validateProtection(d.cpes.protection);
    validateEconomics(d.cpes.economics);
    list(d.cpes.invalidated_by, "CPES invalidations", 64).forEach((x) =>
      str(x, "CPES invalidation", 300, false),
    );
    exact(
      d.authoring,
      [
        "template_id",
        "requested_goal",
        "compatibility",
        "request_id",
        "result_ref",
        "semantic_receipt",
        "extension_request",
      ],
      "authoring",
    );
    for (const k of [
      "template_id",
      "requested_goal",
      "request_id",
      "result_ref",
    ])
      str(d.authoring[k], "authoring " + k, 300);
    enumValue(
      d.authoring.compatibility,
      [
        "UNASSESSED",
        "EXACT_SUPPORTED",
        "INTENT_MISMATCH",
        "EXTENSION_REQUIRED",
      ],
      "authoring compatibility",
    );
    if (d.authoring.semantic_receipt !== null)
      validateSemanticReceipt(d.authoring.semantic_receipt);
    if (d.authoring.extension_request !== null)
      validateExtension(d.authoring.extension_request);
    R.validateRoutePlan(d.route_plan, d);
    const evidence = list(
      d.measurement_evidence,
      "measurement evidence",
      64,
    ).map((x) => E.validateRecord(x, { ...d, traces: ts, cases: cs }));
    const bindingDesign = { ...d, traces: ts, cases: cs };
    const bindings = list(d.evidence_bindings, "evidence bindings", 128).map(
      (x) => R.validateStoredEvidenceBinding(x, bindingDesign, evidence),
    );
    S.validateState(d.source_assessments);
    T.validateAssessment(d.assessment, d);
    list(d.handoffs, "handoffs", 128).forEach((x) => validateHandoff(x, d));
    list(d.responses, "responses", 256).forEach((x) => validateResponse(x, d));
    R.validateCoordination(d.coordination, d.revision);
    if (
      d.coordination.current_action_ref &&
      !d.handoffs.some(
        (item) => item.request_id === d.coordination.current_action_ref,
      ) &&
      !d.coordination.external_records.some(
        (item) => item.record_id === d.coordination.current_action_ref,
      )
    )
      throw Error("Current action reference does not resolve");
    exact(
      d.decision,
      [
        "client_interpretation",
        "design_completeness",
        "authoring_status",
        "evidence_status",
        "scientific_qualification",
        "security_rights",
        "launch_authorization",
        "native_launch_status",
        "owner_decision",
        "next_action",
        "permitted_claims",
      ],
      "decision",
    );
    for (const v of Object.values(d.decision)) str(v, "decision");
    if (d.decision.scientific_qualification !== "NOT_QUALIFIED")
      throw Error(
        "No qualification reader exists; imported qualification is forbidden",
      );
    if (d.decision.native_launch_status !== "NOT_LAUNCHED")
      throw Error(
        "No launch reader exists; imported launch state is forbidden",
      );
    if (!["UNRESOLVED", "PROHIBITED"].includes(d.decision.security_rights))
      throw Error(
        "No rights-authority reader exists; imported rights grant is forbidden",
      );
    list(d.change_log, "change log", 128).forEach((x) => {
      exact(x, ["field", "kind", "impact", "domains", "note"], "change");
      str(x.field, "change field", 500);
      str(x.kind, "change kind", 500);
      str(x.impact, "change impact", 1000);
      list(x.domains, "change domains", 32).forEach((y) =>
        enumValue(y, R.DEPENDENCY_DOMAINS, "change domain"),
      );
      str(x.note, "change note", 500);
    });
    return {
      ...clone(d),
      requirements: rs,
      traces: ts,
      cases: cs,
      measurement_evidence: evidence,
      evidence_bindings: bindings,
    };
  }
  function validateJob(j) {
    exact(
      j,
      [
        "job_id",
        "title",
        "source_opportunity_id",
        "native_task_id",
        "accountable_owner",
        "lead",
        "working_design_id",
        "assignment",
        "intake_records",
        "team_review",
        "designs",
        "created_from",
      ],
      "job",
    );
    ident(j.job_id, "job ID");
    str(j.title, "job title", 300, false);
    if (j.source_opportunity_id !== null)
      ident(j.source_opportunity_id, "opportunity ID");
    str(j.native_task_id, "native task ID", 300);
    str(j.accountable_owner, "accountable owner", 300);
    str(j.lead, "lead", 300);
    nullableId(j.working_design_id, "working design ID");
    exact(
      j.assignment,
      [
        "client_words",
        "client_source",
        "intended_decision",
        "credible_baseline",
        "context",
        "allowances",
        "rights_summary",
        "next_owner_decision",
      ],
      "assignment",
    );
    for (const v of Object.values(j.assignment)) str(v, "assignment field");
    const intakeRecords = list(j.intake_records, "intake records", 64).map(
      (record, index) => {
        exact(
          record,
          [
            "draft_id",
            "revision_id",
            "predecessor_canonical_digest",
            "raw_sha256",
            "canonical_digest",
            "raw_json",
            "validated_draft",
            "mapped_requirement_ids",
            "import_status",
          ],
          "intake record " + index,
        );
        ident(record.draft_id, "intake draft ID");
        ident(record.revision_id, "intake revision ID");
        if (
          record.predecessor_canonical_digest !== null &&
          !/^sha256:[0-9a-f]{64}$/.test(record.predecessor_canonical_digest)
        )
          throw Error("Invalid intake predecessor digest");
        for (const key of ["raw_sha256", "canonical_digest"])
          if (!/^sha256:[0-9a-f]{64}$/.test(record[key]))
            throw Error("Invalid intake digest");
        str(record.raw_json, "intake raw JSON", 120000, false);
        const reparsed = F.strictJsonParse(record.raw_json, {
          maxBytes: 120000,
          maxDepth: 10,
        });
        const validated = I.validateDraft(record.validated_draft);
        const transported = I.draftFromTransport(reparsed);
        if (JSON.stringify(transported) !== JSON.stringify(validated))
          throw Error("Stored intake raw/validated content mismatch");
        list(record.mapped_requirement_ids, "mapped requirement IDs", 16).forEach(
          (value) => ident(value, "mapped requirement ID"),
        );
        if (record.import_status !== "IMPORTED_LOCAL_ASSERTION")
          throw Error("Invalid intake import status");
        return clone(record);
      },
    );
    const intakeIdentities = intakeRecords.map(
      (record) => record.draft_id + "@" + record.revision_id,
    );
    if (new Set(intakeIdentities).size !== intakeIdentities.length)
      throw Error("Duplicate intake revision identity");
    T.validateTeamReview(j.team_review);
    enumValue(
      j.created_from,
      ["DIRECT_INTAKE", "ASSISTED_INTAKE", "MIGRATED"],
      "job origin",
    );
    const ds = list(j.designs, "designs", 64).map((x) =>
      validateDesign(x, j.job_id),
    );
    if (
      !ds.length ||
      new Set(ds.map((x) => x.design_id + "@" + x.revision)).size !== ds.length
    )
      throw Error("Missing or duplicate design revision");
    if (
      j.working_design_id !== null &&
      !ds.some((design) => design.design_id === j.working_design_id)
    )
      throw Error("Unknown working design");
    return { ...clone(j), intake_records: intakeRecords, designs: ds };
  }
  function validateWorkspace(w, componentReader) {
    exact(
      w,
      [
        "schema_version",
        "application_version",
        "decision_id",
        "base_application_merge",
        "opportunity_workspace",
        "jobs",
        "selected_job_id",
        "selected_design_id",
        "migration_receipts",
        "authority",
      ],
      "goal workspace",
    );
    if (
      w.schema_version !== WORKSPACE_VERSION ||
      w.application_version !== APP_VERSION ||
      w.decision_id !== "GOAL-WORKBENCH-09"
    )
      throw Error("Unsupported goal workspace version");
    if (w.base_application_merge !== "4afb80566fc695a873d7154c203787991bb64267")
      throw Error("Unsupported base application identity");
    const component = componentReader(JSON.stringify(w.opportunity_workspace));
    const jobs = list(w.jobs, "jobs", 64).map(validateJob);
    if (new Set(jobs.map((x) => x.job_id)).size !== jobs.length)
      throw Error("Duplicate job ID");
    if (
      w.selected_job_id !== null &&
      !jobs.some((x) => x.job_id === w.selected_job_id)
    )
      throw Error("Unknown selected job");
    if (
      w.selected_design_id !== null &&
      !jobs.some((x) =>
        x.designs.some((d) => d.design_id === w.selected_design_id),
      )
    )
      throw Error("Unknown selected design");
    list(w.migration_receipts, "migration receipts", 128).forEach((x) => {
      exact(
        x,
        ["from", "to", "original_digest_status", "semantic_changes"],
        "migration receipt",
      );
      str(x.from, "migration from", 200, false);
      if (
        ![
          LEGACY_WORKSPACE_VERSION,
          OLD_WORKSPACE_VERSION,
          PRIOR_WORKSPACE_VERSION,
          ACCEPTED_WORKSPACE_VERSION,
          ADMITTED_WORKSPACE_VERSION,
          WORKSPACE_VERSION,
        ].includes(x.to)
      )
        throw Error("Invalid migration target");
      enumValue(
        x.original_digest_status,
        ["VERIFIED_WEB_CRYPTO", "UNAVAILABLE"],
        "migration digest status",
      );
      list(x.semantic_changes, "semantic changes", 16).forEach((y) =>
        str(y, "semantic change", 500, false),
      );
    });
    exact(w.authority, Object.keys(AUTHORITY), "authority");
    if (JSON.stringify(w.authority) !== JSON.stringify(AUTHORITY))
      throw Error("Authority promotion rejected");
    return { ...clone(w), opportunity_workspace: component, jobs };
  }
  function migrateLegacyDesign(design, fromVersion) {
    const oldKeys = [
      "schema_version",
      "job_id",
      "design_id",
      "revision",
      "parent_design_id",
      "status",
      "alternative_label",
      "scope",
      "requirements",
      "traces",
      "cases",
      "score_plan",
      "reference_plan",
      "cpes",
      "authoring",
      "measurement_evidence",
      "handoffs",
      "responses",
      "decision",
      "change_log",
    ];
    const v03Keys = oldKeys.filter((x) => x !== "measurement_evidence");
    exact(
      design,
      fromVersion === OLD_VERSION ? oldKeys : v03Keys,
      "legacy design",
    );
    if (design.schema_version !== fromVersion)
      throw Error("Invalid legacy design version");
    design.schema_version = VERSION;
    if (fromVersion === LEGACY_VERSION) design.measurement_evidence = [];
    for (const key of [
      "commercial_context",
      "disclosure_scope",
      "deployment_environment",
    ]) {
      if (Object.hasOwn(design.scope, key))
        throw Error("Legacy design contains v0.5 scope field");
      design.scope[key] = "";
    }
    design.route_plan = R.newRoutePlan();
    design.evidence_bindings = [];
    design.source_assessments = S.newState();
    design.coordination = R.newCoordination(design.revision);
    design.change_log = design.change_log.map((x) => {
      exact(x, ["field", "kind", "impact", "note"], "legacy change");
      return { ...x, domains: R.changedDomains(x.field) };
    });
  }
  function reconciliationReason(design, field, domain, kind) {
    return {
      reason_id: ["review", kind, design.revision, field, domain].join(":"),
      domain,
      field,
      originating_design_id: design.design_id,
      originating_revision: design.revision,
      basis:
        "v0.5 reconciliation found a retained material change or invalidation for this dependency.",
    };
  }
  function migratePriorBinding(binding, design, parentBinding) {
    exact(
      binding,
      [
        "evidence_binding_id",
        "evidence_kind",
        "source_ref",
        "source_digest_or_identity",
        "design_id",
        "design_revision",
        "trace_ids",
        "case_family_ids",
        "dependency_domains",
        "scientific_applicability",
        "use_or_rights_status",
        "assessment_basis",
        "rationale",
        "invalidated_by",
        "status_provenance",
      ],
      "v0.5 evidence binding",
    );
    const claimed = binding.status_provenance;
    const required = R.MINIMUM_DEPENDENCIES[binding.evidence_kind] || [];
    binding.dependency_domains = [
      ...new Set([...binding.dependency_domains, ...required]),
    ];
    const fields = new Set([
      ...binding.invalidated_by,
      ...design.change_log.map((entry) => entry.field),
    ]);
    const scientific = [],
      rights = [];
    const useDomains = new Set([
      "RIGHTS",
      "DEPLOYMENT",
      "INTENDED_USE",
      "COMMERCIAL_CONTEXT",
      "CPES_DISCLOSURE",
    ]);
    for (const field of fields) {
      let domains;
      try {
        domains = R.changedDomains(field);
      } catch (_error) {
        domains = ["UNRESOLVED_IMPACT"];
      }
      const relevant = domains.filter(
        (domain) =>
          binding.dependency_domains.includes(domain) ||
          domain === "UNRESOLVED_IMPACT",
      );
      for (const domain of relevant) {
        const target = useDomains.has(domain) ? rights : scientific;
        const reason = reconciliationReason(
          design,
          field,
          domain,
          useDomains.has(domain) ? "RIGHTS" : "SCI",
        );
        if (!target.some((item) => item.reason_id === reason.reason_id))
          target.push(reason);
      }
    }
    if (parentBinding) {
      for (const reason of parentBinding.scientific_review_reasons)
        if (!scientific.some((item) => item.reason_id === reason.reason_id))
          scientific.push(clone(reason));
      for (const reason of parentBinding.rights_review_reasons)
        if (!rights.some((item) => item.reason_id === reason.reason_id))
          rights.push(clone(reason));
    }
    const backed = design.measurement_evidence.some(
      (record) =>
        record.source &&
        record.source.result_digest === binding.source_digest_or_identity,
    );
    let scientificState = binding.scientific_applicability;
    if (scientific.length) scientificState = "REVIEW_REQUIRED";
    else if (parentBinding)
      scientificState = parentBinding.scientific_applicability;
    else if (
      ["CARRIED_FORWARD_UNCHANGED_SCOPE", "SOURCE_OWNER_CONFIRMED"].includes(
        scientificState,
      )
    )
      scientificState = "UNASSESSED";
    let rightsState = binding.use_or_rights_status;
    if (parentBinding?.use_or_rights_status === "PROHIBITED")
      rightsState = "PROHIBITED";
    else if (rightsState === "SOURCE_AUTHORIZED") rightsState = "UNRESOLVED";
    else if (rights.length && rightsState !== "PROHIBITED")
      rightsState = "REVIEW_REQUIRED";
    else if (rightsState === "UNCHANGED_SOURCE_SCOPE")
      rightsState = "UNRESOLVED";
    const originalId =
      parentBinding?.originating_binding_id || binding.evidence_binding_id;
    return {
      ...binding,
      originating_design_id:
        parentBinding?.originating_design_id || design.design_id,
      originating_design_revision:
        parentBinding?.originating_design_revision || design.revision,
      originating_binding_id: originalId,
      scope_relationship:
        scientific.length || rights.length
          ? "CHANGED"
          : binding.scientific_applicability ===
              "CARRIED_FORWARD_UNCHANGED_SCOPE"
            ? parentBinding
              ? "UNCHANGED"
              : "UNKNOWN"
            : "UNASSESSED",
      scientific_applicability: scientificState,
      scientific_review_reasons: scientific,
      use_or_rights_status: rightsState,
      rights_review_reasons: rights,
      assessment_basis:
        scientific.length || rights.length
          ? "v0.5 state reconciled from retained change history; unresolved obligations remain visible."
          : "v0.5 assessment retained without inventing a missing source-owner decision.",
      rationale:
        scientific.length || rights.length
          ? "Historical evidence remains retained; current applicability or use requires the recorded review."
          : binding.rationale,
      source_claimed_provenance: claimed,
      origin_verification:
        claimed === "NATIVE_IMPORTED_RESULT" && backed
          ? "PINNED_C05_FIXTURE_VERIFIED"
          : claimed === "EXTERNAL_LINKED_RECORD"
            ? "EXTERNAL_LOCATOR_ONLY"
            : parentBinding
              ? "WORKBENCH_DERIVED_LINEAGE"
              : "UNVERIFIED_CLAIM",
      status_provenance:
        claimed === "NATIVE_IMPORTED_RESULT" && backed
          ? "NATIVE_IMPORTED_RESULT"
          : claimed === "EXTERNAL_LINKED_RECORD"
            ? "EXTERNAL_LINKED_RECORD"
            : "LOCAL_MANUAL_ASSERTION",
    };
  }
  function migratePriorDesign(design, job) {
    const priorKeys = [
      "schema_version",
      "job_id",
      "design_id",
      "revision",
      "parent_design_id",
      "status",
      "alternative_label",
      "scope",
      "requirements",
      "traces",
      "cases",
      "score_plan",
      "reference_plan",
      "cpes",
      "authoring",
      "route_plan",
      "measurement_evidence",
      "evidence_bindings",
      "handoffs",
      "responses",
      "coordination",
      "decision",
      "change_log",
    ];
    exact(design, priorKeys, "v0.5 design");
    if (design.schema_version !== PRIOR_VERSION)
      throw Error("Invalid v0.5 design version");
    const parent = job.designs.find(
      (candidate) =>
        candidate.design_id === design.parent_design_id &&
        candidate.schema_version === VERSION,
    );
    design.schema_version = VERSION;
    design.route_plan.status_provenance =
      design.route_plan.route === "UNASSESSED"
        ? "WORKBENCH_DERIVED"
        : "LOCAL_MANUAL_ASSERTION";
    design.coordination.customer_outcome_provenance =
      design.coordination.customer_outcome === "OPEN"
        ? "WORKBENCH_DERIVED"
        : "LOCAL_MANUAL_ASSERTION";
    const actionIds = [
      ...design.handoffs.map((item) => item.request_id),
      ...design.coordination.external_records.map((item) => item.record_id),
    ];
    design.coordination.current_action_ref =
      actionIds.length === 1 ? actionIds[0] : "";
    design.evidence_bindings = design.evidence_bindings.map((binding) => {
      const parentBinding = parent?.evidence_bindings.find(
        (candidate) =>
          candidate.source_digest_or_identity ===
          binding.source_digest_or_identity,
      );
      return migratePriorBinding(binding, design, parentBinding);
    });
    design.decision.scientific_qualification = "NOT_QUALIFIED";
    design.decision.security_rights =
      design.decision.security_rights === "PROHIBITED"
        ? "PROHIBITED"
        : "UNRESOLVED";
    design.decision.launch_authorization = "NOT_AUTHORIZED";
    design.decision.native_launch_status = "NOT_LAUNCHED";
    design.source_assessments = S.newState();
  }
  function migrateAcceptedDesign(design) {
    const keys = [
      "schema_version", "job_id", "design_id", "revision", "parent_design_id",
      "status", "alternative_label", "scope", "requirements", "traces", "cases",
      "score_plan", "reference_plan", "cpes", "authoring", "route_plan",
      "measurement_evidence", "evidence_bindings", "handoffs", "responses",
      "coordination", "decision", "change_log",
    ];
    exact(design, keys, "v0.6 design");
    if (design.schema_version !== ACCEPTED_VERSION)
      throw Error("Invalid v0.6 design version");
    design.schema_version = VERSION;
    design.source_assessments = S.newState();
  }
  function migrateGoalWorkspace(value, digestStatus) {
    const w = clone(value),
      from = w.schema_version;
    if (from === INTAKE_WORKSPACE_VERSION) {
      if (
        w.application_version !== INTAKE_APP_VERSION ||
        w.decision_id !== "GOAL-WORKBENCH-08" ||
        w.base_application_merge !== "94762b6a8932ac6834c731a416c3a45c4cbf6170"
      )
        throw Error("Unsupported v0.8 workspace identity");
    } else if (from === ADMITTED_WORKSPACE_VERSION) {
      if (
        w.application_version !== ADMITTED_APP_VERSION ||
        w.decision_id !== "GOAL-WORKBENCH-07" ||
        w.base_application_merge !== "e5aafc522ca40db12f1897bcc0beacdedb44d823"
      )
        throw Error("Unsupported v0.7 workspace identity");
    } else if (from === ACCEPTED_WORKSPACE_VERSION) {
      if (
        w.application_version !== ACCEPTED_APP_VERSION ||
        w.decision_id !== "GOAL-WORKBENCH-05A" ||
        w.base_application_merge !== "3681f7fb10be0c6e278f53d59ff9b022099ef12d"
      )
        throw Error("Unsupported v0.6 workspace identity");
    } else if (from === PRIOR_WORKSPACE_VERSION) {
      if (
        w.application_version !== PRIOR_APP_VERSION ||
        w.decision_id !== "GOAL-WORKBENCH-05" ||
        w.base_application_merge !== "e576fbdc711c9194dbcc7d90405480e90577407e"
      )
        throw Error("Unsupported v0.5 workspace identity");
    } else if (from === OLD_WORKSPACE_VERSION) {
      if (
        w.application_version !== OLD_APP_VERSION ||
        w.decision_id !== "GOAL-WORKBENCH-04" ||
        w.base_application_merge !== "95e717f28fab66a087b1e7006ad2ba5e167e2ddf"
      )
        throw Error("Unsupported v0.4 workspace identity");
    } else if (from === LEGACY_WORKSPACE_VERSION) {
      if (
        w.application_version !== LEGACY_APP_VERSION ||
        w.decision_id !== "GOAL-WORKBENCH-02" ||
        w.base_application_merge !== "3fb98bfbfb9ca8dd3f6dd0d8e5a588a89b1c9932"
      )
        throw Error("Unsupported v0.3 workspace identity");
    } else throw Error("Unsupported goal workspace version");
    w.schema_version = WORKSPACE_VERSION;
    w.application_version = APP_VERSION;
    w.decision_id = "GOAL-WORKBENCH-09";
    w.base_application_merge = "4afb80566fc695a873d7154c203787991bb64267";
    for (const job of w.jobs) {
      if (from !== INTAKE_WORKSPACE_VERSION && Object.hasOwn(job, "team_review")) {
        if (JSON.stringify(job.team_review) !== JSON.stringify(T.newTeamReview()))
          throw Error("Declared legacy workspace contains non-empty future team-review state");
        delete job.team_review;
      }
      if (from !== INTAKE_WORKSPACE_VERSION)
        for (const design of job.designs)
          if (Object.hasOwn(design, "assessment")) {
            if (JSON.stringify(design.assessment) !== JSON.stringify(T.newAssessment()))
              throw Error("Declared legacy workspace contains non-empty future assessment state");
            delete design.assessment;
          }
      if (from === INTAKE_WORKSPACE_VERSION) {
        for (const design of job.designs) {
          if (design.schema_version !== INTAKE_VERSION)
            throw Error("Invalid v0.8 design version");
          design.schema_version = VERSION;
          design.assessment = T.newAssessment();
        }
      } else if (from === ADMITTED_WORKSPACE_VERSION) {
        for (const design of job.designs) {
          design.schema_version = VERSION;
          design.assessment = T.newAssessment();
        }
        job.intake_records = [];
      } else if (from === ACCEPTED_WORKSPACE_VERSION) {
        for (const design of job.designs) {
          migrateAcceptedDesign(design);
          design.assessment = T.newAssessment();
        }
        job.intake_records = [];
      } else if (from === PRIOR_WORKSPACE_VERSION) {
        exact(
          job,
          [
            "job_id",
            "title",
            "source_opportunity_id",
            "native_task_id",
            "accountable_owner",
            "lead",
            "assignment",
            "designs",
            "created_from",
          ],
          "v0.5 job",
        );
        for (const design of job.designs) {
          migratePriorDesign(design, job);
          design.assessment = T.newAssessment();
        }
        job.intake_records = [];
      } else {
        exact(
          job,
          [
            "job_id",
            "title",
            "source_opportunity_id",
            "native_task_id",
            "lead",
            "assignment",
            "designs",
            "created_from",
          ],
          "legacy job",
        );
        job.accountable_owner = "";
        job.intake_records = [];
        for (const design of job.designs) {
          migrateLegacyDesign(
            design,
            from === OLD_WORKSPACE_VERSION ? OLD_VERSION : LEGACY_VERSION,
          );
          design.assessment = T.newAssessment();
        }
      }
      job.team_review = T.newTeamReview();
      const selected =
        w.selected_job_id === job.job_id
          ? job.designs.find(
              (design) => design.design_id === w.selected_design_id,
            )
          : null;
      const drafts = job.designs.filter((design) => design.status === "DRAFT");
      job.working_design_id =
        selected?.design_id ||
        (drafts.length === 1 ? drafts[0].design_id : null);
    }
    w.migration_receipts.push({
      from,
      to: WORKSPACE_VERSION,
      original_digest_status: digestStatus,
      semantic_changes: [
        "Preserved all earlier job, sealed-design, CPES, C-05, authoring, handoff, response and change-history bytes.",
        from === INTAKE_WORKSPACE_VERSION
          ? "Added an empty team-review queue and design-assessment record. No reviewer, feasibility conclusion, source evidence, task result, client approval or route was fabricated."
          : from === ADMITTED_WORKSPACE_VERSION
          ? "Added an empty local-intake lineage collection; no client statement, route, owner, source assessment, consent or approval was fabricated. Existing source-assessment receipts remain subject to installed-snapshot revalidation."
          : from === ACCEPTED_WORKSPACE_VERSION
          ? "Added an empty repository-pinned source-assessment state. No migrated response, receipt, provenance label, or historical Workbench-06 fixture was admitted."
          : from === PRIOR_WORKSPACE_VERSION
          ? "Reconciled v0.5 carry labels into a separate scope relationship and cumulative scientific/rights review reasons; insufficient history remains unassessed or review-required."
          : "Added explicit working-design selection and cumulative applicability fields without inferring a route, qualification, rights grant, approval or launch.",
        "Revalidated claimed provenance: only an exact retained C-05 record keeps native status; manual labels and links remain claims or locators.",
      ],
    });
    return w;
  }
  function readWorkspace(raw, componentReader, digestStatus = "UNAVAILABLE") {
    const value = F.strictJsonParse(raw, { maxBytes: 2000000, maxDepth: 24 });
    if (value.schema_version === WORKSPACE_VERSION)
      return validateWorkspace(value, componentReader);
    if (
      value.schema_version === PRIOR_WORKSPACE_VERSION ||
      value.schema_version === INTAKE_WORKSPACE_VERSION ||
      value.schema_version === ADMITTED_WORKSPACE_VERSION ||
      value.schema_version === ACCEPTED_WORKSPACE_VERSION ||
      value.schema_version === OLD_WORKSPACE_VERSION ||
      value.schema_version === LEGACY_WORKSPACE_VERSION
    )
      return validateWorkspace(
        migrateGoalWorkspace(value, digestStatus),
        componentReader,
      );
    const component = componentReader(raw);
    const w = newWorkspace(component);
    w.migration_receipts.push({
      from: value.schema_version,
      to: WORKSPACE_VERSION,
      original_digest_status: digestStatus,
      semantic_changes: [
        "Preserved the complete v0.1/v0.2 Opportunity/CPES component.",
        "Added an empty direct-client routing, owner-status and evidence-applicability layer; no missing science, route or authority was inferred.",
        "Derived workflow, protection and economics outputs are recomputed.",
      ],
    });
    return w;
  }
  function reviseDesign(job, designId, newId, changes = []) {
    const found = job.designs.find((x) => x.design_id === designId);
    if (!found || found.status !== "DRAFT")
      throw Error("Only the current draft design can be revised");
    found.status = "SEALED";
    const next = clone(found);
    next.design_id = ident(newId, "new design ID");
    next.revision = found.revision + 1;
    next.parent_design_id = found.design_id;
    next.status = "DRAFT";
    next.cpes.design_binding_revision = next.revision;
    next.handoffs = [];
    next.responses = [];
    next.source_assessments = S.newState();
    const retainedAssessment = next.assessment
      ? clone(next.assessment)
      : T.newAssessment();
    next.assessment = T.newAssessment();
    for (const key of ["intended_engineering_decision", ...T.ASSESSMENT_FIELDS])
      next.assessment[key] = retainedAssessment[key];
    next.assessment.resource_scenarios = clone(retainedAssessment.resource_scenarios);
    next.assessment.work_packages = clone(retainedAssessment.work_packages);
    next.assessment.open_questions = clone(retainedAssessment.open_questions);
    next.measurement_evidence = [];
    next.evidence_bindings = R.carryEvidenceBindings(found, next);
    next.route_plan = R.newRoutePlan();
    next.coordination = R.newCoordination(next.revision);
    next.authoring = {
      template_id: next.authoring.template_id,
      requested_goal: next.authoring.requested_goal,
      compatibility: "UNASSESSED",
      request_id: "",
      result_ref: "",
      semantic_receipt: null,
      extension_request: null,
    };
    next.decision = {
      ...next.decision,
      authoring_status: "NOT_ATTEMPTED",
      evidence_status: "PLANNED_OR_MISSING",
      scientific_qualification: "NOT_QUALIFIED",
      launch_authorization: "NOT_AUTHORIZED",
      native_launch_status: "NOT_LAUNCHED",
    };
    for (const c of changes) applyChange(next, c.field, c.value, c.note || "");
    job.designs.push(next);
    job.working_design_id = next.design_id;
    return next;
  }
  function recordImpact(d, field, note = "") {
    if (d.status !== "DRAFT") throw Error("Sealed design is immutable");
    const domains = R.applyChangeImpact(d, field),
      entry = {
        field,
        kind:
          domains.length === 1 && domains[0] === "COMMERCIAL_CONTEXT"
            ? "EDITORIAL_OR_COMMERCIAL"
            : domains.includes("UNRESOLVED_IMPACT")
              ? "REVIEW_IMPACT_UNKNOWN"
              : "SCOPE_AWARE_CHANGE",
        impact: domains.join(", "),
        domains,
        note: str(note, "change note", 500),
      };
    d.change_log.push(entry);
    const cpesImpact =
      {
        intended_use: ["CPES protection", "CPES economics"],
        physics_family: ["CPES protection", "CPES economics"],
        exclusions: ["CPES protection", "CPES economics"],
        requirements: ["CPES protection", "CPES economics"],
        traces: ["CPES economics"],
        cases: ["CPES economics"],
        query_workload: ["CPES economics"],
        rights_scope: ["CPES protection"],
        population: ["CPES economics"],
        regime: ["CPES economics"],
        score: ["CPES economics"],
        reference: ["CPES protection", "CPES economics"],
        disclosure: ["CPES protection"],
        disclosure_scope: ["CPES protection"],
      }[field] || [];
    if (cpesImpact.length) {
      const warning = field + ": " + cpesImpact.join(", ");
      if (!d.cpes.invalidated_by.includes(warning))
        d.cpes.invalidated_by.push(warning);
    }
    if (domains.some((x) => R.C05_DOMAINS.includes(x)))
      for (const evidence of d.measurement_evidence)
        evidence.binding_status = "STALE_DESIGN_CHANGED";
    if (domains.includes("AUTHORING")) {
      d.authoring.compatibility = "UNASSESSED";
      d.authoring.semantic_receipt = null;
      d.decision.authoring_status = "NOT_ATTEMPTED";
    }
    if (domains.some((x) => x !== "COMMERCIAL_CONTEXT")) {
      d.decision.launch_authorization = "NOT_AUTHORIZED";
      d.decision.native_launch_status = "NOT_LAUNCHED";
    }
    d.coordination.last_relevant_design_revision = d.revision;
    return domains;
  }
  function applyChange(d, field, value, note = "") {
    if (d.status !== "DRAFT") throw Error("Sealed design is immutable");
    const target = d.scope;
    if (!Object.hasOwn(target, field)) throw Error("Unknown change field");
    target[field] = str(value, "changed value");
    return recordImpact(d, field, note);
  }

  function intakeRecordFrom(inspection, mappedRequirementIds) {
    return {
      draft_id: inspection.draft.draft_id,
      revision_id: inspection.draft.revision_id,
      predecessor_canonical_digest:
        inspection.draft.predecessor?.canonical_digest || null,
      raw_sha256: inspection.raw_sha256,
      canonical_digest: inspection.canonical_digest,
      raw_json: inspection.raw_json,
      validated_draft: clone(inspection.draft),
      mapped_requirement_ids: clone(mappedRequirementIds),
      import_status: "IMPORTED_LOCAL_ASSERTION",
    };
  }

  function previewIntakeImport(workspace, inspection) {
    I.validateDraft(inspection.draft);
    if (
      typeof inspection.raw_json !== "string" ||
      !/^sha256:[0-9a-f]{64}$/.test(inspection.raw_sha256) ||
      !/^sha256:[0-9a-f]{64}$/.test(inspection.canonical_digest)
    )
      throw Error("Incomplete intake inspection");
    const records = [];
    for (const job of workspace.jobs)
      for (const record of job.intake_records || []) records.push({ job, record });
    const identity = records.filter(
      ({ record }) =>
        record.draft_id === inspection.draft.draft_id &&
        record.revision_id === inspection.draft.revision_id,
    );
    if (identity.length) {
      const exactReplay = identity.find(
        ({ record }) =>
          record.raw_sha256 === inspection.raw_sha256 &&
          record.canonical_digest === inspection.canonical_digest,
      );
      if (exactReplay)
        return {
          action: "EXACT_REPLAY",
          target_job_id: exactReplay.job.job_id,
          mapping: I.mapDraft(inspection.draft, inspection.canonical_digest, inspection.review_package),
          message: "This exact intake revision is already linked; no new job, requirement, or handoff will be created.",
        };
      return {
        action: "IDENTITY_CONFLICT",
        target_job_id: identity[0].job.job_id,
        mapping: I.mapDraft(inspection.draft, inspection.canonical_digest, inspection.review_package),
        message: "The claimed draft/revision identity already exists with different bytes. Reconciliation is required.",
      };
    }
    const predecessor = inspection.draft.predecessor;
    if (predecessor) {
      const matches = records.filter(
        ({ record }) =>
          record.draft_id === predecessor.draft_id &&
          record.revision_id === predecessor.revision_id &&
          record.canonical_digest === predecessor.canonical_digest,
      );
      if (matches.length !== 1)
        return {
          action: "RECONCILIATION_REQUIRED",
          target_job_id: null,
          mapping: I.mapDraft(inspection.draft, inspection.canonical_digest, inspection.review_package),
          message:
            matches.length === 0
              ? "The declared predecessor is not present. Import it first or explicitly create a separate inquiry."
              : "The predecessor association is ambiguous; choose the target outside this automatic path.",
        };
      return {
        action: "ADD_REVISION_FOR_REVIEW",
        target_job_id: matches[0].job.job_id,
        mapping: I.mapDraft(inspection.draft, inspection.canonical_digest, inspection.review_package),
        message: "Attach this successor as an unreviewed intake revision. It will not overwrite a sealed design or change scientific state.",
      };
    }
    if (records.some(({ record }) => record.draft_id === inspection.draft.draft_id))
      return {
        action: "RECONCILIATION_REQUIRED",
        target_job_id: null,
        mapping: I.mapDraft(inspection.draft, inspection.canonical_digest, inspection.review_package),
        message: "This draft ID is already known, but no predecessor was supplied. The Workbench will not guess whether it is a revision or a separate inquiry.",
      };
    return {
      action: "CREATE_NEW_JOB",
      target_job_id: null,
      mapping: I.mapDraft(inspection.draft, inspection.canonical_digest, inspection.review_package),
      message: "Create one new unassessed job with source-linked requirement candidates and unresolved science and rights.",
    };
  }

  function commitIntakeImport(workspace, inspection, preview) {
    const current = previewIntakeImport(workspace, inspection);
    if (
      current.action !== preview.action ||
      current.target_job_id !== preview.target_job_id
    )
      throw Error("Intake preview is stale; review the import again");
    if (current.action === "EXACT_REPLAY")
      return { action: current.action, job_id: current.target_job_id, changed: false };
    if (!["CREATE_NEW_JOB", "ADD_REVISION_FOR_REVIEW"].includes(current.action))
      throw Error(current.message);
    if (current.action === "ADD_REVISION_FOR_REVIEW") {
      const target = workspace.jobs.find((item) => item.job_id === current.target_job_id);
      if (!target) throw Error("Intake target job is unavailable");
      target.intake_records.push(intakeRecordFrom(inspection, []));
      target.team_review.queue_state = "READY_FOR_REVIEW";
      target.team_review.current_action =
        "Review the revised client brief and decide which design revision, if any, it changes.";
      target.team_review.next_restart_event =
        "A reviewer records the revision association or requests clarification.";
      return { action: current.action, job_id: target.job_id, changed: true };
    }
    const base =
      "intake-" +
      inspection.draft.draft_id
        .toLowerCase()
        .replace(/[^a-z0-9._:-]/g, "-")
        .slice(0, 100);
    let id = base || "intake-job";
    let suffix = 2;
    while (workspace.jobs.some((item) => item.job_id === id)) id = base + "-" + suffix++;
    const mapped = current.mapping;
    const target = newJob(id, mapped.title);
    target.created_from = "ASSISTED_INTAKE";
    Object.assign(target.assignment, mapped.assignment);
    const design = target.designs[0];
    for (const [key, value] of Object.entries(mapped.scope)) design.scope[key] = value;
    const requirementIds = [];
    mapped.requirements.forEach((item, index) => {
      const requirementId = "INTAKE-REQ-" + String(index + 1).padStart(3, "0");
      design.requirements.push(
        requirement(
          requirementId,
          item.original_words,
          item.source_reference,
          item.consequence,
          item.kind,
        ),
      );
      requirementIds.push(requirementId);
    });
    target.intake_records.push(intakeRecordFrom(inspection, requirementIds));
    target.team_review.queue_state = "READY_FOR_REVIEW";
    target.team_review.current_action =
      "Assign one reviewer and assess the source-linked brief before selecting a route.";
    target.team_review.next_restart_event =
      "A reviewer is assigned or the client supplies a named clarification.";
    workspace.jobs.push(target);
    workspace.selected_job_id = target.job_id;
    workspace.selected_design_id = design.design_id;
    return { action: current.action, job_id: target.job_id, changed: true };
  }

  async function revalidateIntakeRecords(workspace) {
    for (const job of workspace.jobs) {
      for (const record of job.intake_records || []) {
        const checked = await I.inspect(record.raw_json, F.strictJsonParse);
        if (
          checked.raw_sha256 !== record.raw_sha256 ||
          checked.canonical_digest !== record.canonical_digest ||
          JSON.stringify(checked.draft) !== JSON.stringify(record.validated_draft) ||
          checked.draft.draft_id !== record.draft_id ||
          checked.draft.revision_id !== record.revision_id
        )
          throw Error("Stored intake identity or content failed revalidation");
      }
    }
    return workspace;
  }

  function economics(d) {
    const result = F.fixedGroupEconomics(d.cpes.economics),
      stale = d.cpes.invalidated_by.some((x) => x.includes("CPES economics"));
    if (!stale) return result;
    return {
      ...result,
      status: "STALE_FOR_REVIEW",
      relation: "unknown",
      message:
        "Preserved scenario belongs to an earlier design meaning. Reconfirm reference adequacy, compatibility, demand, overhead and service scope before using its arithmetic.",
    };
  }
  function coverage(d) {
    const active = new Set(
        d.requirements
          .filter((x) => x.kind === "MATERIAL" || x.kind === "CONSTRAINT")
          .map((x) => x.requirement_id),
      ),
      covered = new Set(
        d.traces
          .filter(
            (x) => !x.gap && x.measurement_definition && x.authoring_binding,
          )
          .map((x) => x.requirement_id),
      ),
      caseCovered = new Set(d.cases.flatMap((x) => x.requirement_ids));
    const missing = [...active].filter((x) => !covered.has(x)),
      missingCases = [...active].filter((x) => !caseCovered.has(x));
    const orphan = d.traces.filter((x) => !active.has(x.requirement_id)),
      orphanCases = d.cases.filter((x) => !x.requirement_ids.length),
      caseWithoutTrace = d.cases.filter((x) =>
        x.requirement_ids.some((id) => !covered.has(id)),
      );
    const unresolvedFloor = d.traces
      .filter((x) => x.role !== "DIAGNOSTIC" && !x.floor)
      .map((x) => x.trace_id);
    const weighting = d.cases
        .filter(
          (x) =>
            x.target_mass &&
            x.sampling_frequency &&
            x.target_mass === x.sampling_frequency &&
            x.analysis_weight === "",
        )
        .map((x) => x.case_family_id),
      current = d.measurement_evidence.filter(
        (x) => x.binding_status === "CURRENT_DESIGN_REVISION",
      ),
      executed = new Set(
        current
          .filter(
            (x) => x.evidence_state === "SOURCE_MEASUREMENT_EVIDENCE_BOUND",
          )
          .flatMap((x) => x.requirement_trace_ids),
      );
    const traceEvidence = d.traces.map((x) => ({
      trace_id: x.trace_id,
      requirement_id: x.requirement_id,
      structural_trace: x.gap ? "GAP" : "STRUCTURAL_ONLY",
      source_execution: executed.has(x.trace_id)
        ? "SOURCE_MEASUREMENT_EXECUTED"
        : "NOT_EXECUTED",
      scientific_decision: executed.has(x.trace_id)
        ? "SCIENTIFIC_DECISION_UNRESOLVED"
        : "NOT_AVAILABLE",
      qualification: "NOT_QUALIFIED",
    }));
    return {
      status:
        missing.length ||
        missingCases.length ||
        orphan.length ||
        orphanCases.length ||
        caseWithoutTrace.length ||
        unresolvedFloor.length ||
        weighting.length
          ? "GAPS"
          : executed.size
            ? "STRUCTURALLY_ASSEMBLED_WITH_SOURCE_MEASUREMENT_EVIDENCE"
            : "STRUCTURALLY_ASSEMBLED_NOT_NUMERICALLY_AUDITED",
      missing_requirements: missing,
      missing_case_requirements: missingCases,
      orphan_traces: orphan.map((x) => x.trace_id),
      orphan_case_families: orphanCases.map((x) => x.case_family_id),
      case_families_without_complete_trace: caseWithoutTrace.map(
        (x) => x.case_family_id,
      ),
      unresolved_floors: unresolvedFloor,
      population_sampling_weighting_questions: weighting,
      numerical_diagnostic: executed.size
        ? "SOURCE_MEASUREMENT_EXECUTED_SCIENTIFIC_DECISION_UNRESOLVED"
        : "NOT_EXECUTED_UNLESS_SOURCE_OWNED_RESULT_IS_BOUND",
      trace_evidence: traceEvidence,
      source_evidence_count: current.length,
    };
  }
  function prospectivePreferenceDiagnostic(example) {
    enumValue(example, DIAGNOSTIC_EXAMPLES, "diagnostic example");
    const mandatory = [
      "MANDATORY_FAILURE",
      "NONFINITE_OR_WITHHELD",
      "DROPPED_WORK",
    ].includes(example);
    return {
      schema_version: "carbon.goal-workbench.prospective-diagnostic.v1",
      example,
      expected_relation: mandatory
        ? "INELIGIBLE_REGARDLESS_OF_AVERAGE"
        : "NO_TOTAL_RANK_WITHOUT_OWNER_TRADEOFF",
      implementation_layer: "WORKBENCH_STRUCTURAL_EXPECTATION",
      official_score: false,
      numerical_execution: "NOT_EXECUTED",
      limitation:
        "Prospective structural expectation only; use a source-owned measurement/scoring result for numerical evidence.",
    };
  }
  function diagnosticRequest(d, requestId) {
    return {
      schema_version: "carbon.goal-workbench.measurement-diagnostic-request.v1",
      request_id: ident(requestId, "diagnostic request ID"),
      job_id: d.job_id,
      design_id: d.design_id,
      design_revision: d.revision,
      question:
        "Do the source-owned measurement and score interfaces preserve these frozen failure/preference relationships for this exact design?",
      frozen_expectations: DIAGNOSTIC_EXAMPLES.map(
        prospectivePreferenceDiagnostic,
      ),
      bindings: {
        requirements: clone(d.requirements),
        measurement_score: clone(d.traces),
        score_plan: clone(d.score_plan),
        population_cases: clone(d.cases),
        reference_plan: clone(d.reference_plan),
      },
      source_association: {
        requirement_trace_ids: d.traces.map((x) => x.trace_id),
        case_family_ids: d.cases.map((x) => x.case_family_id),
        challenge: { id: "burgers-dynamics-v1", version: "1.0" },
        template_id: d.scope.physics_family,
        expected_source_interface: E.RESULT_SCHEMA,
        evidence_scope: "PUBLIC_DEVELOPMENT_ONLY",
      },
      required_output: {
        request_binding:
          "Return this request ID, job/design/revision, exact source request/result digests, implementation identity, case/candidate provenance, limitations and imported artifact digest.",
        result_scope:
          "Return exact source-owned C-05 request/result bytes; retain typed non-complete dispositions and unresolved scientific decisions.",
        authority:
          "A numerical result remains scoped evidence and cannot qualify the exam or invent uncertainty, floors, weights, ranks or scores.",
      },
      source_owner: "C-05 measurement runtime owner",
      route: "LOCAL_STRICT_C05_READER",
      status: "NOT_EXECUTED",
      authority: "REQUEST_ONLY_NO_SCORER_EXECUTION_OR_QUALIFICATION",
    };
  }
  function compatibility(d) {
    const gaps = [];
    if (d.scope.physics_family !== "periodic_viscous_burgers_1d_v1")
      gaps.push(
        "physics template is not the closed public Burgers v1 template",
      );
    if (d.scope.requested_goal !== "Dynamics")
      gaps.push("requested active goal is not Dynamics");
    if (d.scope.rights_scope !== "SYNTHETIC_INTERNAL")
      gaps.push("rights scope is not SYNTHETIC_INTERNAL");
    for (const k of [
      "inputs",
      "outputs",
      "units",
      "conditions",
      "query_workload",
      "turnaround",
    ])
      if (!d.scope[k]) gaps.push(k + " semantics are unresolved");
    if (!coverage(d).status.startsWith("STRUCTURALLY_ASSEMBLED"))
      gaps.push("requirement/measurement trace has structural gaps");
    if (
      !d.cases.length ||
      d.cases.some(
        (x) =>
          x.generator_ref !== "goal_burgers_12cell_v1" ||
          !["TRAIN", "EVAL", "STRESS"].includes(x.role),
      )
    )
      gaps.push("case/generator binding is absent or outside the source plans");
    if (
      !d.score_plan.mandatory_gate_summary ||
      !d.score_plan.soft_estimand ||
      d.score_plan.official_score_status !== "PROPOSED_UNQUALIFIED" ||
      d.score_plan.reward_accounting !== "SEPARATE_UNRESOLVED"
    )
      gaps.push("score roles do not bind the source DEVELOPMENT proposal");
    if (!d.reference_plan.equation || !d.reference_plan.method)
      gaps.push("reference law/method binding is unresolved");
    const exact = !gaps.length;
    return {
      compatible: exact,
      status: exact ? "EXACT_SUPPORTED" : "EXTENSION_REQUIRED",
      reason: exact
        ? "Exact source-owned public DEVELOPMENT template and active Dynamics goal are semantically bound."
        : "The fixed compiler is callable only for its closed public Burgers inputs; unresolved or different semantics require an extension or owner review.",
      gaps,
    };
  }
  function authoringRequest(d, requestId) {
    const c = compatibility(d),
      id = ident(requestId, "authoring request ID"),
      callable =
        d.scope.physics_family === "periodic_viscous_burgers_1d_v1" &&
        ["Dynamics", "Transport", "Front Resolution", "Dissipation"].includes(
          d.scope.requested_goal,
        ) &&
        d.scope.rights_scope === "SYNTHETIC_INTERNAL" &&
        d.scope.units !== "";
    d.authoring.template_id = d.scope.physics_family;
    d.authoring.requested_goal = d.scope.requested_goal;
    d.authoring.request_id = id;
    d.authoring.compatibility = c.compatible
      ? "EXACT_SUPPORTED"
      : "EXTENSION_REQUIRED";
    if (!c.compatible) d.authoring.extension_request = extensionRequest(d, id);
    return {
      schema_version: "carbon.goal-workbench.authoring-request.v1",
      request_id: id,
      job_id: d.job_id,
      design_id: d.design_id,
      design_revision: d.revision,
      template_id: d.scope.physics_family,
      requested_goal: d.scope.requested_goal,
      intended_use: d.scope.intended_use,
      rights_scope: d.scope.rights_scope,
      expected_semantics: {
        physical_law: {
          template_id: d.scope.physics_family,
          equation: d.reference_plan.equation,
          conditions: d.scope.conditions,
        },
        active_goal: d.scope.requested_goal,
        score_plan: clone(d.score_plan),
        measurement_bindings: d.traces.map((x) => ({
          requirement_id: x.requirement_id,
          role: x.role,
          binding: x.authoring_binding,
        })),
        sampling: d.cases.map((x) => ({
          case_family_id: x.case_family_id,
          role: x.role,
          generator_ref: x.generator_ref,
          target_population: x.target_population,
          sampling_frequency: x.sampling_frequency,
          analysis_weight: x.analysis_weight,
        })),
        references: clone(d.reference_plan),
        query_contract: {
          inputs: d.scope.inputs,
          outputs: d.scope.outputs,
          units: d.scope.units,
          query_workload: d.scope.query_workload,
          turnaround: d.scope.turnaround,
        },
      },
      compatibility: c,
      route: callable ? "LOCAL_FIXED_CLI" : "SOURCE_OWNER_EXTENSION",
      authority: "DEVELOPMENT_REQUEST_ONLY",
    };
  }
  function extensionRequest(d, requestId) {
    return {
      schema_version: "carbon.goal-workbench.authoring-extension.v1",
      request_id: requestId,
      job_id: d.job_id,
      design_id: d.design_id,
      design_revision: d.revision,
      missing_capability: [
        d.scope.physics_family || "physics template",
        d.scope.requested_goal || "active goal",
      ].join(" / "),
      client_rationale: d.scope.intended_use,
      compatible_existing_components: d.scope.physics_family.includes("burgers")
        ? "Burgers fixed compiler may supply non-authoritative components only."
        : "None established by this tool.",
      proposed_tests:
        "Compile, compare physical law/active goal/score/cases/reference/query semantics, and reject omissions or coercions.",
      unresolved_scientific_choices:
        d.score_plan.unresolved_tradeoffs ||
        "Target population, measurement adequacy, uncertainty and owner acceptance remain unresolved.",
      owner_interface: "C-AUTH1 scientific authoring owner",
    };
  }
  function validateExtension(x) {
    exact(
      x,
      [
        "schema_version",
        "request_id",
        "job_id",
        "design_id",
        "design_revision",
        "missing_capability",
        "client_rationale",
        "compatible_existing_components",
        "proposed_tests",
        "unresolved_scientific_choices",
        "owner_interface",
      ],
      "extension request",
    );
    if (x.schema_version !== "carbon.goal-workbench.authoring-extension.v1")
      throw Error("Invalid extension schema");
    for (const k of ["request_id", "job_id", "design_id"]) ident(x[k], k);
    integer(x.design_revision, "extension revision", 1);
    for (const k of [
      "missing_capability",
      "client_rationale",
      "compatible_existing_components",
      "proposed_tests",
      "unresolved_scientific_choices",
      "owner_interface",
    ])
      str(x[k], k);
    return clone(x);
  }
  function semanticCompare(request, proposal, proposalDigest, inputDigest) {
    if (
      !proposal ||
      proposal.schema_version !== "carbon.goal-authoring-proposal/1"
    )
      throw Error("Unsupported native authoring result");
    const reports = Array.isArray(proposal.goal_reports)
        ? proposal.goal_reports
        : [],
      activeCount = reports.length
        ? reports.filter((x) => x.activation === "PRIMARY_CHALLENGE").length
        : proposal.challenge?.competition_count;
    const emitted = {
      physical_law: proposal.physical_contract || {},
      active_goal: proposal.challenge?.primary_goal || "",
      source_goal: proposal.evidence_boundary?.source_goal || "",
      active_goal_count: activeCount,
      measurement: proposal.measurement_proposal || {},
      score: proposal.score_proposal || {},
      sampling: proposal.plans || {},
      references: proposal.reference_candidates || [],
      query_contract: {
        candidate_payload_allow_list:
          proposal.training_adapter?.candidate_payload_allow_list || [],
        point_query_rule: proposal.measurement_proposal?.point_query_rule || "",
      },
      capabilities: proposal.capabilities || {},
    };
    const mismatches = [];
    if (request.template_id !== "periodic_viscous_burgers_1d_v1")
      mismatches.push("physics template unsupported");
    if (request.requested_goal !== emitted.active_goal)
      mismatches.push(
        "requested active goal " +
          request.requested_goal +
          " emitted as " +
          emitted.active_goal,
      );
    if (emitted.active_goal_count !== 1)
      mismatches.push("active goal count changed");
    if (request.compatibility?.status !== "EXACT_SUPPORTED")
      mismatches.push(
        "workbench design has unresolved semantic bindings: " +
          (request.compatibility?.gaps || []).join("; "),
      );
    if (
      !emitted.capabilities ||
      Object.values(emitted.capabilities).some(Boolean)
    )
      mismatches.push("authority flags unexpectedly enabled");
    return {
      schema_version: "carbon.goal-workbench.semantic-receipt.v1",
      request_id: request.request_id,
      job_id: request.job_id,
      design_id: request.design_id,
      design_revision: request.design_revision,
      input_digest: inputDigest,
      proposal_digest: proposalDigest,
      expected: clone(request.expected_semantics),
      emitted,
      mismatches,
      status: mismatches.length ? "INTENT_MISMATCH" : "INTENT_PRESERVED",
      qualification: "NOT_QUALIFIED",
      launch: "NOT_LAUNCHED",
    };
  }
  function validateSemanticReceipt(r) {
    exact(
      r,
      [
        "schema_version",
        "request_id",
        "job_id",
        "design_id",
        "design_revision",
        "input_digest",
        "proposal_digest",
        "expected",
        "emitted",
        "mismatches",
        "status",
        "qualification",
        "launch",
      ],
      "semantic receipt",
    );
    if (r.schema_version !== "carbon.goal-workbench.semantic-receipt.v1")
      throw Error("Invalid semantic receipt schema");
    for (const k of ["request_id", "job_id", "design_id"]) ident(r[k], k);
    integer(r.design_revision, "receipt revision", 1);
    str(r.input_digest, "input digest", 200, false);
    str(r.proposal_digest, "proposal digest", 200, false);
    list(r.mismatches, "semantic mismatches", 32).forEach((x) =>
      str(x, "mismatch", 1000, false),
    );
    enumValue(
      r.status,
      ["INTENT_PRESERVED", "INTENT_MISMATCH"],
      "semantic status",
    );
    if (r.qualification !== "NOT_QUALIFIED" || r.launch !== "NOT_LAUNCHED")
      throw Error("Semantic receipt authority promotion");
    return clone(r);
  }
  function importAuthoringResult(d, request, result) {
    exact(
      result,
      [
        "schema_version",
        "request_id",
        "job_id",
        "design_id",
        "design_revision",
        "input_digest",
        "proposal_digest",
        "proposal",
        "cli_result",
        "semantic_receipt",
        "source_revision",
        "route",
      ],
      "authoring result",
    );
    if (
      result.schema_version !== "carbon.goal-workbench.authoring-result.v1" ||
      result.request_id !== request.request_id ||
      result.job_id !== d.job_id ||
      result.design_id !== d.design_id ||
      result.design_revision !== d.revision
    )
      throw Error("Wrong or stale authoring result association");
    const receipt = validateSemanticReceipt(result.semantic_receipt);
    const recomputed = semanticCompare(
      request,
      result.proposal,
      result.proposal_digest,
      result.input_digest,
    );
    if (JSON.stringify(receipt) !== JSON.stringify(recomputed))
      throw Error("Forged or stale semantic receipt");
    d.authoring.semantic_receipt = receipt;
    d.authoring.result_ref = result.proposal_digest;
    d.authoring.compatibility =
      receipt.status === "INTENT_PRESERVED"
        ? "EXACT_SUPPORTED"
        : "INTENT_MISMATCH";
    d.decision.authoring_status = receipt.status;
    return receipt;
  }
  function handoff(
    d,
    {
      request_id,
      recipient,
      lead,
      question,
      required_output,
      route = "MANUAL",
      permitted_data = "",
      rights = "",
      required_authority = "",
      allowance = "",
      stop_condition = "",
      input_refs = [],
      dependency_owner = "",
      restart_event = "",
      native_task_id = "",
    },
  ) {
    const h = {
      schema_version: HANDOFF_VERSION,
      request_id: ident(request_id, "request ID"),
      base_revision: d.revision,
      job_id: d.job_id,
      design_id: d.design_id,
      design_revision: d.revision,
      native_task_id: str(native_task_id, "native task ID", 300),
      sender: "WORKBENCH_PREPARER",
      recipient: str(recipient, "recipient", 300, false),
      lead: str(lead, "lead", 300, false),
      question: str(question, "question", 8000, false),
      required_output: str(required_output, "required output", 8000, false),
      permitted_data: str(permitted_data, "permitted data"),
      rights: str(rights, "rights"),
      required_authority: str(required_authority, "authority"),
      allowance: str(allowance, "allowance"),
      stop_condition: str(stop_condition, "stop condition"),
      input_artifact_refs: list(input_refs, "input refs", 32).map((x) =>
        str(x, "input ref", 500, false),
      ),
      dependency_owner: str(dependency_owner, "dependency owner", 300),
      restart_event: str(restart_event, "restart event", 1000),
      route: enumValue(
        route,
        ["MANUAL", "VERIFIED_CONNECTOR", "UNAVAILABLE"],
        "route",
      ),
      status: "PREPARED",
      authority: "REQUEST_ONLY_NO_EXECUTION_OR_APPROVAL",
    };
    validateHandoff(h, d);
    if (d.handoffs.some((x) => x.request_id === h.request_id))
      throw Error("Duplicate handoff request ID");
    d.handoffs.push(h);
    d.coordination.current_action_ref = h.request_id;
    return clone(h);
  }
  function validateHandoff(h, d) {
    exact(
      h,
      [
        "schema_version",
        "request_id",
        "base_revision",
        "job_id",
        "design_id",
        "design_revision",
        "native_task_id",
        "sender",
        "recipient",
        "lead",
        "question",
        "required_output",
        "permitted_data",
        "rights",
        "required_authority",
        "allowance",
        "stop_condition",
        "input_artifact_refs",
        "dependency_owner",
        "restart_event",
        "route",
        "status",
        "authority",
      ],
      "handoff",
    );
    if (
      h.schema_version !== HANDOFF_VERSION ||
      h.job_id !== d.job_id ||
      h.design_id !== d.design_id ||
      h.design_revision !== d.revision ||
      h.base_revision !== d.revision
    )
      throw Error("Wrong or stale handoff binding");
    ident(h.request_id, "request ID");
    enumValue(
      h.route,
      ["MANUAL", "VERIFIED_CONNECTOR", "UNAVAILABLE"],
      "route",
    );
    enumValue(
      h.status,
      ["PREPARED", "EXPORTED", "ACKNOWLEDGED", "RETURNED", "BLOCKED"],
      "handoff status",
    );
    if (h.authority !== "REQUEST_ONLY_NO_EXECUTION_OR_APPROVAL")
      throw Error("Handoff authority promotion");
    list(h.input_artifact_refs, "input refs", 32).forEach((x) =>
      str(x, "input ref", 500, false),
    );
    for (const k of ["recipient", "lead", "question", "required_output"])
      str(h[k], "handoff " + k, 8000, false);
    for (const k of [
      "native_task_id",
      "sender",
      "permitted_data",
      "rights",
      "required_authority",
      "allowance",
      "stop_condition",
      "dependency_owner",
      "restart_event",
    ])
      str(h[k], "handoff " + k);
    return clone(h);
  }
  function markExported(d, requestId) {
    const h = d.handoffs.find((x) => x.request_id === requestId);
    if (!h) throw Error("Unknown handoff");
    if (h.status !== "PREPARED" && h.status !== "EXPORTED")
      throw Error("Handoff cannot be exported from current state");
    h.status = "EXPORTED";
    return clone(h);
  }
  function validateResponse(r, d) {
    exact(
      r,
      [
        "schema_version",
        "response_id",
        "request_id",
        "base_revision",
        "job_id",
        "design_id",
        "design_revision",
        "kind",
        "route",
        "source_owner",
        "status",
        "output_reference",
        "input_digest",
        "authority_class",
        "verification_reference",
        "limitations",
        "note",
        "content_sha256",
      ],
      "response",
    );
    if (
      r.schema_version !== RESPONSE_VERSION ||
      r.job_id !== d.job_id ||
      r.design_id !== d.design_id ||
      r.design_revision !== d.revision ||
      r.base_revision !== d.revision
    )
      throw Error("Wrong or stale response binding");
    for (const k of ["response_id", "request_id"]) ident(r[k], k);
    enumValue(
      r.kind,
      [
        "ACKNOWLEDGMENT",
        "RESULT",
        "BLOCKER",
        "OWNER_DECISION",
        "LAUNCH_STATUS",
      ],
      "response kind",
    );
    enumValue(
      r.route,
      ["MANUAL", "VERIFIED_CONNECTOR", "UNAVAILABLE", "TEST_FIXTURE"],
      "response route",
    );
    enumValue(
      r.authority_class,
      [
        "UNVERIFIED_ASSERTION",
        "VERIFIED_OWNER_DECISION",
        "SYNTHETIC_TEST_EVIDENCE",
      ],
      "authority class",
    );
    for (const k of [
      "source_owner",
      "status",
      "output_reference",
      "input_digest",
      "verification_reference",
      "limitations",
      "note",
    ])
      str(r[k], "response " + k);
    if (
      typeof r.content_sha256 !== "string" ||
      !/^[a-f0-9]{64}$/.test(r.content_sha256)
    )
      throw Error("Invalid response content SHA-256");
    return clone(r);
  }
  function importResponse(d, r, _options = {}) {
    validateResponse(r, d);
    const h = d.handoffs.find((x) => x.request_id === r.request_id);
    if (!h) throw Error("Response references unknown request");
    const prior = d.responses.find((x) => x.response_id === r.response_id);
    if (prior) {
      if (
        prior.content_sha256 === r.content_sha256 &&
        JSON.stringify(prior) === JSON.stringify(r)
      )
        return { disposition: "DEDUPLICATED", authoritative: false };
      throw Error("Conflicting response identity");
    }
    if (r.authority_class === "VERIFIED_OWNER_DECISION")
      throw Error("No trusted authority verification route for this import");
    d.responses.push(clone(r));
    if (r.kind === "ACKNOWLEDGMENT") h.status = "ACKNOWLEDGED";
    else if (r.kind === "BLOCKER") h.status = "BLOCKED";
    else h.status = "RETURNED";
    if (r.kind === "LAUNCH_STATUS")
      d.decision.native_launch_status = "NOT_LAUNCHED";
    return {
      disposition: "IMPORTED",
      authoritative: false,
    };
  }
  function launchCandidate(d, nativeTaskId = "") {
    const c = coverage(d),
      open = [];
    if (!c.status.startsWith("STRUCTURALLY_ASSEMBLED"))
      open.push("Close structural requirement/score/case trace gaps.");
    if (d.authoring.semantic_receipt?.status !== "INTENT_PRESERVED")
      open.push("Obtain intent-preserving native authoring output.");
    if (d.decision.scientific_qualification !== "OWNER_VERIFIED_SCOPED")
      open.push(
        "Scientific owner qualification for this exact design is absent.",
      );
    if (d.decision.security_rights !== "OWNER_VERIFIED_SCOPED")
      open.push("Security, custody and rights acceptance is absent.");
    open.push(
      "AT-09, AT-16, AT-19, AT-22 and AT-30 remain source-backed unresolved claims; user applicability assertions cannot clear them.",
    );
    return {
      schema_version: LAUNCH_VERSION,
      job_id: d.job_id,
      design_id: d.design_id,
      design_revision: d.revision,
      native_identifiers: {
        native_task_id: str(nativeTaskId, "native task ID", 300),
        authoring_result_ref: d.authoring.result_ref,
      },
      bindings: {
        physical: d.scope.physics_family,
        generator: d.cases.map((x) => x.generator_ref),
        sampling: d.cases.map((x) => x.case_family_id),
        measurement_score: d.traces.map((x) => x.authoring_binding),
        reference: d.reference_plan.method,
        protection: d.cpes.study_ref,
        rights: d.scope.rights_scope,
      },
      remaining_decisions: open,
      status: "MANUAL_OWNER_HANDOFF_REQUIRED",
      native_launch_interface: "UNAVAILABLE",
      authority: "CANDIDATE_ONLY_NOT_AUTHORIZED_OR_LAUNCHED",
    };
  }
  function clientProjection(job, d) {
    const status = R.ownerSummary(job, d);
    return {
      schema_version: "carbon.goal-workbench.client-summary.v1",
      job_id: job.job_id,
      design_id: d.design_id,
      design_revision: d.revision,
      planning_route: d.route_plan.route,
      intended_decision: job.assignment.intended_decision,
      credible_baseline: job.assignment.credible_baseline,
      client_words: job.assignment.client_words,
      proposed_scope: {
        outputs: d.scope.outputs,
        units: d.scope.units,
        regime: d.scope.regime,
        exclusions: d.scope.exclusions,
      },
      requirements: d.requirements.map((x) => ({
        original_words: x.original_words,
        decision_consequence: x.decision_consequence,
        agreement_status: x.agreement_status,
      })),
      source_measurement_evidence: d.measurement_evidence
        .filter((x) => x.binding_status === "CURRENT_DESIGN_REVISION")
        .map(E.clientSummary),
      applicability_summary: d.evidence_bindings.map((x) => ({
        evidence_kind: x.evidence_kind,
        scientific_applicability: x.scientific_applicability,
        use_or_rights_status: x.use_or_rights_status,
        rationale: x.rationale,
      })),
      workflow_state: status.workflow_state,
      evidence_state: status.evidence_state,
      customer_outcome: status.customer_outcome,
      current_action: status.current_action,
      current_recommendation:
        "Retain Variant A in DEVELOPMENT; Variant B is conditional research review only.",
      cpes_economics: economics(d),
      evidence_gaps: coverage(d),
      next_discussion: d.decision.next_action,
      pilot_brief: T.clientPilotBrief(job, d),
      authority:
        "Planning summary only. Evidence reuse is not reference-answer reuse. Source measurements are public DEVELOPMENT evidence, not a score, pass/fail, qualification, submission, launch, protected reuse permission, or binding commercial claim. Local exports are unencrypted; keep them non-sensitive.",
    };
  }
  function engineeringProjection(job, d) {
    return {
      schema_version: "carbon.goal-workbench.engineering-packet.v1",
      job: clone(job.assignment),
      job_id: job.job_id,
      owner_console: R.ownerSummary(job, d),
      design: clone(d),
      coverage: coverage(d),
      conditional_economics: economics(d),
      launch_candidate: launchCandidate(d, job.native_task_id),
      team_review: clone(job.team_review),
      execution_brief: T.internalExecutionBrief(job, d),
      authority:
        "Requests source-owner review only. Cannot execute a solver, activate sharing, qualify science, grant rights, submit, register, or launch.",
    };
  }
  function n1Projection(job, d) {
    const status = R.ownerSummary(job, d);
    return {
      schema_version: "carbon.goal-workbench.n1-account-view.v1",
      job_id: job.job_id,
      title: job.title,
      planning_route: d.route_plan.route,
      intended_decision: job.assignment.intended_decision,
      client_words: job.assignment.client_words,
      source_measurement_evidence: d.measurement_evidence
        .filter((x) => x.binding_status === "CURRENT_DESIGN_REVISION")
        .map(E.clientSummary),
      workflow_state: status.workflow_state,
      evidence_state: status.evidence_state,
      customer_outcome: status.customer_outcome,
      current_action: status.current_action,
      next_owner_decision: job.assignment.next_owner_decision,
      next_action: d.decision.next_action,
      permitted_claims: d.decision.permitted_claims,
      excluded:
        "Internal provenance details, private experiments, protected cases, answers, credentials, runtime paths, raw diagnostics, and unapproved findings are not included.",
      authority:
        "Manual account handoff only; public DEVELOPMENT evidence is not qualification, and no CRM write, message, calendar change, or transmission occurred.",
    };
  }
  function markdown(v) {
    const lines = [
      "# " + (v.title || v.job_id || "Carbon planning export"),
      "",
      "Schema: `" + v.schema_version + "`",
      "",
      "```json",
      JSON.stringify(v, null, 2),
      "```",
      "",
      "Authority: " + (v.authority || "No authority conveyed."),
    ];
    return lines.join("\n") + "\n";
  }
  function cPilotProjection() {
    return {
      schema_version: "carbon.goal-workbench.operating-projection.v1",
      assignment_id: "C-PILOT-01",
      lead: "R1",
      support: "S1 supplies minimum existing job/grid context",
      question:
        "Can the existing Foundax FNO express the 8/16-mode contract check?",
      construction_scope:
        "1+1 pilot; possible six builds are pilot allowances, not global repeat policy",
      h1: "OPTIONAL_FOR_ROUTINE_CLASS_B; REQUIRED_ONLY_FOR_NAMED_RESERVED_SCIENCE",
      training_triggered: false,
      execution_status: "NOT_RUN_BY_WORKBENCH",
      authority:
        "Projection of supplied Grok v1.9 operating input; no Grok/account integration or execution is claimed.",
    };
  }
  const api = {
    VERSION,
    WORKSPACE_VERSION,
    APP_VERSION,
    HANDOFF_VERSION,
    RESPONSE_VERSION,
    LAUNCH_VERSION,
    ROLES,
    CASE_ROLES,
    DIAGNOSTIC_EXAMPLES,
    BLOCKERS,
    CONTROLS,
    AUTHORITY,
    ROUTES: R.ROUTES,
    PROVENANCE: R.PROVENANCE,
    WORKFLOW_STATES: R.WORKFLOW_STATES,
    EVIDENCE_STATES: R.EVIDENCE_STATES,
    CUSTOMER_OUTCOMES: R.CUSTOMER_OUTCOMES,
    ATTENTION_BUCKETS: R.ATTENTION_BUCKETS,
    DEPENDENCY_DOMAINS: R.DEPENDENCY_DOMAINS,
    newWorkspace,
    newJob,
    newDesign,
    requirement,
    trace,
    caseFamily,
    validateWorkspace,
    readWorkspace,
    validateJob,
    validateDesign,
    reviseDesign,
    applyChange,
    recordImpact,
    economics,
    coverage,
    prospectivePreferenceDiagnostic,
    diagnosticRequest,
    compatibility,
    authoringRequest,
    extensionRequest,
    semanticCompare,
    importAuthoringResult,
    handoff,
    markExported,
    validateResponse,
    importResponse,
    launchCandidate,
    clientProjection,
    engineeringProjection,
    n1Projection,
    markdown,
    cPilotProjection,
    previewIntakeImport,
    commitIntakeImport,
    revalidateIntakeRecords,
    emptyEconomics,
    protection,
    selectRoute: R.selectRoute,
    addEvidenceBinding: R.addEvidenceBinding,
    linkExternalRecord: R.linkExternalRecord,
    nextRouteAction: R.nextAction,
    ownerSummary: R.ownerSummary,
    ownerConsole: R.ownerConsole,
    teamQueue: (workspace) =>
      workspace.jobs.map((job) => {
        const selected =
          job.designs.find((design) => design.design_id === job.working_design_id) ||
          job.designs[0];
        return T.queueProjection(job, selected);
      }),
    clientPilotBrief: T.clientPilotBrief,
    internalExecutionBrief: T.internalExecutionBrief,
    addReviewCorrection: T.addCorrection,
    addAssessmentNote: (review, input) =>
      T.addManualRecord(review, "assessment_notes", input),
    addOutstandingQuestion: (review, input) =>
      T.addManualRecord(review, "outstanding_questions", input),
    QUEUE_STATES: T.QUEUE_STATES,
    ASSESSMENT_FIELDS: T.ASSESSMENT_FIELDS,
  };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.CarbonGoalWorkflow = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
