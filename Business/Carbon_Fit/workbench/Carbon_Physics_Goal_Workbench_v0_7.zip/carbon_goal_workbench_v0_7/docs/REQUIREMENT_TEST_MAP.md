# GOAL-WORKBENCH-07A / GOAL-WORKBENCH-07 / GOAL-WORKBENCH-06 / GOAL-WORKBENCH-05A / GOAL-WORKBENCH-05 / GOAL-WORKBENCH-04 / GOAL-WORKBENCH-03 / GOAL-WORKBENCH-02 / EXAM-PROTECT-WORKBENCH-01 requirement-to-test map

This map describes focused application acceptance. It does not relabel the CPES study's historical 14/52/208 runs as workbench tests.

| GW07 repository-snapshot requirement | Implementation / evidence | Automated coverage | Authority limitation |
|---|---|---|---|
| Ryan-controlled bounded issuer policy and exact adoption | `OWNER-GW07-RYAN-SNAPSHOT-01`; separate adoption record; installed profile | adoption-record schema/digest/scope checks, production profile/index and forgery tests | Adoption is exact-content scoped, not live authentication |
| Freeze exact subject and avoid re-entry | `scopeSubject`, `buildRequest`, design panel | sealed/draft/semantic-change/request determinism tests | Technical question only |
| Installed root cannot come from workspace/import | embedded profile/index; immutable installer | test-root production rejection, self-supplied-root, save/reload revalidation | Genuine build/release administration remains trusted |
| Exact raw/canonical/request/source association | `verifyResponse` | wrong job/design/revision/request/domain, changed bytes, replay tests | Matching bytes do not prove truth or live operator identity |
| Atomic failure and cumulative reasons | `importResponse`, scoped dispositions | historical-empty rejection, real production import, partial answer, tamper, child/reload tests | Scientific and rights reasons remain pending |
| Withdrawal/conflict/supersession fail closed | installed entry states | withdrawal/conflict and replay tests | Offline freshness limited to installed snapshot |
| Old v1 and v0.1–v0.6 compatibility | v0.7 migration; detached v1 retained | Workbench-06 rejection, v0.6 migration, inherited suites | Migration never creates adoption |
| One exact real admission; test branch remains isolated | one-entry production index, separate controlled adoption record and historical empty fixtures | build-time admission check, test-only rejection, real installed-snapshot positive test | Exactly two technical answers; one partial question; zero resolved reasons |
| Normal browser workflow and zero network | exact public example plus source-assessment panel in generated HTML | generated-browser load/import/dedupe/export/reload, tamper and outbound-request checks | No dispatch or remote fetch; later withdrawals unknown offline |

| GW06A delivery-integrity requirement | Retained evidence | Automated evidence | Authority limitation |
|---|---|---|---|
| Locator existence cannot stand in for delivered content | malformed comment API observation and immutable delivery history | local-path-only and malformed-status tests | Posting is not acknowledgment |
| Corrected content is complete and byte-verifiable | exact Markdown, readback observation, SHA-256 receipt | required/forbidden marker, issue/author/digest tests | Hash does not authenticate a source-owner response |
| Duplicate delivery and response inference fail closed | unique delivery marker and one-time response check | duplicate, eligible identity/time/decision and KEEP/CHANGE/BLOCKED tests | Silence and unrelated comments are not acceptance |
| Contract and application boundaries remain closed | all-false ceiling and unchanged v0.6 artifact | candidate import rejection, HTML digest and active-Wave assertions | No consumer, qualification, rights, execution, score or launch |

| GW06 contract requirement | Detached artifact | Automated evidence | Authority limitation |
|---|---|---|---|
| Exact request/content/source identities | sealed snapshot, request/response/profile/manifest v1 | positive validation; wrong job/design/revision/content/case/query/source tests | No production reader |
| Capability, evidence, applicability, origin and qualification remain separate | normative field/authority map and receipt | technical-unqualified, forged origin and all-false ceiling tests | Applicability never qualifies |
| Existing authoring and C-05 source rules are reused | retained bridge output and in-place C-05 ref | actual C-05 `importBundle`; authoring semantic/source digest checks | Fixed case is not a campaign or fresh execution |
| Partial/unsupported/conflicting/stale responses preserve debt | compact vector inventory | partial reasons, unsupported physics/rights, stale, replay/conflict/reconciliation tests | No real reason is resolved |
| Closed parser and atomic detached output | schemas and new-directory-only CLI | duplicate/key/number/depth, malicious text, no-output-on-failure tests | No network/account action |
| Current v0.6 application stays fail closed | unchanged application artifact | candidate response rejects with unchanged design | No source-owner confirmation/rights import |
| Source owner can decide three exact questions | decision packet | packet/manifest/source mapping assertions | Acceptance remains external and pending |

| v0.6 repair requirement | UI / data | Automated evidence | Authority limitation |
|---|---|---|---|
| Review debt is cumulative and order-safe | applicability table; reason records | `test_state_integrity.cjs` F1, reverse-order, child/grandchild, export/import | No review is resolved locally |
| Prohibition and unknowns are not overwritten | rights status plus separate reasons | F3 save/reload and scoped rights tests | No rights grant |
| All supported mutations have explicit impact | closed field-domain map | exclusions/workload/requirements and unknown-field rejection | Unsupported impact rejects |
| Native provenance follows verified content | claimed origin plus verification result | forged route/outcome/binding rejection; exact C-05 reimport | Hash/locator alone is not authentication |
| Evidence, activity, and decisions remain distinct | Owner Console explicit action ref | returned C-05, historical/open action, reconciliation tests | Observation is not execution or acceptance |
| Applicability cannot qualify | evidence-axis projection | guarded F7 adversarial test | Qualification consumer remains unavailable |
| v0.5 contradictions reconcile explicitly | v0.6 migration receipt | contradictory carry label migration test | Insufficient history stays unknown/review-required |
| Built artifact retains repaired state | desktop/narrow generated HTML | `browser_routing_smoke.cjs` material→editorial→export/import journey | Zero external requests; no adapter dispatch |

| v0.5 requirement | UI / data | Automated evidence | Authority limitation |
|---|---|---|---|
| Three exact-revision routes; no inferred migration route | Route panel; v0.5 closed schema | `test_routing.cjs` route/migration/sealed-revision cases; browser Journeys A–C | Route is planning only |
| Existing capability skips authoring; unsupported adaptation fails closed | Journey A; supported Burgers Journey B | pure route validation and Chrome journey checks | Existing is not customer-qualified; adapter remains Burgers/Dynamics only |
| New capability stops at one bounded feasibility question | Journey C; handoff export | question/lead/stop/restart tests; Chrome waiting state | Export is not send, execution, or approval |
| Owner Console and deterministic attention/action | Owner Console | separate-axis, attention, no-percent and narrow-width checks | Owner decides priority; no hidden rank |
| Workflow, evidence and customer statuses remain separate | three console columns | exported/sent/acknowledged/executed/qualified distinction tests | Local state cannot create trusted qualification |
| Provenance remains visible and closed | provenance badge/detail | manual/native/external/derived tests | Link/hash does not authenticate a claim |
| Exact-revision evidence binding and selective change impact | Evidence applicability and change-impact panels | commercial, intended-use, physics, output/units, population, score, reference, disclosure, rights and deployment cases | Carry-forward is not qualification or answer reuse |
| Fixed-case history survives without population inference | sealed parent plus child binding | child-revision and C-05 regression tests | One C-05 case remains source-executed/unresolved |
| CPES semantics remain unchanged | integrated change-impact display | A/B/C, five blockers, favorable-B non-authority regressions | No protection or launch activation |
| #42 `EXPORTED_OWNER_REQUEST` remains waiting | explicit external-linked negative control | pure and Chrome checks | No GitHub polling; not acknowledged/approved |
| v0.1–v0.4 additive migration and atomic rejection | v0.5 workspace receipt | migration, duplicate/dangerous/unknown authority-field tests | No science/applicability inferred |
| Frozen public/synthetic demonstrations | `goal_workbench_05_journeys_v1.json` | `browser_routing_smoke.cjs` against built HTML | Synthetic DEVELOPMENT only |

| v0.4 requirement | UI / data | Native owner / adapter | Automated evidence | Current limitation |
|---|---|---|---|---|
| Direct intake, multiple jobs/alternatives, optional Atlas, immutable revisions | Client jobs; v0.3 job/design schemas | Business/WAVE-G planning owner | `test_workflow.cjs`; `browser_goal_smoke.cjs` | Browser-local manual persistence; no live intake/CRM |
| Exact C-05 result bytes and provenance bind to request/job/design/revision/trace/case | C-05 evidence panel; v0.4 closed association record; retained fixture index | C-05 read-only adapter | 25 `test_c05_evidence.cjs` checks, including cross-design rebind rejection; exact Chrome import | Public DEVELOPMENT only; one retained complete case is not population evidence; the registry-pinned manual association is not operator authentication |
| Raw values remain separate from scientific interpretation | four measurements, six physics defects, null limit/uncertainty labels | C-05 source contract | ID/order/numeric/unresolved/projection tests | No pass/fail, score, rank, or qualified floor |
| Fail-closed replay and change semantics | dedup/conflict/rejection/staleness states | Workbench adapter | wrong identity/schema/provenance, nonfinite, forgery, revision and edit tests | Requires exact registered fixture bytes |
| Preserve original requirement and link score/cases/reference | Requirement trace, score plan, case families, reference plan, diagnostic-request export | Measurement/ScorePack, generator, reference owners | workflow coverage/mandatory-failure/diagnostic-request tests; browser source-bound case trace and downloaded request | Structural coverage is not numerical or scientific adequacy; request status stays `NOT_EXECUTED` |
| Exact supported Burgers compilation and semantic agreement | Authoring request/result/receipt | C-AUTH1; `tools/authoring_bridge.py` fixed CLI | bridge Python tests; actual CLI round trip in browser journey | DEVELOPMENT Dynamics only; not qualification/registration |
| Same-PDE incompatible goal and non-Burgers/rights gaps | Extension request retained in design | C-AUTH1 source owner | Front Resolution and extension tests | Source owner must implement/accept any new capability |
| Design-bound CPES and stale impact | CPES binding + change log | CPES research and domain owners | favorable-B/stale-economics workflow tests; browser journey | A remains baseline; five claims and adequate R/demand/H/service unknowns remain |
| Bidirectional idempotent handoffs | handoff/response v1 arrays | Named S1/R1/owner/executor/launch owner | duplicate/conflict/stale/wrong-task/forgery tests; browser ack cycle | Actual route is manual; no Grok/CRM/message connector |
| Least-privilege client/N1/Engineering views | projections and downloads | Business/account and Engineering owners | projection unit tests; parsed browser downloads | Files are unencrypted and not transmitted |
| Launch candidate and truthful native status | launch-candidate v1 | Launch/registration owner | forged status and candidate export tests | Native launch interface unavailable; no actual launch |
| Additive v0.1/v0.2/v0.3 migration | outer v0.3 closed schema + receipt | Workbench owner | workflow migration/authority tests; browser migrate/export/reload | No science inferred for migrated component-only sessions |
| C-PILOT-01 operating projection | read-only v1.9 projection | R1 lead, S1 support, optional H1 | workflow projection test plus v1.9 conformance map | DOCX hash verified and ten rendered source pages inspected; no account integration or training run |

## GOAL-WORKBENCH-03 operational rehearsal

| Requirement | UI / data | Native owner / adapter | Automated evidence | Current limitation |
|---|---|---|---|---|
| Freeze three public/synthetic journeys before execution | rehearsal protocol v1 | Workbench owner | `test_rehearsal.cjs`: exact journey IDs and authority rules | Does not authorize a customer, protected, solver, training, or launch run |
| Verify Grok v1.9 roles and operating rules | Grok conformance v1; handoff fields; N1/C-PILOT projections | M0/R1/S1/N1 and named decision owners | exact DOCX hash, conformance mapping test, ten rendered pages inspected | No account connector |
| Forward and reverse score/case trace | `coverage()` and Challenge result summary | Measurement/ScorePack, generator, reference owners | workflow bidirectional case test; deterministic Journey A | Structural assembly is not numerical adequacy or qualification |
| Real source-owned supported authoring | Journey A record | C-AUTH1 fixed local CLI bridge | deterministic rehearsal plus bridge/source tests | Burgers Dynamics DEVELOPMENT only |
| Detect compiler success with semantic mismatch | Journey B record and extension request | C-AUTH1 owner | real Front Resolution bridge run returns Dynamics and `INTENT_MISMATCH` | Active Front Resolution template unavailable |
| Preserve unsupported physics/rights and resume exactly | Journey C record and extension/handoff | C-AUTH1 plus rights/source owners | blocker binding, duplicate replay and restart event tests | Manual route; source capability and rights decisions absent |
| One correction, precise blocker, no polling, timeout uncertainty | rehearsal event validator | Named handoff owner | positive sequence plus polling/second-correction/timeout negative controls | Event policy is rehearsal evidence, not a connector or task daemon |
| CPES change impact remains scoped | `recordImpact`, preserved CPES record | CPES/domain owners | population/score/reference/disclosure/commercial controls | Variant A remains DEVELOPMENT; five claims and core inputs remain unresolved |
| Design-bound numerical diagnostic request | Journey A diagnostic request | Measurement/ScorePack owner | request stays `NOT_EXECUTED` | Source-owned response adapter is recommended next integration |
| Rank manual/unavailable interfaces without invented score | rehearsal record and next-integration handoff | Workbench and interface owners | deterministic record assertions | Human time/wait not measured; no ROI claim |

| Requirement | Automated evidence |
|---|---|
| Exact source archive, 64 opportunities, source wording/ratings, MMS and role distinctions | `tests/test_sources.py`: atlas hash/re-extraction, 64 IDs/groups, reference/MMS/experiment tables, source hypotheses; `tests/test_engine.cjs`: all-ID migration and role preservation |
| All eight indexed CPES members, exact hashes, schemas, 30 attacks, 17/8/5 layers, five blockers | `tools/import_cpes_evidence.py --check`; `tests/test_sources.py`: member/schema/cross-consistency and public adapter tests |
| Baseline A cannot be changed by scenarios/imports; B conditional; C sensitivity; negative control never an option | `tests/test_engine.cjs`: fixed-group, authority-forgery, C, export tests; `tests/browser_smoke.cjs`: baseline immutability, disabled activation, library layers/control |
| P1–P8 inside Exam; `UNASSESSED`, `PROTECTION_BLOCKED`, `READY_FOR_DOMAIN_REVIEW`; completeness independent of blockers | `tests/test_engine.cjs`: five protection-state cases; browser checks P1–P8 and five source claims |
| Conditional economics, unknowns, singleton/equality/sign, field dependence, incomplete/zero completion | `tests/test_engine.cjs`: fixed-group and aggregate cases, exact b=3/R=40/H=4 vector |
| No cross-unit/cross-host/wall-vs-occupancy composition; upfront cost separate | `tests/test_engine.cjs`: scoped quantity composition and upfront-invariance tests |
| Dynamic grouping recomputed and slow-member completion/service caveat | `tests/test_engine.cjs`: exact 38/39 vs 36/36 vector and slow row; browser dynamic table/caveat |
| Six deterministic next-evidence conditions and review-only packet | `tests/test_engine.cjs`: projections; browser profile and actual Engineering download bytes |
| Additive v0.1 migration; no data loss or authority promotion; invalid import atomic | `tests/test_engine.cjs`: substantive migration, 64 identities, round trip, schema/authority rejection; browser migrate/edit/export/reload path |
| Closed parser: duplicates, dangerous keys, depth, overflow, booleans, unknown fields | `tests/test_engine.cjs`: strict parser/schema cases; browser duplicate-member rejection |
| Safe text rendering, no breakout/navigation/request, CSP, offline operation | `tests/test_sources.py`: CSP and embedded JSON build; browser malicious text, page errors, outbound requests, network-blocked flow |
| Client and Engineering JSON/Markdown preview/download with caveats | `tests/test_engine.cjs`: deterministic projections; browser saves and parses all four downloaded artifacts |
| Keyboard, labels, live status, desktop/narrow render | Browser focus/label/live-region/overflow checks and three screenshots in `tests/` |
| Reproducible standalone HTML and complete bundle | `tests/test_sources.py`: double build and manifest/bundle reproduction; `tools/package_release.py` |

## Browser coverage

The recorded automated run uses the actual generated `file://` artifact in installed Google Chrome (Chromium), desktop 1440×1050 and narrow 390×844. A separate CUA owner walk-through uses the supported `127.0.0.1` route. Safari/WebKit automation was unavailable locally and is not counted as passed.
