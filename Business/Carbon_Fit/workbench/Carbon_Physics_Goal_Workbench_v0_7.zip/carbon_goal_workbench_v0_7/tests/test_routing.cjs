"use strict";
const test = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("node:fs"),
  path = require("node:path");
const ROOT = path.resolve(__dirname, ".."),
  F = require("../src/engine.js"),
  R = require("../src/routing.js"),
  E = require("../src/c05_evidence.js"),
  G = require("../src/workflow.js");
E.installFixtureIndex(
  JSON.parse(
    fs.readFileSync(path.join(ROOT, "data/c05_fixture_index_v2.json")),
  ),
);
const atlas = JSON.parse(fs.readFileSync(path.join(ROOT, "data/atlas.json"))),
  ids = atlas.opportunities.map((x) => x.id),
  sha = atlas.source.sha256;
const clone = (x) => JSON.parse(JSON.stringify(x));
function component() {
  return {
    schema_version: F.WORKSPACE_VERSION,
    application_version: F.APP_VERSION,
    source_sha256: sha,
    evidence_catalog: [],
    drafts: [],
    shortlist: [],
    migration_receipts: [],
  };
}
function reader(raw) {
  return F.readWorkspace(raw, ids, sha);
}
function context() {
  const w = G.newWorkspace(component()),
    j = G.newJob("job-001", "Synthetic owner journey"),
    d = j.designs[0];
  w.jobs.push(j);
  return { w, j, d };
}
function sourceDesign() {
  const x = context(),
    { d } = x;
  Object.assign(d.scope, {
    physics_family: "periodic_viscous_burgers_1d_v1",
    requested_goal: "Dynamics",
    intended_use: "Bounded public DEVELOPMENT comparison",
    inputs: "initial field, viscosity and times",
    outputs: "complete field evolution",
    units: "source nondimensional units",
    conditions: "periodic, unforced",
    query_workload: "fixed public case",
    turnaround: "unresolved",
    rights_scope: "SYNTHETIC_INTERNAL",
  });
  d.requirements = [
    G.requirement(
      "REQ-1",
      "Predict field.",
      "synthetic",
      "Inform a bounded decision",
    ),
  ];
  const t = G.trace("TRACE-1", "REQ-1");
  Object.assign(t, {
    measurement_definition: "source measurement",
    authoring_binding: "source binding",
    role: "MANDATORY",
    floor: "source development floor",
  });
  d.traces = [t];
  const c = G.caseFamily("CASE-1", "EVAL");
  Object.assign(c, {
    requirement_ids: ["REQ-1"],
    generator_ref: "goal_burgers_12cell_v1",
    support_status: "SOURCE_SUPPORTED",
  });
  d.cases = [c];
  return x;
}
function binding(d, overrides = {}) {
  return {
    evidence_binding_id: "evidence-1",
    evidence_kind: "FIXED_CASE_RESULT",
    source_ref: "public:result",
    source_digest_or_identity: "sha256:" + "a".repeat(64),
    design_id: d.design_id,
    design_revision: d.revision,
    originating_design_id: d.design_id,
    originating_design_revision: d.revision,
    originating_binding_id: "evidence-1",
    trace_ids: d.traces.map((x) => x.trace_id),
    case_family_ids: d.cases.map((x) => x.case_family_id),
    dependency_domains: [...R.C05_DOMAINS],
    scope_relationship: "UNASSESSED",
    scientific_applicability: "UNASSESSED",
    scientific_review_reasons: [],
    use_or_rights_status: "UNRESOLVED",
    rights_review_reasons: [],
    assessment_basis: "Exact public source identity.",
    rationale: "Fixed-case DEVELOPMENT evidence only.",
    invalidated_by: [],
    source_claimed_provenance: "LOCAL_MANUAL_ASSERTION",
    origin_verification: "UNVERIFIED_CLAIM",
    status_provenance: "LOCAL_MANUAL_ASSERTION",
    ...overrides,
  };
}
function select(j, d, route, overrides = {}) {
  j.accountable_owner = "Ryan";
  j.lead = "S1";
  const base = {
    rationale: "Bounded route rationale.",
    source_or_capability_ref: "public:capability",
    route_basis: "Exact comparison or delta.",
    unresolved_conditions: [],
    next_decision: "Owner disposition.",
    selected_by_assertion: "Local editor",
    status_provenance: "LOCAL_MANUAL_ASSERTION",
  };
  if (route === "DEVELOP_NEW_CAPABILITY")
    Object.assign(base, {
      source_or_capability_ref: "",
      bounded_question:
        "Can one supported representation answer the consequential question?",
      stop_condition: "Stop after one finding.",
      restart_event: "Source owner returns one finding.",
    });
  return G.selectRoute(d, route, { ...base, ...overrides });
}

test("new route defaults to UNASSESSED and no route is inferred", () => {
  const { d } = context();
  assert.equal(d.route_plan.route, "UNASSESSED");
  assert.equal(d.route_plan.status_provenance, "WORKBENCH_DERIVED");
});
test("sealed design cannot change route without revision", () => {
  const { j, d } = context();
  select(j, d, "USE_EXISTING_CAPABILITY");
  G.reviseDesign(j, d.design_id, "job-001-r2");
  assert.throws(() => G.selectRoute(d, "UNASSESSED"), /new revision/);
  assert.equal(j.designs[1].route_plan.route, "UNASSESSED");
});
test("existing-capability route skips Challenge authoring and asks for applicability", () => {
  const { j, d } = context();
  select(j, d, "USE_EXISTING_CAPABILITY", {
    unresolved_conditions: ["deployment evidence"],
  });
  assert.equal(
    G.nextRouteAction(j, d).action,
    "REVIEW_INTENDED_USE_APPLICABILITY",
  );
  assert.equal(d.authoring.request_id, "");
});
test("adapt route accepts exact supported Burgers intent", () => {
  const { j, d } = sourceDesign();
  select(j, d, "ADAPT_SUPPORTED_CHALLENGE");
  assert.equal(d.route_plan.route, "ADAPT_SUPPORTED_CHALLENGE");
});
test("adapt route cannot coerce unsupported physics", () => {
  const { j, d } = context();
  d.scope.physics_family = "synthetic_heat_v1";
  assert.throws(
    () => select(j, d, "ADAPT_SUPPORTED_CHALLENGE"),
    /cannot coerce/,
  );
});
test("develop route requires bounded question stop and restart", () => {
  const { j, d } = context();
  assert.throws(
    () =>
      G.selectRoute(d, "DEVELOP_NEW_CAPABILITY", {
        rationale: "Unsupported.",
        selected_by_assertion: "Local",
        status_provenance: "LOCAL_MANUAL_ASSERTION",
      }),
    /bounded question/,
  );
  select(j, d, "DEVELOP_NEW_CAPABILITY");
  assert.equal(G.nextRouteAction(j, d).action, "ISSUE_ONE_BOUNDED_HANDOFF");
});
test("route record cannot carry approval or qualification fields", () => {
  const { d } = context();
  assert.throws(
    () => G.selectRoute(d, "UNASSESSED", { approved: true }),
    /Unsupported route-plan field/,
  );
});

test("owner console keeps workflow evidence and customer axes separate", () => {
  const { w, j, d } = context();
  j.accountable_owner = "Ryan";
  const row = G.ownerConsole(w).rows[0];
  assert.equal(row.workflow_state, "NEEDS_OWNER_DECISION");
  assert.equal(row.evidence_state, "MISSING");
  assert.equal(row.customer_outcome, "OPEN");
  assert.equal(Object.hasOwn(row, "percent_complete"), false);
});
test("attention groups are deterministic and are not scores", () => {
  assert.equal(R.attentionBucket("NEEDS_OWNER_DECISION"), "NEEDS_DECISION");
  assert.equal(R.attentionBucket("ACTIVE_NATIVE_EVIDENCE"), "ACTIVE");
  assert.equal(R.attentionBucket("WAITING_ON_DEPENDENCY"), "WAITING");
});
test("exported owner request is waiting not sent acknowledged executed or approved", () => {
  const { j, d } = context();
  select(j, d, "DEVELOP_NEW_CAPABILITY");
  G.linkExternalRecord(d, {
    record_id: "D-QUAL-PREP-01-FOLLOWUP-01",
    source_ref: "issue:42#comment",
    status: "EXPORTED_OWNER_REQUEST",
    provenance: "EXTERNAL_LINKED_RECORD",
    note: "Exported only.",
  });
  const row = G.ownerSummary(j, d);
  assert.equal(row.workflow_state, "WAITING_ON_DEPENDENCY");
  assert.equal(row.open_request_or_handoff, "EXPORTED_OWNER_REQUEST");
  assert.equal(row.evidence_state, "MISSING");
  assert.equal(d.decision.scientific_qualification, "NOT_QUALIFIED");
});
test("sent acknowledged executed and qualified remain distinct states", () => {
  const { j, d } = context();
  select(j, d, "DEVELOP_NEW_CAPABILITY");
  const record = {
    record_id: "request-1",
    source_ref: "manual:record",
    status: "SENT",
    provenance: "EXTERNAL_LINKED_RECORD",
    note: "Manual link.",
  };
  G.linkExternalRecord(d, record);
  assert.equal(G.ownerSummary(j, d).workflow_state, "WAITING_ON_DEPENDENCY");
  d.coordination.external_records[0].status = "ACKNOWLEDGED";
  assert.equal(G.ownerSummary(j, d).workflow_state, "WAITING_ON_DEPENDENCY");
  d.coordination.external_records[0].status = "EXECUTED";
  assert.equal(G.ownerSummary(j, d).workflow_state, "NEEDS_OWNER_DECISION");
  assert.equal(G.ownerSummary(j, d).evidence_state, "MISSING");
});
test("manual outcome is visibly manual and forged native evidence is rejected", () => {
  const { j, d } = sourceDesign();
  d.coordination.customer_outcome = "FEASIBILITY_FINDING";
  d.coordination.customer_outcome_provenance = "LOCAL_MANUAL_ASSERTION";
  G.addEvidenceBinding(d, binding(d));
  const row = G.ownerSummary(j, d);
  assert.equal(row.customer_outcome_provenance, "LOCAL_MANUAL_ASSERTION");
  assert.equal(
    d.evidence_bindings[0].status_provenance,
    "LOCAL_MANUAL_ASSERTION",
  );
  assert.throws(
    () =>
      G.addEvidenceBinding(
        d,
        binding(d, {
          evidence_binding_id: "forged-native",
          originating_binding_id: "forged-native",
          status_provenance: "NATIVE_IMPORTED_RESULT",
        }),
      ),
    /exact C-05 reader/,
  );
});

test("exact evidence binding is design-revision scoped", () => {
  const { d } = sourceDesign();
  assert.throws(
    () => G.addEvidenceBinding(d, binding(d, { design_revision: 2 })),
    /exact design revision/,
  );
  assert.equal(G.addEvidenceBinding(d, binding(d)).disposition, "ADDED");
});
test("binding duplicate deduplicates and changed same identity conflicts", () => {
  const { d } = sourceDesign(),
    b = binding(d);
  G.addEvidenceBinding(d, b);
  assert.equal(G.addEvidenceBinding(d, b).disposition, "DEDUPLICATED");
  assert.throws(
    () => G.addEvidenceBinding(d, { ...b, rationale: "changed" }),
    /Conflicting/,
  );
});
test("commercial editorial change preserves assessment and records unchanged relationship", () => {
  const { d } = sourceDesign();
  G.addEvidenceBinding(d, binding(d));
  G.applyChange(d, "commercial_context", "Editorial account note");
  assert.equal(d.evidence_bindings[0].scientific_applicability, "UNASSESSED");
  assert.equal(d.evidence_bindings[0].scope_relationship, "UNCHANGED");
  assert.equal(d.cpes.invalidated_by.length, 0);
});
test("intended-use change preserves numerical assessment while recording use review", () => {
  const { d } = sourceDesign();
  G.addEvidenceBinding(d, binding(d));
  G.applyChange(d, "intended_use", "New deployment use");
  assert.equal(d.evidence_bindings[0].scientific_applicability, "UNASSESSED");
  assert.equal(d.evidence_bindings[0].use_or_rights_status, "REVIEW_REQUIRED");
  assert.ok(
    d.evidence_bindings[0].rights_review_reasons.some(
      (x) => x.domain === "INTENDED_USE",
    ),
  );
});
for (const [field, value, domain] of [
  ["physics_family", "changed_physics", "PHYSICS_SCOPE"],
  ["outputs", "changed output", "OUTPUT_CONTRACT"],
  ["units", "changed units", "UNITS_SCALING"],
])
  test(field + " change requires affected scientific review", () => {
    const { d } = sourceDesign();
    G.addEvidenceBinding(d, binding(d));
    G.applyChange(d, field, value);
    assert.equal(
      d.evidence_bindings[0].scientific_applicability,
      "REVIEW_REQUIRED",
    );
    assert.ok(d.evidence_bindings[0].invalidated_by.includes(field));
    assert.ok(d.change_log.at(-1).domains.includes(domain));
  });
test("population change preserves fixed-case history while removing population inference", () => {
  const { d } = sourceDesign();
  G.addEvidenceBinding(d, binding(d));
  G.recordImpact(d, "population", "Changed case family");
  assert.equal(
    d.evidence_bindings[0].scientific_applicability,
    "REVIEW_REQUIRED",
  );
  assert.match(d.evidence_bindings[0].rationale, /historical/);
});
test("measurement or reference changes trigger dependent review", () => {
  for (const field of ["score", "reference"]) {
    const { d } = sourceDesign();
    G.addEvidenceBinding(d, binding(d));
    G.recordImpact(d, field, "changed");
    assert.equal(
      d.evidence_bindings[0].scientific_applicability,
      "REVIEW_REQUIRED",
    );
  }
});
test("disclosure change affects CPES and records rights review without invalidating raw science", () => {
  const { d } = sourceDesign();
  G.addEvidenceBinding(d, binding(d));
  G.applyChange(d, "disclosure_scope", "broader publication");
  assert.equal(d.evidence_bindings[0].scientific_applicability, "UNASSESSED");
  assert.equal(d.evidence_bindings[0].use_or_rights_status, "REVIEW_REQUIRED");
  assert.ok(
    d.evidence_bindings[0].rights_review_reasons.some(
      (x) => x.domain === "CPES_DISCLOSURE",
    ),
  );
  assert.ok(d.cpes.invalidated_by.length);
});
test("rights and deployment changes do not rewrite numerical assessment and require rights review", () => {
  for (const [field, value, domain] of [
    ["rights_scope", "CLIENT_RESTRICTED", "RIGHTS"],
    ["deployment_environment", "new hardware", "DEPLOYMENT"],
  ]) {
    const { d } = sourceDesign();
    G.addEvidenceBinding(d, binding(d));
    G.applyChange(d, field, value);
    assert.equal(d.evidence_bindings[0].scientific_applicability, "UNASSESSED");
    assert.equal(
      d.evidence_bindings[0].use_or_rights_status,
      "REVIEW_REQUIRED",
    );
    assert.ok(
      d.evidence_bindings[0].rights_review_reasons.some(
        (x) => x.domain === domain,
      ),
    );
  }
});
test("child revision carries exact evidence and obligations without upgrading it", () => {
  const { j, d } = sourceDesign();
  G.addEvidenceBinding(d, binding(d));
  const child = G.reviseDesign(j, d.design_id, "job-001-r2", [
    { field: "commercial_context", value: "copy edit" },
  ]);
  assert.equal(
    child.evidence_bindings[0].scientific_applicability,
    "UNASSESSED",
  );
  assert.equal(child.evidence_bindings[0].scope_relationship, "UNCHANGED");
  assert.notEqual(child.evidence_bindings[0].design_id, d.design_id);
  assert.notEqual(
    child.evidence_bindings[0].scientific_applicability,
    "SOURCE_OWNER_CONFIRMED",
  );
});
test("child population change keeps evidence retained but review-required", () => {
  const { j, d } = sourceDesign();
  G.addEvidenceBinding(d, binding(d));
  const child = G.reviseDesign(j, d.design_id, "job-001-r2", [
    { field: "regime", value: "new population" },
  ]);
  assert.equal(
    child.evidence_bindings[0].scientific_applicability,
    "REVIEW_REQUIRED",
  );
  assert.match(child.evidence_bindings[0].rationale, /historical/);
});
test("manual import cannot claim source-owner confirmation or authorization", () => {
  const { d } = sourceDesign();
  assert.throws(
    () =>
      G.addEvidenceBinding(
        d,
        binding(d, { scientific_applicability: "SOURCE_OWNER_CONFIRMED" }),
      ),
    /future eligible source interface/,
  );
  assert.throws(
    () =>
      G.addEvidenceBinding(
        d,
        binding(d, { use_or_rights_status: "SOURCE_AUTHORIZED" }),
      ),
    /future eligible source interface/,
  );
});

test("CPES baseline variants and five blockers remain unchanged", () => {
  const { d } = context();
  assert.equal(d.cpes.baseline, "RETAIN_A_DEVELOPMENT");
  assert.deepEqual(G.BLOCKERS, ["AT-09", "AT-16", "AT-19", "AT-22", "AT-30"]);
  assert.equal(d.decision.scientific_qualification, "NOT_QUALIFIED");
  assert.equal(d.decision.launch_authorization, "NOT_AUTHORIZED");
});
test("favorable conditional economics cannot choose a route", () => {
  const { d } = context();
  Object.assign(d.cpes.economics, {
    reference_work: "40",
    reference_status: "user_assumed",
    group_overhead: "4",
    overhead_status: "user_assumed",
    group_size: "3",
    group_size_status: "user_assumed",
    unit: "synthetic work units",
    unit_scope: "one group",
    compatible_demand_status: "user_assumed",
    field_dependent: "NO",
  });
  assert.equal(G.economics(d).relation, "favorable");
  assert.equal(d.route_plan.route, "UNASSESSED");
});

test("v0.4 migration adds current empty fields and never selects or applies evidence", () => {
  const { w } = sourceDesign(),
    old = clone(w);
  old.schema_version = "carbon.goal-workbench.workspace.v0.4";
  old.application_version = "Carbon Goal-to-Challenge Workbench v0.4";
  old.decision_id = "GOAL-WORKBENCH-04";
  old.base_application_merge = "95e717f28fab66a087b1e7006ad2ba5e167e2ddf";
  for (const j of old.jobs) {
    delete j.accountable_owner;
    delete j.working_design_id;
    for (const d of j.designs) {
      d.schema_version = "carbon.goal-workbench.design.v0.4";
      for (const key of [
        "commercial_context",
        "disclosure_scope",
        "deployment_environment",
      ])
        delete d.scope[key];
      delete d.route_plan;
      delete d.evidence_bindings;
      delete d.source_assessments;
      delete d.coordination;
      d.change_log = d.change_log.map(({ domains, ...rest }) => rest);
    }
  }
  const migrated = G.readWorkspace(JSON.stringify(old), reader);
  assert.equal(migrated.schema_version, G.WORKSPACE_VERSION);
  assert.equal(migrated.jobs[0].designs[0].route_plan.route, "UNASSESSED");
  assert.deepEqual(migrated.jobs[0].designs[0].evidence_bindings, []);
  assert.equal(migrated.jobs[0].accountable_owner, "");
});
test("invalid v0.5 import is atomic at the pure reader boundary", () => {
  const { w } = context(),
    raw = JSON.stringify(w),
    bad = JSON.parse(raw);
  bad.jobs[0].designs[0].route_plan.route = "QUALIFIED";
  assert.throws(
    () => G.readWorkspace(JSON.stringify(bad), reader),
    /Invalid planning route/,
  );
  assert.equal(
    JSON.parse(raw).jobs[0].designs[0].route_plan.route,
    "UNASSESSED",
  );
});
test("closed parser rejects duplicate members dangerous keys unsafe numbers and excessive depth", () => {
  assert.throws(() => F.strictJsonParse('{"a":1,"a":2}'), /duplicate/);
  assert.throws(() => F.strictJsonParse('{"constructor":{}}'), /forbidden/);
  assert.throws(() => F.strictJsonParse('{"x":9007199254740992}'), /unsafe/);
  assert.throws(
    () => F.strictJsonParse("[".repeat(26) + "0" + "]".repeat(26)),
    /nesting/,
  );
});
test("general readiness document cannot be bound as a C-05 result by hash alone", () => {
  const { d } = sourceDesign();
  G.addEvidenceBinding(
    d,
    binding(d, {
      evidence_kind: "RESEARCH_REFERENCE",
      source_ref: "D-QUAL readiness report",
      source_claimed_provenance: "EXTERNAL_LINKED_RECORD",
      origin_verification: "EXTERNAL_LOCATOR_ONLY",
      status_provenance: "EXTERNAL_LINKED_RECORD",
    }),
  );
  assert.equal(d.measurement_evidence.length, 0);
  assert.equal(
    G.ownerSummary(context().j, d).evidence_state,
    "STRUCTURAL_ONLY",
  );
});
